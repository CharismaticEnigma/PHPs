<?php
include('cms_admin/connect1.php');
$val="";
$pgnm="gallery_photos.php";
////////////////////////////////////////////// FOR NEPALI CONTENTS ///////////////////////////////////
 if((isset($_GET['contType']))=="nep"){
	$val="nep";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>पि.आर.एम.दि - तस्वीरहरु</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<div class="row">
			<div class="col-md-9">
				<h3> तसवीर ग्यालरी</h3>						
				<div class="row">
					<?php
					$s1="Select * from galleryimage;";
					$qr1=mysqli_query($connect,$s1) or die ("Error in Mysqli: ".mysqli_error($connect));
					while ($rs1=mysqli_fetch_array($qr1))
					{
						$imgNm=$rs1['galleryimageName1'];
						$imgPath=$rs1['galleryimageImagePath'];
					
					?>
					<div class="col-md-4"  style="text-align:center;">
						<a class="group1" href="<?php echo $imgPath; ?>" title="<?php echo $imgNm; ?>" alt="<?php echo $imgNm; ?>">
							<img src="<?php echo $imgPath; ?>" class="img-thumbnail" alt="<?php echo $imgNm; ?>" style="width:200px; height:200px;">
						</a>
						<p><?php echo $imgNm; ?></p>
					</div>
					<?php
					}
				?>	
					
					
					
				</div>					
			</div>
			<div class="col-md-3">
				<?php include('include/sidebar.php'); ?>
			</div>
		</div>		
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
}
////////////////////////////////////////////// FOR ENGLISH CONTENTS ///////////////////////////////////
else{
	$val="eng";
	?>
	<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>PRMD - Photos</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<div class="row">
			<div class="col-md-9">
				<h3>Photo Gallery</h3>						
				<div class="row">
				<?php
					$s1="Select * from galleryimage;";
					$qr1=mysqli_query($connect,$s1) or die ("Error in Mysqli: ".mysqli_error($connect));
					while ($rs1=mysqli_fetch_array($qr1))
					{
						$imgNm=$rs1['galleryimageName'];
						$imgPath=$rs1['galleryimageImagePath'];
					
					?>
					<div class="col-md-4"  style="text-align:center;">
						<a class="group1" href="<?php echo $imgPath; ?>" title="<?php echo $imgNm; ?>" alt="<?php echo $imgNm; ?>">
							<img src="<?php echo $imgPath; ?>" class="img-thumbnail" alt="<?php echo $imgNm; ?>" style="width:200px; height:200px;">
						</a>
						<p><?php echo $imgNm; ?></p>
					</div>
					<?php
					}
				?>		
				</div>					
			</div>
			<div class="col-md-3">
				<?php include('include/sidebar.php'); ?>
			</div>
		</div>		
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
}
?>
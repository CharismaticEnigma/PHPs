-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 22, 2014 at 06:41 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `prmd`
--
CREATE DATABASE IF NOT EXISTS `prmd` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `prmd`;

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE IF NOT EXISTS `about` (
  `aboutID` int(11) NOT NULL AUTO_INCREMENT,
  `aboutName` varchar(200) NOT NULL,
  `aboutName1` varchar(200) NOT NULL,
  `aboutDesc` text NOT NULL,
  `aboutDesc1` text NOT NULL,
  `aboutImagePath` text NOT NULL,
  PRIMARY KEY (`aboutID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`aboutID`, `aboutName`, `aboutName1`, `aboutDesc`, `aboutDesc1`, `aboutImagePath`) VALUES
(2, 'a1', 'à¤µà¤¿à¤·à¤¯ à¥§', '<p>This is article 1 that will be shown when you are visiting website in English.</p>\r\n', '<p>à¤µà¤¿à¤·à¤¯ à¥§ à¤¤à¤ªà¤¾à¤ˆà¤²à¥‡ à¤¨à¥‡à¤ªà¤¾à¤²à¥€à¤®à¤¾ à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤¤ à¤¹à¥‡à¤°à¥à¤¨à¥ à¤¹à¥à¤¦à¤¾ à¤¦à¥‡à¤–à¥à¤¨à¥ à¤¹à¥à¤¨à¥‡à¤›à¥â€‹à¥¤</p>\r\n', 'images/about/1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `galleryimage`
--

CREATE TABLE IF NOT EXISTS `galleryimage` (
  `galleryimageID` int(11) NOT NULL AUTO_INCREMENT,
  `galleryimageName` varchar(200) NOT NULL,
  `galleryimageName1` varchar(200) NOT NULL,
  `galleryimageImagePath` text NOT NULL,
  PRIMARY KEY (`galleryimageID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `galleryimage`
--

INSERT INTO `galleryimage` (`galleryimageID`, `galleryimageName`, `galleryimageName1`, `galleryimageImagePath`) VALUES
(5, 'gallery 1', 'à¤šà¤¿à¤¤à¥à¤° à¥§', 'images/gallery/residential.png');

-- --------------------------------------------------------

--
-- Table structure for table `galleryvideo`
--

CREATE TABLE IF NOT EXISTS `galleryvideo` (
  `galleryvideoID` int(11) NOT NULL AUTO_INCREMENT,
  `galleryvideoName` varchar(200) NOT NULL,
  `galleryvideoName1` varchar(200) NOT NULL,
  `galleryvideoLink` text NOT NULL,
  PRIMARY KEY (`galleryvideoID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `indexmodule`
--

CREATE TABLE IF NOT EXISTS `indexmodule` (
  `modID` int(11) NOT NULL AUTO_INCREMENT,
  `tableName` text NOT NULL,
  `modLink` text NOT NULL,
  `headingID` int(11) NOT NULL,
  PRIMARY KEY (`modID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `Login_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Login_Name` varchar(400) NOT NULL,
  `Login_Pass` varchar(500) NOT NULL,
  PRIMARY KEY (`Login_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `SN` int(11) NOT NULL AUTO_INCREMENT,
  `menuName` varchar(200) NOT NULL,
  `menuLink` text NOT NULL,
  `menuTableName` varchar(200) NOT NULL,
  PRIMARY KEY (`SN`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`SN`, `menuName`, `menuLink`, `menuTableName`) VALUES
(1, 'About us', 'about_us.php', 'about'),
(2, 'Programs and Services', 'programs_services.php', 'others');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `newsID` int(11) NOT NULL AUTO_INCREMENT,
  `newsName` varchar(200) NOT NULL,
  `newsName1` varchar(200) NOT NULL,
  `newsDesc` text NOT NULL,
  `newsDesc1` text NOT NULL,
  `newsImagePath` text NOT NULL,
  PRIMARY KEY (`newsID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`newsID`, `newsName`, `newsName1`, `newsDesc`, `newsDesc1`, `newsImagePath`) VALUES
(2, 'News 1', 'à¤¸à¤®à¤¾à¤šà¤¾à¤° à¥§', '<p>This content is typed in english. This will be shown when the site is visited in english</p>\r\n', '<p>à¤¯à¤¸à¤®à¤¾ à¤²à¥‡à¤–à¤¿à¤à¤•à¤¾ à¤•à¥à¤°à¤¾à¤¹à¤°à¥ à¤¨à¥‡à¤ªà¤¾à¤²à¥€à¤®à¤¾ à¤¦à¥‡à¤–à¤¾à¤‡à¤¨à¥‡ à¤›â€‹à¥¤</p>\r\n', 'images/news/1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `ourlinks`
--

CREATE TABLE IF NOT EXISTS `ourlinks` (
  `ourlinksID` int(11) NOT NULL AUTO_INCREMENT,
  `ourlinksName` varchar(400) NOT NULL,
  `ourlinksName1` varchar(200) NOT NULL,
  `ourlinksLink` text NOT NULL,
  PRIMARY KEY (`ourlinksID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ourlinks`
--

INSERT INTO `ourlinks` (`ourlinksID`, `ourlinksName`, `ourlinksName1`, `ourlinksLink`) VALUES
(1, 'link 1', 'à¤²à¤¿à¤‚à¤• à¥§', 'https://www.hitechskills.com');

-- --------------------------------------------------------

--
-- Table structure for table `programs`
--

CREATE TABLE IF NOT EXISTS `programs` (
  `programsID` int(11) NOT NULL AUTO_INCREMENT,
  `programsName` varchar(200) NOT NULL,
  `programsName1` varchar(200) NOT NULL,
  `programsDesc` text NOT NULL,
  `programsDesc1` text NOT NULL,
  PRIMARY KEY (`programsID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `publications`
--

CREATE TABLE IF NOT EXISTS `publications` (
  `publicationsID` int(11) NOT NULL AUTO_INCREMENT,
  `publicationsName` varchar(200) NOT NULL,
  `publicationsName1` varchar(200) NOT NULL,
  `publicationsDesc` text NOT NULL,
  `publicationsDesc1` text NOT NULL,
  PRIMARY KEY (`publicationsID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `registrarmessage`
--

CREATE TABLE IF NOT EXISTS `registrarmessage` (
  `registrarmessageID` int(11) NOT NULL AUTO_INCREMENT,
  `registrarmessageName` varchar(200) NOT NULL,
  `registrarmessageName1` varchar(200) NOT NULL,
  `registrarmessageDesc` text NOT NULL,
  `registrarmessageDesc1` text NOT NULL,
  `registrarmessageImagePath` text NOT NULL,
  PRIMARY KEY (`registrarmessageID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `sliderimage`
--

CREATE TABLE IF NOT EXISTS `sliderimage` (
  `sliderimageID` int(11) NOT NULL AUTO_INCREMENT,
  `sliderimageImagePath` text NOT NULL,
  PRIMARY KEY (`sliderimageID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `sliderimage`
--

INSERT INTO `sliderimage` (`sliderimageID`, `sliderimageImagePath`) VALUES
(1, 'images/bigslider/1.jpg'),
(3, 'images/bigslider/2s.jpg'),
(4, 'images/bigslider/3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `staffID` int(11) NOT NULL AUTO_INCREMENT,
  `staffTitle` varchar(200) NOT NULL,
  `staffTitle1` varchar(300) NOT NULL,
  `staffName` varchar(400) NOT NULL,
  `staffName1` varchar(400) NOT NULL,
  `staffImage` text NOT NULL,
  PRIMARY KEY (`staffID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staffID`, `staffTitle`, `staffTitle1`, `staffName`, `staffName1`, `staffImage`) VALUES
(2, 'CEO', 'à¤¸à¥€ à¤ˆ à¤“', 'Dhiraj Jha', 'à¤§à¤¿à¤°à¤œ à¤à¤¾', 'images/staff/residential.png');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
include('cms_admin/connect1.php');
$val="";
$pgnm="organization.php";
////////////////////////////////////////////// FOR NEPALI CONTENTS ///////////////////////////////////
 if((isset($_GET['contType']))=="nep"){
	$val="nep";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	 <title>पि.आर.एम.दि - संस्था</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<h3> संस्था<!-- Organization --></h3>
		<div class="row">
			<div class="col-md-4">
				<div class="custom-wellwell">
					<ul>
					<?php 
					$sql1="select * from organization;";
					$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
					while ($row1=mysqli_fetch_array($result1)) {
						$organizationid=$row1['organizationID'];
						$organizationname1=$row1['organizationName1'];
						?>
						<li><a href="<?php echo "#".$organizationname1; ?>"><?php echo $organizationname1; ?></a></li>
						<?php
					}
					?>						
					</ul>
				</div>
			</div>
		</div>
		<?php 
		$sql2="select * from organization;";
		$result2=mysqli_query($connect,$sql2) or die("Error in Mysql :".mysqli_error($connect));
		while ($row2=mysqli_fetch_array($result2)) {
			$orgid=$row2['organizationID'];
			$orgname1=$row2['organizationName1'];
			$orgdesc1=$row2['organizationDesc1'];
			$orgImg=$row2['organizationImagePath'];
		?>
				<div id="<?php echo $orgname1; ?>">
					<h4><?php echo $orgname1; ?></h4>
					<div class="row">
						<div class="col-md-12" align="center">
							<a href="<?php echo $orgImg;?>" target="_blank"><img src="<?php echo $orgImg;?>" alt="<?php echo $orgname1; ?>" class="img-thumbnail"></a>
							<p><?php echo $orgdesc1; ?></p>
						</div>
					</div>
				</div>
			<?php
			}
		?>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
}
////////////////////////////////////////////// FOR ENGLISH CONTENTS ///////////////////////////////////
else{
	$val="eng";
	?>
	<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>PRMD - Organization</title>
	<!-- <title>पि.आर.एम.दि - संस्था</title> -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<h3>Organization  <!-- संस्था --></h3>
		<div class="row">
			<div class="col-md-4">
				<div class="custom-wellwell">
					<ul>
					<?php 
					$sql1="select * from organization;";
					$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
					while ($row1=mysqli_fetch_array($result1)) {
						$organizationid=$row1['organizationID'];
						$organizationname1=$row1['organizationName'];
						?>
						<li><a href="<?php echo "#".$organizationname1; ?>"><?php echo $organizationname1; ?></a></li>
						<?php
					}
					?>						
					</ul>
				</div>
			</div>
		</div>
		<?php 
		$sql2="select * from organization;";
		$result2=mysqli_query($connect,$sql2) or die("Error in Mysql :".mysqli_error($connect));
		while ($row2=mysqli_fetch_array($result2)) {
			$orgid=$row2['organizationID'];
			$orgname1=$row2['organizationName'];
			$orgdesc1=$row2['organizationDesc'];
			$orgImg=$row2['organizationImagePath'];
		?>
				<div id="<?php echo $orgname1; ?>">
					<h4><?php echo $orgname1; ?></h4>
					<div class="row">
						<div class="col-md-12" align="center">
							<a href="<?php echo $orgImg;?>" target="_blank"><img src="<?php echo $orgImg;?>" alt="<?php echo $orgname1; ?>" class="img-thumbnail"></a>
							<p><?php echo $orgdesc1; ?></p>
						</div>
					</div>
				</div>
			<?php
			}
		?>	
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
	<?php
}
?>
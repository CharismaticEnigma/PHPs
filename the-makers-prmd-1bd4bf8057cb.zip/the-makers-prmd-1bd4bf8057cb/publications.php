<?php
include('cms_admin/connect1.php');
$val="";
$pubTypes;
$pgnm="publications.php";
$pubTypes=$_GET['publicationtype'];


//echo $pubTypes;
////////////////////////////////////////////// FOR NEPALI CONTENTS ///////////////////////////////////
 if((isset($_GET['contType']))=="nep"){
	$val="nep";

	
	if ($pubTypes=="Download"){
		$pubtype1="डाउन्लोड";
	}
	if ($pubTypes=="Report"){
		$pubtype1="प्रतिवेदन";
	}
	if ($pubTypes=="Booklet"){
		$pubtype1="पुस्तिका र पत्र";
	}
	if ($pubTypes=="Form"){
		$pubtype1="फारम";
	}
	if ($pubTypes=="Others"){
		$pubtype1="अन्य";
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>पि.आर.एम.दि - प्रकाशन</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<div class="row">
			<div class="col-md-9">
				<h3><?php echo $pubtype1; ?></h3>
				<!-- <h3>Report प्रतिवेदन</h3>
				<h3>Booklet & Leaflets पुस्तिका र पत्र</h3>
				<h3>Forms फारम</h3>
				<h3>Others अन्य</h3> -->
				<table class="table table-hover">
					<tr>
						<td><strong>शीर्षक</strong></td>
						<td><strong>लिंक​</strong></td>
					</tr>
					<?php
					$sql1="select * from publications where publicationsType='$pubTypes';";
					$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
					while($row1=mysqli_fetch_array($result1)){
						$pubName1=$row1['publicationsName1'];
						$pubdownloadlink=$row1['publicationsDownloadLink'];
						?>
						<tr>
						<td><?php echo $pubName1; ?></td>
						<td><a href="<?php echo $pubdownloadlink;?>" class="btn btn-success">डाउन्लोड</a></td>
					</tr>
						<?php
					}
					?>
				</table>
			</div>
			<div class="col-md-3">
				<?php include('include/sidebar.php'); ?>
			</div>
		</div>		
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
}
////////////////////////////////////////////// FOR ENGLISH CONTENTS ///////////////////////////////////
else{
	$val="eng";
	?>

	<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>PRMD - Publications</title>
	<!-- <title>पि.आर.एम.दि - प्रकाशन</title> -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<div class="row">
			<div class="col-md-9">
				<h3>Downloads <!-- डाउन्लोड --></h3>
				<!-- <h3>Report प्रतिवेदन</h3>
				<h3>Booklet & Leaflets पुस्तिका र पत्र</h3>
				<h3>Forms फारम</h3>
				<h3>Others अन्य</h3> -->
				<table class="table table-hover">
					<tr>
						<td><strong>Title</strong></td>
						<td><strong>Link</strong></td>
						<!-- <td><strong>शीर्षक</strong></td>
						<td><strong>लिंक​</strong></td> -->
					</tr>
					<?php
					$sql1="select * from publications where publicationsType='$pubTypes';";
					$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
					while($row1=mysqli_fetch_array($result1)){
						$pubName=$row1['publicationsName'];
						$pubdownloadlink=$row1['publicationsDownloadLink'];
						?>
						<tr>
						<td><?php echo $pubName; ?></td>
						<td><a href="<?php echo $pubdownloadlink;?>" class="btn btn-success">Download</a></td>
					</tr>
						<?php
					}
					?>
				</table>
			</div>
			<div class="col-md-3">
				<?php include('include/sidebar.php'); ?>
			</div>
		</div>		
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>

<?php

}
?>
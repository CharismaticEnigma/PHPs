<?php
include("connect.php");
	if(!isset($_SESSION['Login_Name'])){
		header("Location:index.php");
		exit();
	}

else{ 

?>

<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css" />	       					
			<?php
			$q10 =$_GET['q10'];
			$atableID=$_GET['q12'];
			$tablename= $_GET['q11'];
			//$atableID=$tablename."ID";
			$atableTitle=$tablename."Name";
			$atableDesc=$tablename."Desc"; 
			$atableTitle1=$tablename."Name1";
			$atableDesc1=$tablename."Desc1"; 
					
			
			
           	$query2="select * from $tablename where $atableID='$q10'";	
			$result2 = mysqli_query($connect,$query2);
				//$row1 = mysql_num_rows($result2 );
				//if($row1>0){
					while($row2=mysqli_fetch_array($result2)){
					?>							
			
	          <table border="2px" width="300px">
					<br>

					<tr>
						<td> Title: </td>
						<td ><?php echo $row2[$atableTitle]?></td>
					</tr>
					<tr>
						<td> Title (Nepali): </td>
						<td ><?php echo $row2[$atableTitle1]?></td>
					</tr>
					<tr>
						<td> Description: </td>
						<td><?php echo $row2[$atableDesc]?></td>
					</tr>
					<tr>
						<td> Description (Nepali): </td>
						<td><?php echo $row2[$atableDesc1]?></td>
					</tr>
											
						
			    </table> 
				<br> 
						
               <?php
			   			}			
					//}
				}
					
            	?>
          
      
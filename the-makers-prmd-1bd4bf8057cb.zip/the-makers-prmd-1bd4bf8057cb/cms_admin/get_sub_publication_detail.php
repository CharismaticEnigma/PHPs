<?php
include("connect.php");
	if(!isset($_SESSION['Login_Name'])){
		header("Location:index.php");
		exit();
	}

else{ 

?>

<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css" />	       					
			<?php
			$q2 =$_GET['q2'];		
			
           $query2="select * from publications where publicationsID='$q2'";	
			$result2 = mysqli_query($connect,$query2);
				$row1 = mysqli_num_rows($result2 );
				if($row1>0){
					while($row2=mysqli_fetch_array($result2)){
					?>	
						
			
          <table border="2px" width="300px">
				<br>

					<tr>
						<td> Sub Name: </td>
						<td ><?php echo $row2['publicationsName']?></td>
					</tr>
					<tr>
						<td> Sub Name (Nepali): </td>
						<td ><?php echo $row2['publicationsName1']?></td>
					</tr>
					<tr>
						<td> File Name: </td>
						<td><?php echo $row2['publicationsDownloadLink']?></td>
					</tr>
										
					
		    </table> 
			<br> 
						
               <?php
			   			}			
					}
			}
					
            	?>
          
      
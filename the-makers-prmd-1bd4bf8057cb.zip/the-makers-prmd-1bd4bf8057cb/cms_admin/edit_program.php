<?php
include("connect.php");

  if(!isset($_SESSION['Login_Name'])){
    header("Location:index.php");
    exit();
  }

else{ 
if(isset($_POST['update'])){
    if(isset($_POST['uptitle'])){
      $titleVal=$_POST['uptitle'];
      $sql="Update programs set programsName='$titleVal' where programsID=1;";
      $query=mysqli_query($connect,$sql) or die("Error in Mysql query: ". mysqli_error($connect));
    }
    if(isset($_POST['updesc'])){
      $descVal=$_POST['updesc'];
      $sql="Update programs set programsDesc='$descVal' where programsID=1;";
      $query=mysqli_query($connect,$sql) or die("Error in Mysql query: ". mysqli_error($connect));
    }
     if(isset($_POST['uptitle1'])){
      $titleVal1=$_POST['uptitle1'];
      $sql="Update programs set programsName1='$titleVal1' where programsID=1;";
      $query=mysqli_query($connect,$sql) or die("Error in Mysql query: ". mysqli_error($connect));
    }
    if(isset($_POST['updesc1'])){
      $descVal1=$_POST['updesc1'];
      $sql="Update programs set programsDesc1='$descVal1' where programsID=1;";
      $query=mysqli_query($connect,$sql) or die("Error in Mysql query: ". mysqli_error($connect));
    }
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Edit Program</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css" />
<script src="ckeditor/ckeditor.js"> </script>
</head>

<body>
<div id="wrapper">
<div style="text-align:right;"><a href="logout.php" style="font-size:20px; text-decoration:none;" > Logout </a></div>
<div class="header"><a href="#" style="text-decoration:none; color:#333;">Edit Program</a></div>
<div class="header2">
   <?php
 include('class/menu.php');
 ?>
</div>

    


 <div class="form2">
 

       
          <form method="post" action="">
      <?php   
   $sql2="select * from programs where programsID=1";
   $res2=mysqli_query($connect,$sql2) or die ("error in mysql :".mysqli_error($connect));
  $row2=mysqli_fetch_array($res2);
 
   
   ?>    <table>
            <tr>
                <td> Program Title: </td>
                <td> <input type="text" name="uptitle" value="<?php echo $row2['programsName']?>" placeholder="Update Title"></td>
            </tr>
            <tr>
                <td> Program Title (Nepali): </td>
                <td> <input type="text" name="uptitle1" value="<?php echo $row2['programsName1']?>" placeholder="Update Title"></td>
            </tr>
            <tr>
               <td>Description: </td>
               <td> <textarea  class="ckeditor"  name="updesc"><?php echo $row2['programsDesc']?></textarea></td>
            </tr> 
            <tr>
               <td>Description (Nepali): </td>
               <td> <textarea  class="ckeditor"  name="updesc1"><?php echo $row2['programsDesc1']?></textarea></td>
            </tr>          
         </table>     



  
<input type="submit" name="update" value="Update" /></form>
          
          </div>
    </div>
  
    </div>
</div>

</body>
</html>
<?php
}
?>
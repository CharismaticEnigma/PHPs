<?php
include("connect.php");
include("class/publicationpage.class.php");
$pubType="";


	if(!isset($_SESSION['Login_Name'])){
		header("Location:index.php");
		exit();
	}

else{ 

		if(isset($_POST['delete'])){
		$Publicationpage -> deletePublication();
		}

		if(isset($_POST['edit'])){
		$Publicationpage -> editPublication();
		}
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Publication</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css" />
<script src="ckeditor/ckeditor.js"> </script>
<style type="text/css">
th{background-color:#999;}
</style>
</head>

<body>
<div id="wrapper">
<div style="text-align:right;"><a href="logout.php" style="font-size:20px; text-decoration:none;" > Logout </a></div>
<div class="header"><a href="#" style="text-decoration:none; color:#333;">Edit/Delete Publication</a></div>
<div class="header2">
   <?php
 include('class/menu.php');
 ?>
</div>


  <div class="form2">
  <form method="post" action="" enctype="multipart/form-data">
 
  <br /><br />
  
  <?php
   $a=$_GET['ed'];
   ?>
   
   <table border="2px" width="300px">
	
	<tr>
		<td> Page Title: </td>
		<td ><?php echo $a ?></td>
	</tr>
	
	
	</table><br>
   
  
  
  <script>
					function showUser(str)
					{
					if (str=="")
					  {
					  document.getElementById("txtHint2").innerHTML="";
					  return;
					  } 
					if (window.XMLHttpRequest)
					  {// code for IE7+, Firefox, Chrome, Opera, Safari
					  xmlhttp=new XMLHttpRequest();
					  }
					else
					  {// code for IE6, IE5
					  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
					  }
					xmlhttp.onreadystatechange=function()
					  {
					  if (xmlhttp.readyState==4 && xmlhttp.status==200)
						{
						document.getElementById("txtHint2").innerHTML=xmlhttp.responseText;
						}
					  }
					xmlhttp.open("GET","get_sub_publication_detail.php?q2="+str,true);
					xmlhttp.send();
					}
			</script> 

  
  
 <?php
 echo $a;
 	$query = "SELECT * FROM publications where publicationsType='$a';";
	if($result = mysqli_query($connect,$query))  {

      // If there are results returned, prepare combo-box
      if($success = mysqli_num_rows($result) > 0) {

	  
      
        // Start combo-box
        echo "<select name='publicationid' onchange='showUser(this.value)' style='height:30px; font-size:16px;'>\n";
		echo "<option >-- Sub Heading --</option>\n";
		
		
        
 // For each item in the results...
        while ($row = mysqli_fetch_array($result))
        	
          // Add a new option to the combo-box
          echo "<option value='$row[publicationsID]'>$row[publicationsName]</option>\n";

        // End the combo-box
        echo "</select>\n";
      }
      // No results found in the database
       else { echo "<a href='#'>No results found. Reload</a>"; }
    }
    // Error in the database
    else { echo "Failed to connect to database."; }

     
 ?> 
  <br>
 	<span id="txtHint2">  </span>
	<?php
	//$query = "SELECT * FROM servicesub where headingID='$a';";
	//$sql1= mysql_query($query) or die("error in sql :" .mysql_error());
	//if($row1=mysql_fetch_array($sql1)){
	

	?>
	<table>
		<tr>
			<td>Name:</td>
			<td><input type="text" name="upsubname"><br></td>
		</tr>
		<tr>
			<td>Name (Nepali):</td>
			<td><input type="text" name="upsubname1"><br></td>
		</tr>
		 <tr>
            <td>File: </td>
            <td>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="newsimg" /></td>
        </tr>
        <tr style="display:none" >
			<td>ptype:</td>
			<td><input type="text" value="<?php echo $a;?>" name="pType"><br></td>
		</tr>
		
		
	</table>
	<?php
	//}
	
	
	?>
	<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
 <input type="submit" name="edit" value="Edit" /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" name="delete" value="Delete" /></form> 
<?
header('location:edit_delete_sub_publication.php?ed='.$a);
?>

</div>
</body>
</html>
<?php
}
?>
<?php
	include("connect.php");
		
		if(!isset($_SESSION['Login_Name'])){
		header("Location:index.php");
		exit();
	}

else{ 
	
	$imgID=$_GET['dele'];

		if(isset($imgID)){
			$sql1="Select * from organization where organizationID='$imgID';";
			$res=mysqli_query($connect,$sql1);
			while($row1 = mysqli_fetch_array($res))
			{
 				 $imgs=$row1['organizationImagePath'];
 				 if ($imgs!="images/organization") {
 				 	$arr=array();
 				 	$arr= (explode ("/",$imgs));
 				 	chdir("../images/organization");
 					unlink($arr[2]);
 				 }
 				 
 			}
		$sql= "delete from organization where organizationID='$imgID';";		
		mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
			
		header('location:edit_delete_organization.php');
		
		}
	}
		?>
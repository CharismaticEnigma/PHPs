<?php
class Publicationpage
{
	function insertPublication(){
		include("connect1.php");
	
		$name=$_POST['tendername'];		
		$name1=$_POST['tendername1'];	
		$type=$_POST['tdtype'];


		//the php script to upload the image
		$imagename = $_FILES["newsimg"]["name"];
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		//path to put into the database table
		if($type=='Download'){
			$path = "images/publications/download/$imagename";	
			//actual server destination folder
			$dest = "../images/publications/download/$imagename";
		}
		else if($type=='Report'){
			$path = "images/publications/report/$imagename";	
			//actual server destination folder
			$dest = "../images/publications/report/$imagename";
		}
		else if($type=='Booklet'){
			$path = "images/publications/booklet/$imagename";	
			//actual server destination folder
			$dest = "../images/publications/booklet/$imagename";
		}
		else if($type=='Form'){
			$path = "images/publications/form/$imagename";	
			//actual server destination folder
			$dest = "../images/publications/form/$imagename";
		}
		else if($type=='Others'){
			$path = "images/publications/others/$imagename";	
			//actual server destination folder
			$dest = "../images/publications/others/$imagename";
		}

		$arr = explode(".",$imagename);
		//check whether the extention is correct
		$ext = $arr[1];
		//echo $tmpimage;
		
		if( ($ext=='pdf') or($ext=='PDF'))
		{	
				//copy the temporarily uploaded file to the server destination (actual upload)
			if(file_exists($dest)){
				echo "a file with that name already exists.. Please change your file";	
			}
			else
			{


				copy($tmpimage,$dest);
				$sql= "insert into publications (publicationsType, publicationsName,publicationsName1, publicationsDownloadLink) values ('$type', '$name','$name1', '$path');";
		
				mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
				echo "data sucessfully added";		
				
			}	
		}
		else
		{
			echo "invalid file! try again.<a href='javascript:history.back()'> Click here to Go back </a>";
			exit;
		}
		//script ends		
	}


	function editPublication(){
		include("connect1.php");

		$id=$_POST['publicationid'];
		$nm=$_POST['upsubname'];
		$nm1=$_POST['upsubname1'];
		$type=$_POST['pType'];
		
		

		if(isset($nm) && $id!="-- Sub Heading --" && $nm!=Null){
			$sqlup=mysqli_query($connect, "Update publications Set publicationsName='$nm' where publicationsID='$id'");	
		}
		if(isset($nm1) && $id!="-- Sub Heading --" && $nm1!=Null){
			$sqlup=mysqli_query($connect, "Update publications Set publicationsName1='$nm1' where publicationsID='$id'");	
		}

		//the php script to upload the image
		
		$imagename = $_FILES["newsimg"]["name"];
		$tmpimage = $_FILES["newsimg"]["tmp_name"];
		//path to put into the database table
		if($type=='Download'){
			$path = "images/publications/download/$imagename";	
			//actual server destination folder
			$dest = "../images/publications/download/$imagename";

		}
		else if($type=='Report'){
			$path = "images/publications/report/$imagename";	
			//actual server destination folder
			$dest = "../images/publications/report/$imagename";
		}
		else if($type=='Booklet'){
			$path = "images/publications/booklet/$imagename";	
			//actual server destination folder
			$dest = "../images/publications/booklet/$imagename";
		}
		else if($type=='Form'){
			$path = "images/publications/form/$imagename";	
			//actual server destination folder
			$dest = "../images/publications/form/$imagename";
		}
		else if($type=='Others'){
			$path = "images/publications/others/$imagename";	
			//actual server destination folder
			$dest = "../images/publications/others/$imagename";
		}

		
		
		if (isset($imagename) && $id!="-- Sub Heading --" && $imagename!=Null)
		{

			$arr = explode(".",$imagename);
			//check whether the extention is correct
			$ext = $arr[1];
		
			if(($ext=='pdf') or($ext=='PDF'))
			{	

				if(file_exists($dest)){
				echo "an image with that name already exists.. Please change your file";
			}
			else{
				if(isset($path) && $path !=Null){

				$sql1="Select * from publications where publicationsID='$id';";
				$res=mysqli_query($connect,$sql1);
				while($row1 = mysqli_fetch_array($res))
				{
 					$imgs=$row1['publicationsDownloadLink'];
 				 	$arr=array();
 				 	$arr= (explode ("/",$imgs));
 				 	$cdr=getcwd();
 				 	$lowerString=strtolower($type);
 				 	chdir("../images/publications/".$lowerString);
 					unlink($arr[3]);
 				}
 				chdir($cdr);
	 			copy($tmpimage,$dest);

				$sqlup=mysqli_query($connect,"Update publications Set publicationsDownloadLink='$path' where publicationsID='$id';");	

					}
				//copy the temporarily uploaded file to the server destination (actual upload)
				}
			}
			else
			{
				echo "invalid file! try again.<a href='javascript:history.back()'> Click here to Go back </a>";
				exit;
			}	
		}		
}

function deletePublication(){
		include("connect1.php");
		
		 $id=$_POST['publicationid'];
		
		
				$sql1="Select * from publications where publicationsID='$id';";
				$res=mysqli_query($connect,$sql1);
				if($row1 = mysqli_fetch_array($res))
				{
	 				 $imgs=$row1['publicationsDownloadLink'];
	 				 	 				
	 				$arr=array();
	 				 $arr= (explode ("/",$imgs));
	 				 $url="../$arr[0]/$arr[1]/$arr[2]/";
	 			 	chdir($url);
	 			 	unlink($arr[3]);
	 			 	$sql= "delete from publications where publicationsID='$id';";			
					 mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
					 echo "data sucessfully deleted";
	 			}	
	 		
	}


}
$Publicationpage = new Publicationpage();
?>
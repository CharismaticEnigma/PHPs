<?php
class Organizationpage
{
	function addOrganization(){
		$neName=$_POST['arnm'];	
		$iDesc=$_POST['ardesc'];
		$neName1=$_POST['arnm1'];	
		$iDesc1=$_POST['ardesc1'];
		if($iDesc==Null){
			$iDesc=" ";
		}
		if($iDesc1==Null){
			$iDesc1=" ";
		}
		include("connect1.php");	

		//the php script to upload the image
		$imagename = $_FILES["newsimg"]["name"];
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		//path to put into the database table
		$path = "images/organization/$imagename";
		
		//actual server destination folder
		$dest = "../images/organization/$imagename";
		$arr = explode(".",$imagename);
		//check whether the extention is correct
		$ext = $arr[1];
		
		if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG') or($ext==''))
		{	
			if($ext=='')
			{

				$sql= "insert into organization (organizationName,organizationName1, organizationDesc,organizationDesc1,organizationImagePath) values ('$neName','$neName1','$iDesc','$iDesc1','images/organization');";

		
				mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
				echo "data sucessfully added";
			}
			elseif(file_exists($dest)){
					echo "an image with that name already exists.. Please change your file";
				}
			else{

				//copy the temporarily uploaded file to the server destination (actual upload)
				copy($tmpimage,$dest);
				
				//@rename($dest,"../studpics/$id.$ext");


				$sql= "insert into organization (organizationName,organizationName1, organizationDesc,organizationDesc1,organizationImagePath) values ('$neName','$neName1','$iDesc','$iDesc1','$path');";
		
				mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
				echo "data sucessfully added";
			}
		
		}
		else
		{
			echo "invalid photo! try again.<a href='javascript:history.back()'> Click here to Go back </a>";
			exit;
		}
				//upload script ends.
					
		//header('location:newsadd.php');
	}
	
	
	function editOrganization(){
		$hid=$_POST['hid'];
		$iID=$_POST['iid'];
		$desc=$_POST['desc'];
		$iID1=$_POST['iid1'];
		$desc1=$_POST['desc1'];
		include("connect1.php");

		if(isset($iID) && $iID !=Null){
			$sqlup=mysqli_query($connect,"Update organization Set organizationName='$iID' where organizationID='$hid'");	
		}
		if(isset($desc)&& $desc !=Null){
			$sqlup=mysqli_query($connect,"Update organization Set organizationDesc='$desc' where organizationID='$hid'");	
		}
		if(isset($iID1) && $iID1 !=Null){
			$sqlup=mysqli_query($connect,"Update organization Set organizationName1='$iID1' where organizationID='$hid'");	
		}
		if(isset($desc)&& $desc !=Null){
			$sqlup=mysqli_query($connect,"Update organization Set organizationDesc1='$desc1' where organizationID='$hid'");	
		}
		
		
		//the php script to upload the image
		
		$imagename = $_FILES["newsimg"]["name"];
		//echo $imagename;
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		//path to put into the database table
		$path = "images/organization/$imagename";
		
		//actual server destination folder
		$dest = "../images/organization/$imagename";
		//echo "Destination: ".$dest;
		
		if (isset($imagename) && $imagename!= Null)
		{
		
		$arr = explode(".",$imagename);
		//check whether the extention is correct
		$ext = $arr[1];
		
		if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG') or($ext==''))
		{	
				if(file_exists($dest)){
			echo "an image with that name already exists.. Please change your file";
		}
		else{
			if(isset($path) && $path !=Null){

			$sql1="Select * from organization where organizationID='$hid';";
			$res=mysqli_query($connect,$sql1);
			while($row1 = mysqli_fetch_array($res))
			{
 				$imgs=$row1['organizationImagePath'];
 				if ($imgs!="images/organization") {
 					$arr=array();
 				 	$arr= (explode ("/",$imgs));
 				 	$cdr=getcwd();
 				 	chdir("../images/organization");
 					unlink($arr[2]);
 				}
 				
 			}
 			if (isset($cdr)) {
 				chdir($cdr);
 			}
 			
 			//echo "Recent dir: ".getcwd();
 			copy($tmpimage,$dest);
			$sqlup=mysqli_query($connect,"Update organization Set organizationImagePath='$path' where organizationID='$hid'");	

		}
			//copy the temporarily uploaded file to the server destination (actual upload)
		}
		}
		else
		{
			echo "invalid photo! try again.<a href='javascript:history.back()'> Click here to Go back </a>";
			exit;
		}	
		}		
		
		//echo "Data updated successfully";
		
	}
	
	
	
	
	}
	
	$Organizationpage = new Organizationpage();
	?>
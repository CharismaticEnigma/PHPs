<?php
class Registrarmessagepage
{
	function editWelcomeMessage(){

		$name=$_POST['upname'];
		$desc=$_POST['updesc'];
		$name1=$_POST['upname1'];
		$desc1=$_POST['updesc1'];
		include("connect1.php");

	if(isset($_POST['upname'])){
      $sql="Update registrarmessage set registrarmessageName='$name'  where registrarmessageID='1';";
      $query=mysqli_query($connect,$sql) or die("Error in Mysql query: ". mysqli_error($connect));
    }
    if(isset($_POST['updesc'])){
      $sql="Update registrarmessage set registrarmessageDesc='$desc' where registrarmessageID='1';";
      $query=mysqli_query($connect,$sql) or die("Error in Mysql query: ". mysqli_error($connect));
    }
    if(isset($_POST['upname1'])){
      $sql="Update registrarmessage set registrarmessageName1='$name1' where registrarmessageID='1';";
      $query=mysqli_query($connect,$sql) or die("Error in Mysql query: ". mysqli_error($connect));
    }
    if(isset($_POST['updesc1'])){
      $sql="Update registrarmessage set registrarmessageDesc1='$desc1' where registrarmessageID='1';";
      $query=mysqli_query($connect,$sql) or die("Error in Mysql query: ". mysqli_error($connect));
    }
	}

	function editRegistrarMessage(){

		$name=$_POST['upname'];
		$desc=$_POST['updesc'];
		$name1=$_POST['upname1'];
		$desc1=$_POST['updesc1'];
		include("connect1.php");

	if(isset($_POST['upname'])){
      $sql="Update registrarmessage set registrarmessageName='$name' where registrarmessageID='2';";
      $query=mysqli_query($connect,$sql) or die("Error in Mysql query: ". mysqli_error($connect));
    }
    if(isset($_POST['updesc'])){
      $sql="Update registrarmessage set registrarmessageDesc='$desc' where registrarmessageID='2';";
      $query=mysqli_query($connect,$sql) or die("Error in Mysql query: ". mysqli_error($connect));
    }
    if(isset($_POST['upname1'])){
      $sql="Update registrarmessage set registrarmessageName1='$name1' where registrarmessageID='2';";
      $query=mysqli_query($connect,$sql) or die("Error in Mysql query: ". mysqli_error($connect));
    }
    if(isset($_POST['updesc1'])){
      $sql="Update registrarmessage set registrarmessageDesc1='$desc1' where registrarmessageID='2';";
      $query=mysqli_query($connect,$sql) or die("Error in Mysql query: ". mysqli_error($connect));
    }

    	//the php script to upload the image
		
		$imagename = $_FILES["newsimg"]["name"];
		//echo $imagename;
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		//path to put into the database table
		$path = "images/staff/registrar/$imagename";
		
		//actual server destination folder
		$dest = "../images/staff/registrar/$imagename";
		//echo "Destination: ".$dest;
		
		if (isset($imagename) && $imagename!= Null)
		{
		
		$arr = explode(".",$imagename);
		//check whether the extention is correct
		$ext = $arr[1];
		
		if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG') or($ext==''))
		{	
				if(file_exists($dest)){
			echo "an image with that name already exists.. Please change your file";
		}
		else{
			if(isset($path) && $path !=Null){

			$sql1="Select * from registrarmessage where registrarmessageID='2';";
			$res=mysqli_query($connect,$sql1);
			while($row1 = mysqli_fetch_array($res))
			{
 				 //echo $row1['headingImagePath'];
 				 $imgs=$row1['registrarmessageImagePath'];
 				 //echo $imgs;
 				 //echo $row1['headingImageName'];
 				$arr=array();
 				 $arr= (explode ("/",$imgs));
 				 //echo $arr[2];
 				 $cdr=getcwd();
 				 chdir("../images/staff/registrar");
 				unlink($arr[3]);
 			}
 			chdir($cdr);
 			//echo "Recent dir: ".getcwd();
 			copy($tmpimage,$dest);
			$sqlup=mysqli_query($connect,"Update registrarmessage Set registrarmessageImagePath='$path' where registrarmessageID='2'");	

		}
			//copy the temporarily uploaded file to the server destination (actual upload)
		}
		}
		else
		{
			echo "invalid photo! try again.";
			exit;
		}	
		}



	}
	
}
	
	$Registrarmessagepage = new Registrarmessagepage();
	?>



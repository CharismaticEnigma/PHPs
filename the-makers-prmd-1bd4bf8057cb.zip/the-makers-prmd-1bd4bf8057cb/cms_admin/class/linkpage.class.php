<?php
class Linkpage
{
	function insertLink(){
	
		$name=$_POST['linkname'];		
		$name1=$_POST['linkname1'];
		$link=$_POST['ourlink'];
		include("connect1.php");
		$sql= "insert into ourlinks (ourlinksName,ourlinksName1,ourlinksLink) values ('$name','$name1','$link');";
		mysqli_query($connect, $sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
		echo "data sucessfully added";
	
				}

	function editLink(){

		$id=$_POST['id'];
		$nm=$_POST['nm'];
		$nm1=$_POST['nm1'];
		$link=$_POST['lnk'];

		include("connect1.php");

		if(isset($nm) && $nm !=Null){
			$sqlup=mysqli_query($connect, "Update ourlinks Set ourlinksName='$nm' where ourlinksID='$id'");	
		}
		if(isset($nm1) && $nm1 !=Null){
			$sqlup=mysqli_query($connect, "Update ourlinks Set ourlinksName1='$nm1' where ourlinksID='$id'");	
		}
		if(isset($link)&& $link !=Null){
			$sqlup=mysqli_query($connect, "Update ourlinks Set ourlinksLink='$link' where ourlinksID='$id'");	
		}

		
}
}
$Linkpage = new Linkpage();
?>
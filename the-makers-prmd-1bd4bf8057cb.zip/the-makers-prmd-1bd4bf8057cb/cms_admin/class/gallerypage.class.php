<?php
class Gallerypage
{
	
	
	
	function insertGalleryImage(){
		$iName=$_POST['iname'];	
		$iName1=$_POST['iname1'];	
		$ext="";
		
		//the php script to upload the image
		$imagename = $_FILES["newsimg"]["name"];
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		//path to put into the database table
		$path = "images/gallery/$imagename";
		
		//actual server destination folder
		$dest = "../images/gallery/$imagename";
		if($imagename!=null || $imagename!=""){
			$arr = explode(".",$imagename);
			//check whether the extention is correct
			$ext = $arr[1];	
		}
		
		
		if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG') or($ext==''))
		{	
			if($ext==""){
				echo "Please select an image befor proceeding";
			}
			elseif(file_exists($dest)){
					echo "an image with that name already exists.. Please change your file";
				}
			else{
				//copy the temporarily uploaded file to the server destination (actual upload)
				copy($tmpimage,$dest);
				
				//@rename($dest,"../studpics/$id.$ext");
				include("connect1.php");

				$sql= "insert into galleryimage (galleryimageName,galleryimageName1, galleryimageImagePath) values ('$iName','$iName1','$path');";
		
				mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
				echo "data sucessfully added";
		
			}
		}
		else
		{
			echo "invalid photo! try again.";
			exit;
		}
				//upload script ends.		
			
		//header('location:gallery_image_add.php');
	}

function insertVideoGallery(){
	
		$name=$_POST['videoname'];		
		$name1=$_POST['videoname1'];
		$link=$_POST['videolink'];
		include("connect1.php");
		$sql= "insert into galleryvideo (galleryvideoName,galleryvideoName1,galleryvideoLink) values ('$name','$name1','$link');";
		mysqli_query($connect, $sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
		echo "data sucessfully added";
	
				}

	function editVideoGallery(){

		$id=$_POST['id'];
		$nm=$_POST['nm'];
		$nm1=$_POST['nm1'];
		$link=$_POST['lnk'];

		include("connect1.php");

		if(isset($nm) && $nm !=Null){
			$sqlup=mysqli_query($connect, "Update galleryvideo Set galleryvideoName='$nm' where galleryvideoID='$id'");	
		}
		if(isset($nm1) && $nm1 !=Null){
			$sqlup=mysqli_query($connect, "Update galleryvideo Set galleryvideoName1='$nm1' where galleryvideoID='$id'");	
		}
		if(isset($link)&& $link !=Null){
			$sqlup=mysqli_query($connect, "Update galleryvideo Set galleryvideoLink='$link' where galleryvideoID='$id'");	
		}
	}
	
	
}
$Gallerypage = new Gallerypage();
?>
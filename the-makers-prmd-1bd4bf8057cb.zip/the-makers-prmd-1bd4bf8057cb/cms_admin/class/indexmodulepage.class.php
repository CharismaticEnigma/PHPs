<?php
class Indexmodulepage
{


	function editIndexmodule()
	{
		include("connect1.php");
		$headid=$_POST['hedname'];
		$tablename=$_POST['tname'];
		$modulelink=$_POST['molink'];
		$atabletitle=$_POST['ttitle'];
		$atableid=$_POST['tid'];
		
		$sql1="select * from $tablename where $atableid='$headid' ;";
		$result1=mysqli_query($connect,$sql1);
		$sql="Select * from indexmodule where tablename='$tablename' and headingID='$headid';";
		$qr1=mysqli_query($connect,$sql) or die("error in mysqli: ".mysqli_error($connect));
		if(($row=mysqli_num_rows($qr1))>0){
			echo "This title has already been selected";
		}
		else{
				
		$sql2="insert into indexmodule (tableName,modLink, headingID) values ('$tablename','$modulelink','$headid');";
		mysqli_query($connect,$sql2) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));

}
}
}

$Indexmodulepage = new Indexmodulepage();
?>
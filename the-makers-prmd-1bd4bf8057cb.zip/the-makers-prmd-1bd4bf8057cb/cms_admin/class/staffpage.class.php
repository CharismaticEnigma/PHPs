<?php
class Staffpage
{
	function addStaff(){
		$sttl=$_POST['sttl'];	
		$stnm=$_POST['stnm'];
		$sttla=$_POST['sttla'];	
		$stnma=$_POST['stnma'];
		include("connect1.php");
		$ext="";	

		//the php script to upload the image
		$imagename = $_FILES["newsimg"]["name"];
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		//path to put into the database table
		$path = "images/staff/$imagename";
		
		//actual server destination folder
		$dest = "../images/staff/$imagename";
		if($imagename!=null || $imagename!=""){
			$arr = explode(".",$imagename);
			//check whether the extention is correct
			$ext = $arr[1];	
		}
		
		
		if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='JPEG') or ($ext=='jpeg') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG') or($ext==''))
		{	
			if($ext=='')
			{
				$sql= "insert into staff (staffTitle,staffTitle1, staffName,staffName1,staffImage) values ('$sttl','$sttla','$stnm','$stnma','images/staff');";

		
				mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
				echo "data sucessfully added";
			}
			elseif(file_exists($dest)){
					echo "an image with that name already exists.. Please change your file";
				}
			else{

				//copy the temporarily uploaded file to the server destination (actual upload)
				copy($tmpimage,$dest);
				
				//@rename($dest,"../studpics/$id.$ext");

				$sql= "insert into staff (staffTitle,staffTitle1, staffName,staffName1,staffImage) values ('$sttl','$sttla','$stnm','$stnma','$path');";
		
				mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
				echo "data sucessfully added";
			}
		
		}
		else
		{
			echo "invalid photo! try again.<a href='javascript:history.back()'> Click here to Go back </a>";
			exit;
		}
				//upload script ends.
					
		//header('location:newsadd.php');
	}
	
	
	function editStaff(){
		$hid=$_POST['hid'];
		$iID=$_POST['sid'];
		$desc=$_POST['snm'];
		$iID1=$_POST['sid1'];
		$desc1=$_POST['snm1'];
		include("connect1.php");

		if(isset($iID) && $iID !=Null){
			$sqlup=mysqli_query($connect,"Update staff Set staffTitle='$iID' where staffID='$hid'");	
		}
		if(isset($desc)&& $desc !=Null){
			$sqlup=mysqli_query($connect,"Update staff Set staffName='$desc' where staffID='$hid'");	
		}
		if(isset($iID1) && $iID1 !=Null){
			$sqlup=mysqli_query($connect,"Update staff Set staffTitle1='$iID1' where staffID='$hid'");	
		}
		if(isset($desc1)&& $desc1 !=Null){
			$sqlup=mysqli_query($connect,"Update staff Set staffName1='$desc1' where staffID='$hid'");	
		}
		
		
		//the php script to upload the image
		
		$imagename = $_FILES["newsimg"]["name"];
		//echo $imagename;
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		//path to put into the database table
		$path = "images/staff/$imagename";
		
		//actual server destination folder
		$dest = "../images/staff/$imagename";
		//echo "Destination: ".$dest;
		
		if (isset($imagename) && $imagename!= Null)
		{
		
		$arr = explode(".",$imagename);
		//check whether the extention is correct
		$ext = $arr[1];
		
		if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG') or($ext==''))
		{	
				if(file_exists($dest)){
			echo "an image with that name already exists.. Please change your file";
		}
		else{
			if(isset($path) && $path !=Null){

			$sql1="Select * from staff where staffID='$hid';";
			$res=mysqli_query($connect,$sql1);
			while($row1 = mysqli_fetch_array($res))
			{
 				$imgs=$row1['staffImage'];
 				if ($imgs!="images/staff") {
 					$arr=array();
	 				$arr= (explode ("/",$imgs));
	 				$cdr=getcwd();
	 				chdir("../images/staff");
	 				unlink($arr[2]);
 				}
 				
 			}
 			if (isset($cdr)) {
 				chdir($cdr);
 			}
 			
 			copy($tmpimage,$dest);
			$sqlup=mysqli_query($connect,"Update staff Set staffImage='$path' where staffID='$hid'");	

		}
			//copy the temporarily uploaded file to the server destination (actual upload)
		}
		}
		else
		{
			echo "invalid photo! try again.<a href='javascript:history.back()'> Click here to Go back </a>";
			exit;
		}	
		}		
		
		//echo "Data updated successfully";
		
	}
	
	
	
	
	}
	
	$Staffpage = new Staffpage();
	?>
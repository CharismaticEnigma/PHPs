<?php
include('cms_admin/connect1.php');
$val="";
$pgnm="index.php";
////////////////////////////////////////////// FOR NEPALI CONTENTS ///////////////////////////////////
 if((isset($_GET['contType']))=="nep"){
	$val="nep";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<!-- <title>PRMD</title> -->
	<title>पि.आर.एम.दि</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<div class="custom-well">
				<?php
				$sql1="select * from registrarmessage where registrarmessageID='1';";
				$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
				$row1=mysqli_fetch_array($result1);
				$welname1=$row1['registrarmessageName1'];
				$weldesc1=$row1['registrarmessageDesc1'];
				?>
					<h2><?php echo $welname1; ?></h2>
					<p align="justify"><?php echo $weldesc1; ?></p>
					<a href="about_us.php" class="btn btn-danger">थप जान्कारी</a>
				</div>
			</div>
			<div class="col-md-8">
				<?php 
					include('include/slider.php')
				?>
			</div>		
		</div>	
	</div>
	<div class="content">
		<div class="container">
			<div class="row">			
				<div class="col-md-9">					
					<div class="row">
						<div class="col-md-12 custom-wellwell">
							<ul class="media-list">
								<li class="media">
								<?php
								$sql2="select * from registrarmessage where registrarmessageID='2';";
								$result2=mysqli_query($connect,$sql2) or die("Error in Mysql :".mysqli_error($connect));
								$row2=mysqli_fetch_array($result2);
								$regname1=$row2['registrarmessageName1'];
								$regdesc1=$row2['registrarmessageDesc1'];
								$regimg=$row2['registrarmessageImagePath'];
								?>
									<h4><?php echo $regname1; ?></h4>
									<img src="<?php echo $regimg; ?>" alt="<?php echo $regname1; ?>" class="media-object pull-left custom-image" />
										<div class="media-body">
											<p align="justify"><?php echo $regdesc1; ?> </p>
										</div>
								</li>								
							</ul>							
						</div>
						<?php	
							$sql="Select * from indexmodule;";
							$query=mysqli_query($connect, $sql) or die ("Error in mysql:".mysqli_error($connect));
							while($row=(mysqli_fetch_array($query))){
								$tbname=$row['tableName'];
								$id=$row['headingID'];
								$hrefLink=$row['modLink'];
								$hrefLink1=str_replace(" ","", $hrefLink);

								$colID=str_replace(" ","", $tbname."ID");
								
								$sql1="Select * from $tbname where $colID=$id;";
								$query1=mysqli_query($connect, $sql1) or die ("Error in mysql:".mysqli_error($connect));
								
								if ($row1=(mysqli_fetch_array($query1))){

									$colTitle=str_replace(" ","", $tbname."Name1");
									$title=$row1[$colTitle];
																
									$coldesc=str_replace(" ","", $tbname."Desc1");
									$description=$row1[$coldesc];
								}
						?>
						
								<div class="col-md-12 custom-wellwell">
									<h4><?php echo $title ?></h4>
									<!-- Limit the amount of texts -->
									<p align="justify"><?php echo substr($description,0,350).".....";?></p>
									<a href="<?php echo $hrefLink1."?contType=nep"; ?>#<?php echo $title; ?>" class="btn btn-info" style="">थप जान्कारी</a>
								</div>
						<?php
								
							}
						?>

					</div>
				</div>
				<div class="col-md-3">
					<?php include('include/sidebar.php');?>
				</div>
			</div>
		</div>
	</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
}
////////////////////////////////////////////// FOR ENGLISH CONTENTS ///////////////////////////////////
else{
	$val="eng";
	?>
	<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>PRMD</title>
	<!-- <title>पि.आर.एम.दि</title> -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<div class="custom-well">
				<?php
				$sql1="select * from registrarmessage where registrarmessageID='1';";
				$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
				$row1=mysqli_fetch_array($result1);
				$welname1=$row1['registrarmessageName'];
				$weldesc1=$row1['registrarmessageDesc'];
				?>
					<h2><?php echo $welname1; ?></h2>
					<p align="justify"><?php echo $weldesc1; ?></p>
					<a href="about_us.php" class="btn btn-danger">Learn More</a>
				</div>
			</div>
			<div class="col-md-8">
				<?php 
					include('include/slider.php')
				?>
			</div>		
		</div>	
	</div>
	<div class="content">
		<div class="container">
			<div class="row">			
				<div class="col-md-9">					
					<div class="row">
						<div class="col-md-12 custom-wellwell">
							<ul class="media-list">
								<li class="media">
								<?php
								$sql2="select * from registrarmessage where registrarmessageID='2';";
								$result2=mysqli_query($connect,$sql2) or die("Error in Mysql :".mysqli_error($connect));
								$row2=mysqli_fetch_array($result2);
								$regname1=$row2['registrarmessageName'];
								$regdesc1=$row2['registrarmessageDesc'];
								$regimg=$row2['registrarmessageImagePath'];
								?>
									<h4><?php echo $regname1; ?></h4>
									<img src="<?php echo $regimg; ?>" alt="<?php echo $regname1; ?>" class="media-object pull-left custom-image" />
										<div class="media-body">
											<p align="justify"><?php echo $regdesc1; ?> </p>
										</div>
								</li>								
							</ul>							
						</div>
						<?php	
							$sql="Select * from indexmodule;";
							$query=mysqli_query($connect, $sql) or die ("Error in mysql:".mysqli_error($connect));
							while($row=(mysqli_fetch_array($query))){
								$tbname=$row['tableName'];
								$id=$row['headingID'];
								$hrefLink=$row['modLink'];
								$hrefLink1=str_replace(" ","", $hrefLink);

								$colID=str_replace(" ","", $tbname."ID");
								
								$sql1="Select * from $tbname where $colID=$id;";
								$query1=mysqli_query($connect, $sql1) or die ("Error in mysql:".mysqli_error($connect));
								
								if ($row1=(mysqli_fetch_array($query1))){

									$colTitle=str_replace(" ","", $tbname."Name");
									$title=$row1[$colTitle];
																
									$coldesc=str_replace(" ","", $tbname."Desc");
									$description=$row1[$coldesc];
								}
						?>
						
								<div class="col-md-12 custom-wellwell">
									<h4><?php echo $title ?></h4>
									<!-- Limit the amount of texts -->
									<p align="justify"><?php echo substr($description,0,350).".....";?></p>
									<a href="<?php echo $hrefLink1; ?>#<?php echo $title; ?>" class="btn btn-info" style="">Read More</a>
								</div>
						<?php
								
							}
						?>
						
					</div>
				</div>
				<div class="col-md-3">
					<?php include('include/sidebar.php');?>
				</div>
			</div>
		</div>
	</div>
	<?php include('include/footer.php');?>	
</body>
</html>
	<?php
}
?>
<?php
include('cms_admin/connect1.php');
$val="";
$pgnm="gallery_videos.php";
////////////////////////////////////////////// FOR NEPALI CONTENTS ///////////////////////////////////
 if((isset($_GET['contType']))=="nep"){
	$val="nep";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>पि.आर.एम.दि - भिडियोहरु</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
    <script src="js/video/jquery.youtubevideogallery.js"></script>
    <link rel="stylesheet" href="css/video/youtube-video-gallery.css" type="text/css"/>
    <link rel="stylesheet" href="css/video/test/test.css" type="text/css"/>
<div class="content">
	<div class="container">
		<div class="row">
			<div class="col-md-9">
				<h3> भिडियो ग्यालरी</h3>		
					<div class="row">
						<?php
				$sql1= "select * from galleryvideo;";
				$result1 = mysqli_query($connect,$sql1) or die("error in mysql :".mysqli_error());
				while ($row1=mysqli_fetch_array($result1)){	 
				?>
							<div class="col-md-3"  style="text-align:center;">
							<!--<iframe width="200" height="200" src="http://www.youtube.com/embed/XGSy3_Czz8k"></iframe> -->
								<div id="test">
									<ul class="youtube-videogallery">
										<li><a href="<?php echo $row1['galleryvideoLink'];?>"><?php echo $row1['galleryvideoName1'];?></a></li>
        
									</ul>     
								</div>

							</div>
							<?php
							}
							
							?>
								<script>
    $(document).ready(function(){
        $("ul.youtube-videogallery").youtubeVideoGallery( {assetFolder:'../'} );

        $("ul.youtube-videogallery-compact").youtubeVideoGallery( {
                assetFolder:'../',
                style:'compact',
                title:'none'
            }
        );

        $("ul.youtube-videogallery-search").youtubeVideoGallery({
            apiFallbackUrl: 'https://www.youtube.com/results?search_query=football+soccer',
            apiUrl: 'https://gdata.youtube.com/feeds/api/videos?q=football+-soccer&orderby=published&start-index=1&alt=json&max-results=6&v=2',
            assetFolder:'../'
        });
        $("ul.youtube-videogallery-user").youtubeVideoGallery({
            apiFallbackUrl: 'http://www.youtube.com/user/mayarcade',
            apiUrl:'http://gdata.youtube.com/feeds/api/users/mayarcade/uploads?v=2&alt=jsonc&max-results=6',
            assetFolder:'../'
        });
        $("ul.youtube-videogallery-playlist").youtubeVideoGallery({
            apiFallbackUrl: 'http://www.youtube.com/playlist?list=PLdLRpN7S7Ubw-OQI7MS04NuYpXHadH6xc',
            apiUrl:'http://gdata.youtube.com/feeds/api/playlists/PLdLRpN7S7Ubw-OQI7MS04NuYpXHadH6xc?alt=json&start-index=1&max-results=6&v=2',
            assetFolder:'../'
        });
    });
</script>
							
						
						
						</div>					
				</div>
					
			
			<div class="col-md-3">
				<?php include('include/sidebar.php'); ?>
			</div>
		</div>		
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
}
////////////////////////////////////////////// FOR ENGLISH CONTENTS ///////////////////////////////////
else{
	$val="eng";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>PRMD-Videos</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
    <script src="js/video/jquery.youtubevideogallery.js"></script>
    <link rel="stylesheet" href="css/video/youtube-video-gallery.css" type="text/css"/>
    <link rel="stylesheet" href="css/video/test/test.css" type="text/css"/>
<div class="content">
	<div class="container">
		<div class="row">
			<div class="col-md-9">
				<h3> Video Gallery</h3>	
				<div class="row">
						<?php
				$sql1= "select * from galleryvideo;";
				$result1 = mysqli_query($connect,$sql1) or die("error in mysql :".mysqli_error());
				while ($row1=mysqli_fetch_array($result1)){	 
				?>
							<div class="col-md-3"  style="text-align:center;">
							<!--<iframe width="200" height="200" src="http://www.youtube.com/embed/XGSy3_Czz8k"></iframe> -->
								<div id="test">
									<ul class="youtube-videogallery">
										<li><a href="<?php echo $row1['galleryvideoLink'];?>"><?php echo $row1['galleryvideoName'];?></a></li>
        
									</ul>     
								</div>

							</div>
							<?php
							}
							
							?>
								<script>
    $(document).ready(function(){
        $("ul.youtube-videogallery").youtubeVideoGallery( {assetFolder:'../'} );

        $("ul.youtube-videogallery-compact").youtubeVideoGallery( {
                assetFolder:'../',
                style:'compact',
                title:'none'
            }
        );

        $("ul.youtube-videogallery-search").youtubeVideoGallery({
            apiFallbackUrl: 'https://www.youtube.com/results?search_query=football+soccer',
            apiUrl: 'https://gdata.youtube.com/feeds/api/videos?q=football+-soccer&orderby=published&start-index=1&alt=json&max-results=6&v=2',
            assetFolder:'../'
        });
        $("ul.youtube-videogallery-user").youtubeVideoGallery({
            apiFallbackUrl: 'http://www.youtube.com/user/mayarcade',
            apiUrl:'http://gdata.youtube.com/feeds/api/users/mayarcade/uploads?v=2&alt=jsonc&max-results=6',
            assetFolder:'../'
        });
        $("ul.youtube-videogallery-playlist").youtubeVideoGallery({
            apiFallbackUrl: 'http://www.youtube.com/playlist?list=PLdLRpN7S7Ubw-OQI7MS04NuYpXHadH6xc',
            apiUrl:'http://gdata.youtube.com/feeds/api/playlists/PLdLRpN7S7Ubw-OQI7MS04NuYpXHadH6xc?alt=json&start-index=1&max-results=6&v=2',
            assetFolder:'../'
        });
    });
</script>
							
						
						
						</div>					
				</div>				
					
			
			<div class="col-md-3">
				<?php include('include/sidebar.php'); ?>
			</div>
			</div>
		</div>		
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
}
?>
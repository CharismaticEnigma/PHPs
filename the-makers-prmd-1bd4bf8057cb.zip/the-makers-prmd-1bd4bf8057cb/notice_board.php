<?php
include('cms_admin/connect1.php');
$val="";
$pgnm="notice_board.php";
////////////////////////////////////////////// FOR NEPALI CONTENTS ///////////////////////////////////
 if((isset($_GET['contType']))=="nep"){
	$val="nep";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>पि.आर.एम.दि - सूचना पेटी</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<h3>सूचना पेटी</h3>
		<ul class="media-list">
			<!------ Repeat ------>
			<?php
				$s1="Select * from news;";
				$qr1=mysqli_query($connect,$s1) or die("Error in Mysqli: ".mysqli_error($connect));
				while($rs1=mysqli_fetch_array($qr1)){
					$newsID=$rs1['newsID'];
						$newsNm=$rs1['newsName1'];
						$newsName=$rs1['newsImagePath'];
						$newsDesc=$rs1['newsDesc1'];
			?>
			<li class="media">
				<h4><?php echo $newsNm; ?></h4>
				<img src="<?php echo $newsName;?>" alt="<?php echo $newsNm; ?>" class="media-object pull-left custom-image" />
					<div class="media-body">
						<p align="justify"><?php echo $newsDesc?></p>
					</div>
			</li>
			<?php		
				}
			?>
			<!------ Repeat ------>
			
		</ul>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
}
////////////////////////////////////////////// FOR ENGLISH CONTENTS ///////////////////////////////////
else{
	$val="eng";
	?>
	<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>PRMD - Notice Board</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<h3>Notice Board <!-- सूचना पेटी --></h3>
		<ul class="media-list">

		<!------ Repeat ------>
			<?php
				$s1="Select * from news;";
				$qr1=mysqli_query($connect,$s1) or die("Error in Mysqli: ".mysqli_error($connect));
				while($rs1=mysqli_fetch_array($qr1)){
					$newsID=$rs1['newsID'];
						$newsNm=$rs1['newsName'];
						$newsName=$rs1['newsImagePath'];
						$newsDesc=$rs1['newsDesc'];
			?>
			<li class="media">
				<h4><?php echo $newsNm; ?></h4>
				<img src="<?php echo $newsName;?>" alt="<?php echo $newsNm; ?>" class="media-object pull-left custom-image" />
					<div class="media-body">
						<p align="justify"><?php echo $newsDesc?></p>
					</div>
			</li>
			<?php		
				}
			?>
			<!------ Repeat ------>
		</ul>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
	<?php
}
?>
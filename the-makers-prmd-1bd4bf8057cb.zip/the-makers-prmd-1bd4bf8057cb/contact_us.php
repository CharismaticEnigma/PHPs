<?php
include('cms_admin/connect1.php');
$val="";
$pgnm="contact_us.php";
////////////////////////////////////////////// FOR NEPALI CONTENTS ///////////////////////////////////
 if((isset($_GET['contType']))=="nep"){
	$val="nep";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>पि.आर.एम.दि - सम्पर्क</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<h3> सम्पर्क</h3>
		<p align="justify">
			सल्लाह सुझाव भएमा तल दिएको फारम भरेर हामीलाई सहयोग गरिदिनुहोला।
		</p>
		<hr>
		<div class="row">
			<div class="col-md-6">
				<div class="well">
					<!-- <h4>कीटनाशक दर्ता र व्यवस्थापन विभाग</h4>
					<p><span class="glyphicon glyphicon-pushpin"></span> ठेगाना: हरिहर भवन, ललितपुर, नेपाल</p>				
					<p><span class="glyphicon glyphicon-envelope"></span> इमेल: info@prmd.gov.np</p> -->	

					<form name="form" action="include/mail.php" method="post">
						
						<div class="responsive-table">
						<table class="table">
							<tr>
								<td><p>नाम</p></td>
								<td><input type="text" name="name" id="name" style="width:100%;" required></td>
							</tr>
							<tr>
								<td><p>इमेल</p></td>								
								<td><input type="email" name="email" id="email" style="width:100%;" required></td>
							</tr>
							<tr>
								<td><p>विषय</p></td>
								<td><input type="text" name="subject" id="subject" style="width:100%;" required></td>
							</tr>
							<tr>
								<td><p>तपाईको सन्देश</p></td>
								<td><textarea name="message" id="message" cols="45" rows="5" style="width:100%;" required></textarea></td>
							</tr>
							<tr>
								<td></td>
								<td style="float:right;"><input class="btn btn-info" type="submit" name="submit" id="submit" value="बुझाउ"></td>
							</tr>
						</table>
					</div>
					</form>
				</div>
			</div>
			<div class="col-md-6">
				<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script><div style="overflow:hidden;height:500px;width:100%;"><div id="gmap_canvas" style="height:500px;width:100%;"></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style><a class="google-map-code" href="http://www.mapsembed.com/mirapodo/" id="get-map-data">www.mapsembed.com</a></div><script type="text/javascript"> function init_map(){var myOptions = {zoom:16,center:new google.maps.LatLng(27.681140798358932,85.31738695399781),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(27.681140798358932, 85.31738695399781)});infowindow = new google.maps.InfoWindow({content:"<b>Pesticide Registration and Management Division</b><br/>Harihar Bhaban<br/> Lalitpur" });google.maps.event.addListener(marker, "click", function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>	
			</div>
		</div>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
}
////////////////////////////////////////////// FOR ENGLISH CONTENTS ///////////////////////////////////
else{
	$val="eng";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>PRMD - Contact Us</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<h3>Contact Us</h3>
		<p align="justify">
			If you have any feedback and suggestions you can send us a message down below. We are happy to hear from you.
		</p>
		<hr>
		<div class="row">
			<div class="col-md-6">
				<div class="well">
					<h4>Pesticide Registration and Management Division</h4>
					<p><span class="glyphicon glyphicon-pushpin"></span> Address: Harihar Bhaban, Lalitpur, Nepal</p>					
					<p><span class="glyphicon glyphicon-envelope"></span> Email: info@prmd.gov.np</p>

					<form name="form" action="include/mail.php" method="post">
						
						<div class="responsive-table">
						<table class="table">
							<tr>
								<td><p>Name</p></td>
								<td><input type="text" name="name" id="name" style="width:100%;" required></td>
							</tr>
							<tr>
								<td><p>E-mail</td>
								<td><input type="email" name="email" id="email" style="width:100%;" required></td>
							</tr>
							<tr>
								<td><p>Subject</p></td>
								<td><input type="text" name="subject" id="subject" style="width:100%;" required></td>
							</tr>
							<tr>
								<td><p>Your Message</p></td>
								<td><textarea name="message" id="message" cols="45" rows="5" style="width:100%;" required></textarea></td>
							</tr>
							<tr>
								<td></td>
								<td style="float:right;"><input class="btn btn-info" type="submit" name="submit" id="submit" value="Submit"></td>
							</tr>
						</table>
					</div>
					</form>
				</div>
			</div>
			<div class="col-md-6">
				<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script><div style="overflow:hidden;height:500px;width:100%;"><div id="gmap_canvas" style="height:500px;width:100%;"></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style><a class="google-map-code" href="http://www.mapsembed.com/mirapodo/" id="get-map-data">www.mapsembed.com</a></div><script type="text/javascript"> function init_map(){var myOptions = {zoom:16,center:new google.maps.LatLng(27.681140798358932,85.31738695399781),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(27.681140798358932, 85.31738695399781)});infowindow = new google.maps.InfoWindow({content:"<b>Pesticide Registration and Management Division</b><br/>Harihar Bhaban<br/> Lalitpur" });google.maps.event.addListener(marker, "click", function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>	
			</div>
		</div>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
}
?>
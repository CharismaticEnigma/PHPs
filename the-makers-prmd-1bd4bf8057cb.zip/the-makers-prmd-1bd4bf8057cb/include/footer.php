<?php
////////////////////////////nepali ko lai//////////////////////////////////////////////////////////////////////

if($val=="nep"){
 /* echo "you will see nepali header";*/
?>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript" src="js/smoothzoom.js"></script>
<script type="text/javascript">
    $(window).load( function() {
        $('img').smoothZoom({
            // Options go here
        });
    });
</script>
<div class="container" style="border-bottom:1px solid #382356;">
	<div class="row">
		<div class="col-md-6 col-xs-6">
			<h4>लिंक​</h4>
			<div style="color:#494949;">
				<?php
				$s1="select * from ourlinks;";
				$qr1=mysqli_query($connect,$s1) or die ("Error in Mysqli: ".mysqli_error($connect));
				while($rs1=mysqli_fetch_array($qr1)) {
					$linkID=$rs1['ourlinksID'];
					$linkNm=$rs1['ourlinksName1'];
					$linkPage=$rs1['ourlinksLink'];
				?>
				<p><a href="<?php echo $linkPage; ?>" target="_blank"><?php echo $linkNm;?></a></p>
				<?php
					}
				?>
			</div>
		</div>		
		<div class="col-md-6 col-xs-6">			
			<h4>सम्पर्क</h4>
			<div style="color:#494949;">
				<p><span class="glyphicon glyphicon-pushpin"></span> ठेगाना: हरिहर भवन, ललितपुर, नेपाल</p>				
				<p><span class="glyphicon glyphicon-envelope"></span> इमेल: info@prmd.gov.np</p>				
			</div>
		</div>
	</div>		
</div>
<div class="container" style="margin-top:20px"> 	
	<div class="copyright" align="middle">
		<p>Copyright &copy 2014 Pesticide Registration and Management Division. All rights reserved</p>
		<p>Powered By: <a href="http://www.hitechskills.com">Hi-Tech Skills</a></p>
	</div>
</div>	
<?php 
}
///////////////////////////////////////////////////////ENGLISH KO LAGI////////////////////////////////////////////////
else if($val=="eng"){
 // echo "you are going to see english header";
?>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript" src="js/smoothzoom.js"></script>
<script type="text/javascript">
    $(window).load( function() {
        $('img').smoothZoom({
            // Options go here
        });
    });
</script>
<div class="container" style="border-bottom:1px solid #382356;">
	<div class="row">
		<div class="col-md-6 col-xs-6">
			<h4>Link</h4>
			<div style="color:#494949;">

				<?php
				$s1="select * from ourlinks;";
				$qr1=mysqli_query($connect,$s1) or die ("Error in Mysqli: ".mysqli_error($connect));
				while($rs1=mysqli_fetch_array($qr1)) {
					$linkID=$rs1['ourlinksID'];
					$linkNm=$rs1['ourlinksName'];
					$linkPage=$rs1['ourlinksLink'];
				?>
				<p><a href="<?php echo $linkPage; ?>" target="_blank"><?php echo $linkNm;?></a></p>
				<?php
					}
				?>
			</div>
		</div>		
		<div class="col-md-6 col-xs-6">
			<h4>Contact Us</h4>
			<div style="color:#494949;">
				<p><span class="glyphicon glyphicon-pushpin"></span> Address:  Harihar Bhaban, Lalitpur, Nepal</p>
				<!-- <p><span class="glyphicon glyphicon-phone-alt"></span> Phone: 01426715, 014212376</p>
				<p><span class="glyphicon glyphicon-print"></span> Fax: 0142123</p> -->
				<p><span class="glyphicon glyphicon-envelope"></span> Email: info@prmd.gov.np</p>				
			</div>
			
		</div>
	</div>		
</div>
<div class="container" style="margin-top:20px"> 	
	<div class="copyright" align="middle">
		<p>Copyright &copy 2014 Pesticide Registration and Management Division. All rights reserved</p>
		<p>Powered By: <a href="http://www.hitechskills.com">Hi-Tech Skills</a></p>
	</div>
</div>	

<?php
}
?> 
 	  	 
 	  	 
 	  	 
 	  	 
 	  	 
 	  	 
 	  	 




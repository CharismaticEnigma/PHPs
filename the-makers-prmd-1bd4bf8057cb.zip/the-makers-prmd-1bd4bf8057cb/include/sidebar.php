<?php
////////////////////////////nepali ko lai//////////////////////////////////////////////////////////////////////

if($val=="nep"){
 /* echo "you will see nepali header";*/
?>
<div class="row" >	
	<div class="col-md-12">
		<div class="tender">
			<?php include('include/side_news_&_events.php'); ?>								
		</div> 							
	</div>
	<div class="col-md-12" style="padding:10px;">			
		<div class="calender" align="center">								
			<h4>पात्रो</h4>
			<iframe src="http://www.nepcal.com/m_e_j3.php" frameborder="0" scrolling="no" marginwidth="0" marginheight="0" style="border:none; overflow:hidden; width:189px; height:279px;" allowtransparency="true"></iframe>
		</div>		 
	</div>
</div>
<?php 
}
///////////////////////////////////////////////////////ENGLISH KO LAGI////////////////////////////////////////////////
else if($val=="eng"){
 // echo "you are going to see english header";
?>
<div class="row" >	
	<div class="col-md-12">
		<div class="tender">
			<?php include('include/side_news_&_events.php'); ?>								
		</div> 							
	</div>
	<div class="col-md-12" style="padding:10px;">			
		<div class="calender" align="center">								
			<h4>Calender </h4>
			<iframe src="http://www.nepcal.com/m_e_j3.php" frameborder="0" scrolling="no" marginwidth="0" marginheight="0" style="border:none; overflow:hidden; width:189px; height:279px;" allowtransparency="true"></iframe>
		</div>		 
	</div>
</div>
<?php
}
?>


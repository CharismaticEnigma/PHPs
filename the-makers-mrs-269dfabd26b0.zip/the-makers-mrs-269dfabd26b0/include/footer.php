<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript" src="js/smoothzoom.js"></script>
<script type="text/javascript">
    $(window).load( function() {
        $('img').smoothZoom({
            // Options go here
        });
    });
</script>
<div class="footer" style="background-color:#0A2600;  width:100%; color:#CCC;">
    <div class="row clearfix" style=" width:98%; margin:0 auto;" align="center">    
        <div class="col-md-3">
            <h3>Gallery</h3>

            
            <?php
                $sq1="Select * from galleryimage limit 6;";
                $qr1=mysqli_query($connect, $sq1) or die ("Error in Mysqli: ".mysqli_error($connect));
                while($rs=mysqli_fetch_array($qr1)){
                    $galImg=$rs['galleryimageImagePath'];
                    $galName=$rs['galleryimageName'];

                
            ?>
          
            <a href="<?php echo $galImg;?>" target="_blank"><img src="<?php echo $galImg;?>" style="height:100px; max-width:75px; float:left;"  alt="<?php echo $galName;?>"class=" image img-rounded" /></a>
            <?php
                }
                ?>

        </div>
        <div class="col-md-3">
            <h3 align="left">About Us</h3>
            <?php
            $ab1=str_replace(" ","",strtolower("About Us"));
            $ab2=str_replace(" ","",strtolower("About Company"));
            $ab3=str_replace(" ","",strtolower("About MRS"));
            $ab4=str_replace(" ","",strtolower("About MRS Enterprises"));
            $ab5=str_replace(" ","",strtolower("About MRS Surgical"));
            
            $sq2="Select * from about;";
            $qr2=mysqli_query($connect,$sq2) or die ("Error in Mysqli: ".mysqli_error($connect));
            while($rs2=mysqli_fetch_array($qr2)){
                $title=str_replace(" ","",strtoLower($rs2['aboutName']));
                if($title=="aboutus" || $title=="aboutcompany" || $title=="aboutmrs" || $title=="aboutmrsenterprises" || $title=="aboutmrssurgical"){
                    $desc=$rs2['aboutDesc'];
                    $abDesc=substr($desc, 0,530)."......";        
                    ?>
                    <p align="justify">
                        <?php echo $abDesc;?>
                    </p>
                    <?php
                }
            }
            

            ?>

            
        </div>
        <div class="col-md-4">
            <h3 align="left">Contact Us</h3>
             <p align="justify"><span class="glyphicon glyphicon-map-marker"></span> Address: Tripureshwor-11, Kathmandu, Nepal</p>
             <p align="justify"><span class="glyphicon glyphicon-phone"></span> Telephone: +977-01-4101129,4100504</p>
             <p align="justify"><span class="glyphicon glyphicon-pencil"></span> E-mail: nepal_mrscompany@yahoo.com</p>
        </div>
        <div class="col-md-2">
            <h3>Follow Us</h3>
             <p><a href="#"><img src="img/fb.png" alt="Facebook"></a></p>
             <p><a href="#"><img src="img/twitter.png" alt="Twitter"></a></p>
        </div>        
    </div> 
    <hr>
        <p align="center">Copyright &copy MRS. All Rights Reserved.</p>
        <p align="center">Powered By: <a href="http://www.hitechskills.com">Hi - Tech Skills</a></p>  
</div>
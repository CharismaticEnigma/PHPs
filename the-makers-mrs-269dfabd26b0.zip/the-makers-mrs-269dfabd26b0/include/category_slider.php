<?php

?>
	 <link href="../css/owl.carousel.css" rel="stylesheet">
	 <link href="../css/owl.theme.css" rel="stylesheet">
	 <script src="../js/jquery-1.9.1.min.js"></script>	
	<script src="../js/owl.carousel.js"></script>
	
      <div class="row">
        <div class="span12">

          <div id="owl-example" class="owl-carousel">
           <?php
         $sql1="select * from category;";
         $result1=mysqli_query($connect,$sql1) or die("Error in Mysqli :".mysqli_error($connect));
         while($row1=mysqli_fetch_array($result1))
         {
          $catId=$row1['categoryID'];
          $catName=$row1['categoryName'];
          $catImg=$row1['categoryImagePath'];
          $catDesc=$row1['categoryDesc'];
         ?>
          	<div class="well" style="margin-left:8px; margin-right:8px;" align="center">
          		<p style="height:60px;"><?php echo $catName;?></p>
          		<a href="<?php echo "categories.php?id=".$catId;?>"><img src="<?php echo $catImg;?>"  class="img-thumbnail custom-image" alt="<?pho echo $catName; ?>"/></a>          
          		<div style="height:150px;">
                <p align="justify"><?php echo substr($catDesc, 0, 500); ?></p>
              </div>
        	</div>
          <?php
            }
            ?>
          </div>
        </div>
      </div>



  <script type="text/javascript">
  	    $(document).ready(function() {
     
    $("#owl-example").owlCarousel();
     
    });
  </script>
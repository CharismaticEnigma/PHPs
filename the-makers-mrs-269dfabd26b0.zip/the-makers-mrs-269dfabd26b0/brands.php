<?php
include("cms_admin/connect1.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>MRS Surgical House</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">			
		<div class="row">
			<div class="col-lg-3">
				<?php
					include('include/sidebar.php');
				?>
			</div>
			<div class="col-lg-9">
			<?php
					$bid=$_GET['id'];
					$sql1="select * from brand where brandID='$bid';";
					$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :line 28".mysqli_error($connect));
					while ($row1=mysqli_fetch_array($result1)) {
						$brandName=$row1['brandName'];
						$brandimage=$row1['brandImagePath'];
						$brandDesc=$row1['brandDesc'];
						if ($brandimage=="images/brand")
						{
							$brandimage="images/brand/default.png";
						}

					}
				?>
				<h3><?php echo $brandName;?></h3>
				<ul class="media-list">						
					<li class="media">
						<img src="<?php echo $brandimage;?>" class="pull-left img-thumbnail" alt="<?php echo $brandName;?>">
						<div class="media-body">
							<p align="justify">
								<?php echo $brandDesc;?>
							</p>
						</div>
					</li>
				</ul>
				<div class="well">
					<h3>Categories</h3>
						<div class="row" align="center">
						<?php
				
							$sql2="select distinct categoryID from product where brandID='$bid';";
							$result2=mysqli_query($connect,$sql2) or die("Error in Mysql :line 48".mysqli_error($connect));
							while($row2=mysqli_fetch_array($result2)){
								$categoryid=$row2['categoryID'];
														
								$sql3="select * from category where categoryID='$categoryid';";
								$result3=mysqli_query($connect,$sql3) or die("Error in Mysql :line 59".mysqli_error($connect));
								while($row3=mysqli_fetch_array($result3)){
									$categoryimage=$row3['categoryImagePath'];
									$categoryname=$row3['categoryName'];
									$categorydesc=$row3['categoryDesc'];

									if($categoryimage=="images/category"){
										?>
							<div class="col-md-3">
								<div class="cat-container" style="margin-bottom: 8px;">
												<a href="<?php echo "products.php?id=".$categoryid;?>"><img src="images/category/default1.png" class="img-thumbnail" alt="<?php echo $categoryname; ?>" style="margin-top:-60px;"></a>
												<h4><?php echo $categoryname; ?></h4>
								</div>															
							</div>
								<?php

									}
									else{
										?>
										<div class="col-md-3">
											<div class="cat-container" style="margin-bottom: 8px;">
												<a href="<?php echo "products.php?cateid=".$categoryid;?>"><img src="<?php echo $categoryimage; ?>" class="img-thumbnail custom-otherimage" alt="<?php echo $categoryname; ?>" style="margin-top:-60px;"></a>
												<h4><?php echo $categoryname; ?></h4>
											</div>														
										</div>
							<?php

									}

							?>
							
							<?php
								}
							}
							?>
						
						</div>
					
				</div>
			</div>
		</div>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
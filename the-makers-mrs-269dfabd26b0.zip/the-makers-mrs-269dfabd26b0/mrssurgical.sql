-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2014 at 06:52 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mrssurgical`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE IF NOT EXISTS `about` (
  `aboutID` int(11) NOT NULL AUTO_INCREMENT,
  `aboutName` varchar(200) NOT NULL,
  `aboutDesc` text NOT NULL,
  `aboutImagePath` text NOT NULL,
  PRIMARY KEY (`aboutID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`aboutID`, `aboutName`, `aboutDesc`, `aboutImagePath`) VALUES
(1, 'article2', '<p>asdasdas</p>\r\n', 'images/about/article/acer-1.jpg'),
(2, 'About Us', '<p style="text-align: justify;"><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">La-med healthcare is a leading manufacturer of premium quality medical devices. The company which established in the year 2007 has multiple manufacturing facilities located in India.</span><br />\r\n<br />\r\n<span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">La-med manufacture and market single use medical devices in Infusion Therapy, Anaesthesia &amp; Respiratory care, Surgery &amp; Drainage, Urology, Gastroenterology.&nbsp;</span><br />\r\n<br />\r\n<span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">The company has adopted ISO -9001:2008 quality management system and ISO 13485:2003 Quality management system specially for medical devices. Our products are CE marked from DNV Norway. La-med is registered with USFDA, and approval from Indian FDA, Drugs Department, GMP certificates has been received. Our products are registered in many more countries as per local regulation.</span><br />\r\n<br />\r\n<span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">La-med export over 150 million devices to over 45 countries globally. Our brand is well recognized and respected in the markets we cover. La- med has local representatives in many countries.</span><br />\r\n<br />\r\n<span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">Jaya Sai baba has a strong marketing base within the home country India, where we have a strong well trained and organized sales team covering the whole country. Over 300 SKU are being marketed in our own brand all over the country. Primaflon, IVflon, Primaneo, Link, Drippy, OncoGuard, etc are some of our popular brands.</span><br />\r\n<br />\r\n<span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif">Jaya Sai baba</span><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px"> has a strong innovation team which focus on improvement of existing products and introduction of new products as per the market feed back and needs identified by our marketing team.</span><br />\r\n<br />\r\n<span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">The company has plan to introduce many innovative products with underline principle of safety and simplicity to facilitate better patient care through innovation in line with our philosophy of Conscious caring</span></p>\r\n', 'images/about/article/godrej.jpg'),
(3, 'Our Objectives', '<p style="text-align: justify;"><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">La-med healthcare is a leading manufacturer of premium quality medical devices. The company which established in the year 2007 has multiple manufacturing facilities located in India.</span><br />\r\n<br />\r\n<span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">La-med manufacture and market single use medical devices in Infusion Therapy, Anaesthesia &amp; Respiratory care, Surgery &amp; Drainage, Urology, Gastroenterology.&nbsp;</span><br />\r\n<br />\r\n<span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">The company has adopted ISO -9001:2008 quality management system and ISO 13485:2003 Quality management system specially for medical devices. Our products are CE marked from DNV Norway. La-med is registered with USFDA, and approval from Indian FDA, Drugs Department, GMP certificates has been received. Our products are registered in many more countries as per local regulation.</span><br />\r\n<br />\r\n<span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">La-med export over 150 million devices to over 45 countries globally. Our brand is well recognized and respected in the markets we cover. La- med has local representatives in many countries.</span><br />\r\n<br />\r\n<span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">Jaya Sai baba has a strong marketing base within the home country India, where we have a strong well trained and organized sales team covering the whole country. Over 300 SKU are being marketed in our own brand all over the country. Primaflon, IVflon, Primaneo, Link, Drippy, OncoGuard, etc are some of our popular brands.</span><br />\r\n<br />\r\n<span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif">Jaya Sai baba</span><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">&nbsp;has a strong innovation team which focus on improvement of existing products and introduction of new products as per the market feed back and needs identified by our marketing team.</span><br />\r\n<br />\r\n<span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">The company has plan to introduce many innovative products with underline principle of safety and simplicity to facilitate better patient care through innovation in line with our philosophy of Conscious caring</span></p>\r\n', 'images/about/article/2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE IF NOT EXISTS `brand` (
  `brandID` int(11) NOT NULL AUTO_INCREMENT,
  `brandName` varchar(200) NOT NULL,
  `brandImagePath` text NOT NULL,
  `brandDesc` text NOT NULL,
  PRIMARY KEY (`brandID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`brandID`, `brandName`, `brandImagePath`, `brandDesc`) VALUES
(5, 'Santosh Surgical Ltd', 'images/brand/santoshsurgical.png', '<p style="text-align: justify;"><strong>SANTOSH SURGICAL</strong><span style="font-family:helvetica,arial,sans-serif; font-size:12px">, is very Professional in Manufacturing and Supplying Instruments to worldwide since 1981. The company&nbsp;is&nbsp;Manufacturer&nbsp;and Exporter&nbsp;of all kinds of Surgical Instruments in , E.N.T. Instruments and Other Instruments.</span></p>\r\n'),
(6, 'JingHao Enterprises Share Co. Ltd.', 'images/brand/jinghao.jpg', '<p style="text-align: justify;"><span style="color:rgb(85, 85, 85); font-family:arial; font-size:12px">Jinghao Enterprise Shares Co., Ltd. is a professional technology company specializing in the hearing aids. Their products have&nbsp;been analyzed by Guangdong Provincial Medical Administration and awarded the License for producing those items. They&nbsp;have also passed ISO9001 international quality guarantee standard.</span><br />\r\n<span style="color:rgb(85, 85, 85); font-family:arial; font-size:12px">With the Development and renovation of products, most of their&nbsp;items sell well all over the world, especially in Europe, North America, and the Middle East. They&nbsp;have their own design of BTE (Behind the Ear), ITE (in the ear) ITC (in the canal), and CIC (completely in the canal). With the increasing demands and business, they have&nbsp;achieved an output of Five Million pieces in 2008.</span></p>\r\n'),
(7, 'La-med Conscious Caring', 'images/brand/lamed.jpg', '<table border="0" cellpadding="0" cellspacing="8" style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px; line-height:normal; text-align:justify; width:100%">\r\n	<tbody>\r\n		<tr>\r\n			<td><strong>About Us</strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>La-med healthcare is a leading manufacturer of premium quality medical devices. The company which established in the year 2007 has multiple manufacturing facilities located in India.<br />\r\n			<br />\r\n			La-med manufacture and market single use medical devices in Infusion Therapy, Anaesthesia &amp; Respiratory care, Surgery &amp; Drainage, Urology, Gastroenterology.&nbsp;<br />\r\n			<br />\r\n			The company has adopted ISO -9001:2008 quality management system and ISO 13485:2003 Quality management system specially for medical devices. Our products are CE marked from DNV Norway. La-med is registered with USFDA, and approval from Indian FDA, Drugs Department, GMP certificates has been received. Our products are registered in many more countries as per local regulation.<br />\r\n			<br />\r\n			La-med export over 150 million devices to over 45 countries globally. Our brand is well recognized and respected in the markets we cover. La- med has local representatives in many countries.<br />\r\n			<br />\r\n			La-med has a strong marketing base within the home country India, where we have a strong well trained and organized sales team covering the whole country. Over 300 SKU are being marketed in our own brand all over the country. Primaflon, IVflon, Primaneo, Link, Drippy, OncoGuard, etc are some of our popular brands.<br />\r\n			<br />\r\n			La-med has a strong innovation team which focus on improvement of existing products and introduction of new products as per the market feed back and needs identified by our marketing team.<br />\r\n			<br />\r\n			The company has plan to introduce many innovative products with underline principle of safety and simplicity to facilitate better patient care through innovation in line with our philosophy of Conscious caring</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n'),
(8, 'Empecs Medisign', 'images/brand/medisign.jpg', '<p style="text-align: justify;">Empecs Medisign has been specialized in manufacturing and sales of disposable medical devices since its founding in 1992 under the name of Tianjin Haing Lim Sou Won Medical Instrument Co. Ltd as a foreign-owned corporation. Their Bio-sensing Technology Laboratory in Korea has taken the lead from 2004 in making development of blood glucose monitoring system with assistance from scholars of famous universities and researchers of biochemistry institutes. The company has acquired related patent rights in China, Korea and U.S.A etc</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `categoryID` int(11) NOT NULL AUTO_INCREMENT,
  `categoryName` varchar(200) NOT NULL,
  `categoryImagePath` text NOT NULL,
  `categoryDesc` text NOT NULL,
  PRIMARY KEY (`categoryID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`categoryID`, `categoryName`, `categoryImagePath`, `categoryDesc`) VALUES
(5, 'Hospital Disposable Items', 'images/category/disposable.jpg', '<p>Includes Hospital disposable items such as adult diaper, disposable masks and caps, gauze than etc</p>\r\n'),
(6, 'Medical Devices', 'images/category/medicaldevices.jpg', '<p>Medical Devices include products like glucometer, digital thermometer and BP monitoring system</p>\r\n'),
(7, 'Hospital Equipments', 'images/category/hospitalequip.jpg', '<p>This category includes products like oxygen concentrator machine etc</p>\r\n'),
(8, 'Laboratory Items', 'images/category/laboratoryitems.jpg', '<p>Laboratory items include products like vaccuumtenner etc</p>\r\n'),
(9, 'Laboratory Reagent Kits', 'images/category/laboratoryreagent.jpg', '<p>Laoratory reagent&nbsp;kits include....</p>\r\n'),
(10, 'Wheelchair', 'images/category/wheelchair.jpg', '<p>Wheelchair includes simple wheelchair, comod wheelchair, bed type wheelchair, walking stick, crutches, comod chair and walker etc.</p>\r\n'),
(11, 'Others', 'images/category/others.jpg', '<p style="text-align: justify;">Others includes nebulizer, air mattress and pulse oximeter etc</p>\r\n'),
(12, 'Glass Slide', 'images/category/glass slide.jpg', '<p>glass slide includes glass slide plain and frosted etc</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `galleryimage`
--

CREATE TABLE IF NOT EXISTS `galleryimage` (
  `galleryimageID` int(11) NOT NULL AUTO_INCREMENT,
  `galleryimageName` varchar(250) NOT NULL,
  `galleryimageImagePath` text NOT NULL,
  PRIMARY KEY (`galleryimageID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `galleryimage`
--

INSERT INTO `galleryimage` (`galleryimageID`, `galleryimageName`, `galleryimageImagePath`) VALUES
(1, 'a1', 'images/gallery/1.jpg'),
(2, 'a2', 'images/gallery/2s.jpg'),
(3, 'a3', 'images/gallery/3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `newsID` int(11) NOT NULL AUTO_INCREMENT,
  `newsTitle` varchar(250) NOT NULL,
  `newsDesc` text NOT NULL,
  `newsImagePath` text NOT NULL,
  PRIMARY KEY (`newsID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `productID` int(11) NOT NULL AUTO_INCREMENT,
  `productName` varchar(200) NOT NULL,
  `productPrice` varchar(200) NOT NULL,
  `categoryID` int(11) NOT NULL,
  `brandID` int(11) NOT NULL,
  `productDesc` text NOT NULL,
  `productImagePath` text NOT NULL,
  `productEntryDate` date NOT NULL,
  `productStatus` varchar(200) NOT NULL,
  PRIMARY KEY (`productID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productID`, `productName`, `productPrice`, `categoryID`, `brandID`, `productDesc`, `productImagePath`, `productEntryDate`, `productStatus`) VALUES
(1, 'Blood Glucometer-Medisign', '1500', 6, 8, '<p>GOD Enzyme System</p>\r\n\r\n<p>5 Seconds Testing Time</p>\r\n\r\n<p>0.5 microliter whole blood sample</p>\r\n\r\n<p>300 memories</p>\r\n\r\n<p>Alternative Site Testing</p>\r\n\r\n<p>14 Day Average</p>\r\n\r\n<p>Pre/Post Meal Flag</p>\r\n', 'images/product/glucometer1.jpg', '2014-08-01', 'Defult'),
(2, 'Disposable Cap', '250', 5, 8, '<ul>\r\n	<li style="text-align: justify;">Manufactured from soft non-woven cloth</li>\r\n	<li style="text-align: justify;">specially designed to protect he patient against dropping of hair/dandruff of the doctors and other attending staff</li>\r\n	<li style="text-align: justify;">provided with stitched interlocking adaptable elastic for better grip on the forehead and comfortable fitting</li>\r\n	<li style="text-align: justify;">disposable sterile and Non Sterile</li>\r\n</ul>\r\n\r\n<p style="text-align: justify;">&nbsp;</p>\r\n', 'images/product/disposable_cap.jpg', '2014-08-01', 'Defult'),
(3, 'Disposable Mask', '250', 5, 8, '<p>This is new&nbsp;disposable mask</p>\r\n', 'images/product/disposable_mask.jpg', '2014-08-01', 'New'),
(4, 'Air Matress', '550', 11, 6, '<ul>\r\n	<li style="text-align: justify;">Items No: AM-01</li>\r\n	<li style="text-align: justify;">Max User Weight: 100-110 kgs</li>\r\n	<li style="text-align: justify;">Mattress Dimensions: 200*90 cm</li>\r\n	<li style="text-align: justify;">Materials: PVC 0.3mm</li>\r\n	<li style="text-align: justify;">Pump Air Output: 6-7 L/Min</li>\r\n	<li style="text-align: justify;">Pump Pressure Range: 70-130 mmHg</li>\r\n	<li style="text-align: justify;">Pump Electrical Power Supply: 220-240 Volts/100V, 60 Hz</li>\r\n</ul>\r\n', 'images/product/airmatress.jpg', '2014-07-18', 'New'),
(5, 'Pulsi Oximeter', '5000', 11, 6, '<ul>\r\n	<li style="text-align: justify;">Item No: JH-PX01</li>\r\n	<li style="text-align: justify;">Pusle oximeter finger</li>\r\n	<li style="text-align: justify;">Integrated with SpO2 probe and processing display module</li>\r\n	<li style="text-align: justify;">Small in volume, light in weight and convenient in carrying</li>\r\n	<li style="text-align: justify;">operation of the product is simple, low power consumption</li>\r\n</ul>\r\n', 'images/product/po-1.jpg', '2014-07-24', 'New'),
(6, 'Nebulizer', '2000', 11, 6, '<ul>\r\n	<li style="text-align: justify;">nebulizer with best price</li>\r\n	<li style="text-align: justify;">color optional</li>\r\n	<li style="text-align: justify;">low noise</li>\r\n	<li style="text-align: justify;">easy operation</li>\r\n	<li style="text-align: justify;">CE Rohs</li>\r\n	<li style="text-align: justify;">with mask and tube</li>\r\n	<li style="text-align: justify;">hope using nebulizer</li>\r\n</ul>\r\n', 'images/product/neb-1.jpg', '2014-07-16', 'Defult'),
(7, 'BP Monitoring System', '5000', 11, 6, '<ul>\r\n	<li style="text-align: justify;">Electronic Blood Pressure Monitor</li>\r\n	<li style="text-align: justify;">Atractive Design</li>\r\n	<li style="text-align: justify;">Perfect in craftmanship</li>\r\n	<li style="text-align: justify;">CE ROhs approval</li>\r\n	<li style="text-align: justify;">High level</li>\r\n</ul>\r\n', 'images/product/bp.jpg', '2014-06-18', 'Defult'),
(8, 'Oxygen Concentrator Machine', '3500', 7, 5, '<p><strong>Home oxygen concentrators</strong>&nbsp;are medical devices that deliver a concentrated flow of oxygen to an individual. In fact, an&nbsp;<strong>oxygen concentrator</strong>&nbsp;takes the ambient room air, concentrates it, and then delivers it to a person through a cannula. There are various reasons why an individual might need&nbsp;<strong>supplemental oxygen</strong>&nbsp;and it is best to check with your medical provider to see if you need to use a&nbsp;<em>home oxygen concentrator</em>.</p>\r\n\r\n<p style="text-align: justify;"><em>Home oxygen concentrators</em>&nbsp;are designed to be more stationary and deliver a continuous or flow of oxygen. Additionally,&nbsp;<em>home oxygen concentrators</em>&nbsp;are much safer than using an oxygen tank and is incredibly easy to operate.</p>\r\n', 'images/product/oxygen concentrator machine.jpg', '2014-07-15', 'Defult'),
(9, 'Oxygen Concentrator Machine 2', '5500', 7, 5, '<p><strong>Home oxygen concentrators</strong>&nbsp;are medical devices that deliver a concentrated flow of oxygen to an individual. In fact, an&nbsp;<strong>oxygen concentrator</strong>&nbsp;takes the ambient room air, concentrates it, and then delivers it to a person through a cannula. There are various reasons why an individual might need&nbsp;<strong>supplemental oxygen</strong>&nbsp;and it is best to check with your medical provider to see if you need to use a&nbsp;<em>home oxygen concentrator</em>.</p>\r\n\r\n<p style="text-align: justify;"><em>Home oxygen concentrators</em>&nbsp;are designed to be more stationary and deliver a continuous or flow of oxygen. Additionally,&nbsp;<em>home oxygen concentrators</em>&nbsp;are much safer than using an oxygen tank and is incredibly easy to operate.</p>\r\n', 'images/product/oxygen concentrator machine2.jpg', '2014-07-09', 'New'),
(10, 'Commode Wheelchair', '4500', 10, 5, '<p style="text-align: justify;">This is commod wheelchair</p>\r\n', 'images/product/commodewheelchair.jpg', '2014-08-13', 'Defult'),
(11, 'Vac Set', '570', 5, 7, '<ul>\r\n	<li style="text-align: justify;"><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">Two Redon drain tube provided with RO line and smooth eyes for two check &amp; discuss drainage in case of need.</span></li>\r\n	<li style="text-align: justify;"><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">Smooth and atraumatic multiple eyes for easy drainage and prevents post operative trauma.</span></li>\r\n	<li style="text-align: justify;"><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">Trocar needle assist in placement of catheter inside wound.</span></li>\r\n	<li style="text-align: justify;"><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">Depending on need different sizes of Redon Drain tube and Trocar available.</span></li>\r\n	<li style="text-align: justify;"><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">Leak proof cap and single step pinch clamp for easy and one hand operation.</span></li>\r\n	<li style="text-align: justify;"><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">Main connecting tube has been equipped with colour coded Y connector to connect compatible redon tube.</span></li>\r\n</ul>\r\n', 'images/product/vac set.jpg', '2014-07-08', 'New'),
(12, 'Resuscitators', '5500', 8, 7, '<ul>\r\n	<li style="text-align: justify;"><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">Complete kit has star lumen oxygen tube, reservoir bag, silicon mask, resuscitator bag and pressure release valve.</span></li>\r\n	<li style="text-align: justify;"><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">Good recoiling property after pressing during resuscitation.</span></li>\r\n	<li style="text-align: justify;"><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">360&deg; rotation of connectors between patient &amp; resuscitation bag.</span></li>\r\n	<li style="text-align: justify;"><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">Made from 100% silicon, autoclavable.</span></li>\r\n	<li style="text-align: justify;"><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">Non-Sterile.</span></li>\r\n</ul>\r\n', 'images/product/resuscitators.jpg', '2014-06-25', 'Defult'),
(13, 'Rylo', '450', 9, 7, '<ul>\r\n	<li style="text-align: justify;"><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">X-Ray line facilitates detection during passage to duodenum.</span></li>\r\n	<li style="text-align: justify;"><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">Soft rounded distal end with solid RO material sealed into the tube, to assist the passage of the tube during intubation.</span></li>\r\n	<li style="text-align: justify;"><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">Four lateral eyes are provided for efficient aspiration and administration</span></li>\r\n	<li style="text-align: justify;"><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">Colour coded Universal funnel shape connector with cap for easy identification of sizes provided at proximal end.</span></li>\r\n	<li style="text-align: justify;"><span style="color:rgb(102, 102, 102); font-family:arial,helvetica,sans-serif; font-size:13px">Made from non-toxic, medical grade P.V.C. material.</span></li>\r\n</ul>\r\n', 'images/product/Rylo.jpg', '2014-07-17', 'New'),
(14, 'Glass Slide', '550', 12, 7, '<p style="text-align: justify;"><span style="color:rgb(0, 0, 0); font-family:arial,helvetica,sans-serif; font-size:12px">We are a well-reputed&nbsp;</span><strong>Glass Slides</strong><span style="color:rgb(0, 0, 0); font-family:arial,helvetica,sans-serif; font-size:12px">&nbsp;Exporters and Suppliers. Our Glass Slides are procured from trusted vendors who maintain high hygiene level throughout the production process. Our Glass Slides are resistant to chemical reactions and temperature changes. Our Glass Slides are therefore widely demanded by hospitals, clinics, pathological labs and research project work centers. Our Glass Slides are cost-effective solution for diverse laboratory applications.&nbsp;</span></p>\r\n', 'images/product/glassslide.jpg', '2014-07-23', 'New');

-- --------------------------------------------------------

--
-- Table structure for table `sliderimage`
--

CREATE TABLE IF NOT EXISTS `sliderimage` (
  `sliderimageID` int(11) NOT NULL AUTO_INCREMENT,
  `sliderimageImagePath` text NOT NULL,
  PRIMARY KEY (`sliderimageID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `sliderimage`
--

INSERT INTO `sliderimage` (`sliderimageID`, `sliderimageImagePath`) VALUES
(4, 'images/bigslider/1.jpg'),
(5, 'images/bigslider/3.jpg'),
(6, 'images/bigslider/4.jpg'),
(7, 'images/bigslider/6.jpg'),
(8, 'images/bigslider/5.jpg'),
(9, 'images/bigslider/slide-1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `welcome`
--

CREATE TABLE IF NOT EXISTS `welcome` (
  `welcomeID` int(11) NOT NULL AUTO_INCREMENT,
  `welcomeTitle` varchar(200) NOT NULL,
  `welcomeDesc` text NOT NULL,
  PRIMARY KEY (`welcomeID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `welcome`
--

INSERT INTO `welcome` (`welcomeID`, `welcomeTitle`, `welcomeDesc`) VALUES
(1, 'One Med Health Welcomes You', '<p>Namaste!&nbsp;</p>\r\n\r\n<p style="text-align:justify">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Welcome to One Med Health Surgical House. We provide different range of surgical items from different brands over the world. Our products include different wheelchair items, BP monitoring devices, glucometer, glass slides and many more.&nbsp;Make sure to pay visit to our site&nbsp;and let us offer you our services.</p>\r\n\r\n<p style="text-align:justify">Thank you!</p>\r\n');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
include("cms_admin/connect1.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>MRS Surgical House</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">
</head>

<body>
  <?php include('include/header.php') ?>
  	<div class="container well" style="margin-top:20px;">
        <div class="row clearfix">
             <div class="col-md-12 column ">
                    <h1>News And Events</h1>
                    <?php
                      $sql="Select * from news;";
                      $result=mysqli_query($connect,$sql) or die("Error in mysql: ".mysqli_error());
                      while ($row=mysqli_fetch_array($result)){
                        $newstitle=$row['newsTitle'];
                        $newsimagepath=$row['newsImagePath'];
                        $newsdesc=$row['newsDesc'];
                        if ($newsimagepath=="images/news")
                        {
                      ?>
                      <div class="row">
                          <div class="col-md-2">
                              <img src="images/news/defaultnews.jpg" class="img-thumbnail" alt=" <?php echo $newstitle; ?>">  
                          </div>
                          <div class="col-md-10">
                                <h3><?php echo $newstitle;?></h3>
                                <p><?php echo $newsdesc;?></p>  
                          </div>
                      </div>
                    

                   <?php
                      }
                      else
                      {
                    ?>
                     <div class="row">
                          <div class="col-md-2">
                              <img src="<?php echo $newsimagepath;?>" class="img-thumbnail" alt=" <?php echo $newstitle; ?>">  
                          </div>
                          <div class="col-md-10">
                                <h3><?php echo $newstitle;?></h3>
                                <p><?php echo $newsdesc;?></p>  
                          </div>
                      </div> 
                    <?php
                        }
                      }
                    ?>


             </div>
        </div>
    </div>
  <?php include('include/footer.php') ?>

</body>
</html>

<?php
include('cms_admin/connect1.php');
?>
<!DOCTYPE html>
<html lang="en">
<title>MRS Surgical House</title>
<head>
  <meta charset="utf-8">

  <scrip src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDY0kkJiTPVd2U7aTOAwhc9ySH6oHxOIYM&sensor=false">
</script>

<script>
function initialize()
{
var mapProp = {
  center:new google.maps.LatLng(27.685698,85.31918),
  zoom:5,
  mapTypeId:google.maps.MapTypeId.ROADMAP
  };
var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
}

google.maps.event.addDomListener(window, 'load', initialize);
</script>
  <title>MRS</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the browser URL, then refresh the page. -->
	
	
</head>

<body>
  <?php include('include/header.php') ?>
  	<div class="container well" style="">
        <div class="row clearfix ">
          <div class="col-md-5 column" >
			         <h1>Contact Us</h1>
             	<p class="text-info"><span>Address:</span> Tripureshwor-11, Kathmandu, Nepal <br />
                <span>Telephone:</span> +977-01-4101129,4100504<br />
                <span>E-mail:</span> nepal_mrscompany@yahoo.com	
              </p>
                <h2>Send us mail</h2>
                <form action="#" method="post" id="sendemail" role="form" class="">
                    <div class="form-group ">
                          <div>
                              <label for="name">Name (required)</label>
                              <input id="name" name="name" class="form-control" />
                          </div>
                          <div>
                              <label for="exampleInputEmail1">Email Address (required)</label>
                              <input  name="email" class="form-control" id="exampleInputEmail1"/>
                          </div>
                          <div>
                              <label for="website">Website</label>
                              <input id="website" name="website" class="form-control" />
                          </div>
                          <div>
                              <label for="message">Your Message</label>
                              <textarea id="message" name="message" rows="8" cols="50" class="form-control"></textarea><br />
                          </div>
                          <button type="button" class="btn btn-primary">Submit</button>
                    </div>
              	</form>
          </div>

			    <div class="col-md-6">
            <div class="well wel-sm">
                <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script><div style="overflow:hidden;height:500px;width:500px;"><div id="gmap_canvas" style="height:500px;width:500px;"></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style><a class="google-map-code" href="http://www.mapsembed.com/redcoon-gutschein/" id="get-map-data">http://www.mapsembed.com</a></div><script type="text/javascript"> function init_map(){var myOptions = {zoom:18,center:new google.maps.LatLng(27.685698246365988,85.31901750115821),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(27.685698246365988, 85.31901750115821)});infowindow = new google.maps.InfoWindow({content:"<b>Hi-Tech skills</b><br/>Jwagal<br/> Lallitpur" });google.maps.event.addListener(marker, "click", function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>  
            </div>
          </div>  
        </div>
    </div>
 <?php include('include/footer.php') ?>

</body>
</html>

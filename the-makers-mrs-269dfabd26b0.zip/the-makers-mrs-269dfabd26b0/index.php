<?php
include('cms_admin/connect1.php');
$a=1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>MRS Surgical House</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the browser URL, then refresh the page. -->
	
</head>

<body>
<?php include('include/header.php') ?>
	<div class="container">
    <div class="row clearfix well-lg" style=" margin-top:-20px">
        <div class="col-md-12 column">
            <div class="carousel slide" id="carousel-323560">
                <div class="carousel-inner">
                  <?php
                    $s1="Select * from sliderimage;";
                    $q1=mysqli_query($connect, $s1) or die ("Error in Mysqli: ".mysqli_error($connect));
                    while($r1=mysqli_fetch_array($q1)){

                      $imgpath=$r1['sliderimageImagePath'];
                      $imgid=$r1['sliderimageID'];
                      $arr=explode("/",$imgpath);
                      $imgnm=$arr[2];
                      if ($a==1){
                ?>
                <div class="item active">
                  <img src="<?php echo $imgpath;?>" alt="<?php echo $imgnm; ?>">
                </div>
                <?php
              }
              else{
                
                ?>
                <div class="item">
                  <img src="<?php echo $imgpath;?>" alt="<?php echo $imgnm; ?>">
                </div>
                <?php
              }
                $a++;
              
            }
            ?>
                </div> 
                <a class="left carousel-control" href="#carousel-323560" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a> <a class="right carousel-control" href="#carousel-323560" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
            </div>
        </div>
    </div> 
  </div>
  <div class="container custom-well">       
      <h3>Our Categories</h3>
      <div class="row">
        <div class="cl-md-12">
          <?php include('include/category_slider.php'); ?> 
        </div>                        
      </div>
    <h3>Popular Products</h3>
      <div class="row">
      <?php
        $sql2="select * from product where productStatus='New' limit 4;";
        $result2=mysqli_query($connect,$sql2) or die("Error in Mysql :".mysqli_error($connect));
        while($row2=mysqli_fetch_array($result2)){
          $proName=$row2['productName'];
          $proPrice=$row2['productPrice'];
          $proImage=$row2['productImagePath'];
          $pId=$row2['productID'];
        ?>
        <div class="col-lg-3" style="padding:10px;">
          <div class="hover-over" align="middle">
            <img src="<?php echo $proImage; ?>" alt="<?php echo $proName; ?>" class="img-thumbnail custom-image">
            <strong><p style="height:60px;"><?php echo $proName; ?></p></strong>
            <p>Price: Rs <?php echo $proPrice; ?></p>
           <a href="<?php echo "product_details.php?iddetail=".$pId;?>"> <p class="btn btn-success">Learn More</p></a>
          </div>
        </div>
        <?php
      }
      ?>
        <a href="products_status.php" class="btn btn-danger" style="float:right;">See More</a>
      </div>
  </div>
  <div class="container">
    <div class="row">
      <div class="col-md-12" >            
            <div class="">
                <h2>Chair Man Voice</h2>
                    <div class="clr"></div>
                    <img src="img/img2.jpg" height=""  class=" center-block img-thumbnail img-responsive" /> 
                <p>
                  Aliquam mi erat, aliquam vel luctus eu, pharetra quis elit. Nulla euismod ultrices massa, et feugiat ipsum consequat eu. Aliquam mi erat, aliquam vel luctus eu, pharetra quis elit. Nulla euismod ultrices massa, et feugiat ipsum consequat eu.  Aliquam mi erat, aliquam vel luctus eu, pharetra quis elit. Nulla euismod ultrices massa, et feugiat ipsum consequat eu.
                </p>
             </div>
        </div>
    </div>
  </div>
  
<?php include('include/footer.php') ?>

</body>
</html>

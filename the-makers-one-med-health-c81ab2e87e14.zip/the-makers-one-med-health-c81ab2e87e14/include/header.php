<?php
?>
<!------ CSS & JS ------>       
  <link rel="stylesheet" href="css/bootstrap.css"> 
  <link rel="stylesheet" href="css/bootswatch.css">      
  <link rel="stylesheet" href="css/custom-css.css">
  <link rel="stylesheet" href="css/sidemenu.css">
  <link rel="stylesheet" href="css/smoothzoom.css">
  <link rel="stylesheet" href="css/menustyles.css">

  <script src="js/jquery-latest.min.js" type="text/javascript"></script>
  <script src="js/menuscript.js"></script>
  <script src="js/ajax.googleapis"></script>  
  <script src="js/modernizr.js"></script>    
  <script src="js/jquery.min.js" type="text/javascript"></script>
  <script src="js/modernizr.custom.17475.js" type="text/javascript"></script>
  <script src="js/jquery-1.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="js/bootswatch.js"></script>

<!------ --------- ------>

<div class="container">
  <div class="row">
    <div class="col-md-3">
      <div style="margin-bottom:20px;">
        <img src="images/thumbnails/thumb200x100.png">
      </div>
    </div>
  </div>
  
  <div id='maincssmenu' style="margin-bottom:20px;">
    <ul>
       <li><a href='index.php'><span class="glyphicon glyphicon-home"></span><span> Home</span></a></li>
       <li class='active has-sub'><a href='#'><span class="glyphicon glyphicon-barcode"></span><span> Products <span class="caret"></span></span></a>
          <ul>
             <?php
              $sql1="select * from category;";
              $result1=mysqli_query($connect, $sql1) or die("Error in Mysql :".mysqli_error($connect));
              while ($row1=mysqli_fetch_array($result1)){
            ?>
              <li><a href="<?php echo "categories.php?id=".$row1['categoryID'];?>"><?php echo $row1['categoryName'];?></a></li>
            <?php
              }
            ?>
             
          </ul>
       </li>
       <li class='active has-sub'><a href='#'> <span class="glyphicon glyphicon-hdd"></span><span> Brands <span class="caret"></span></span></a>
          <ul>
             <?php
               $sql2="select * from brand;";
               $result2=mysqli_query($connect, $sql2) or die("Error in Mysql :".mysqli_error());
               while ($row2=mysqli_fetch_array($result2))
               {
            ?>
              <li><a href="<?php echo "brands.php?id=".$row2['brandID']; ?>"><?php echo $row2['brandName']; ?></a></li>
            <?php
              }
            ?>
          </ul>
       </li>
       <li><a href='about_us.php'><span><span class="glyphicon glyphicon-info-sign"></span> About</span></a></li>
       <li class='last'><a href='contact_us.php'><span class="glyphicon glyphicon-earphone"></span><span> Contact</span></a></li>
       <li class="no-hover">
          <div class="search">
            <form action="search.php" method="get">
              <input type="search" placeholder="Search Products" name="pnm">
            </form>
          </div>
        </li>
    </ul>   
  </div>
</div>
        
          

       
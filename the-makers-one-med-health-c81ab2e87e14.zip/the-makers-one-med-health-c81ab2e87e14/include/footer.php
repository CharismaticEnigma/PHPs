<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript" src="js/smoothzoom.js"></script>
<script type="text/javascript">
    $(window).load( function() {
        $('img').smoothZoom({
            // Options go here
        });
    });
</script>
<div class="container" style="border-bottom:1px solid #382356;">
	<div class="row">
		<div class="col-md-3">
			<h4>Categories</h4>
			<div class="custom-link">
			<?php
			$sqlc="select * from category limit 4;";
			$resultc=mysqli_query($connect,$sqlc) or die("Error in Mysql :".mysqli_error($connect));
			while($rowc=mysqli_fetch_array($resultc)){
			?>
				<p><a href="<?php echo "categories.php?id=".$rowc['categoryID'];?>"><?php echo $rowc['categoryName'];?></a></p>
			<?php
			}
			?>
			</div>
		</div>
		<div class="col-md-3">
			<h4>Brands</h4>
			<div style="color:#494949;">
			<?php
			$sqlb="select * from brand limit 4;";
			$resultb=mysqli_query($connect,$sqlb) or die("Error in Mysql :".mysqli_error($connect));
			while($rowb=mysqli_fetch_array($resultb)){
			?>
				<p><a href="<?php echo "brands.php?id=".$rowb['brandID']; ?>"><?php echo $rowb['brandName'];?></a></p>
			<?php
			}
			?>
			</div>
		</div>
		<div class="col-md-3">
			<h4>Contact Us</h4>
			<div style="color:#494949;">
				<p><span class="glyphicon glyphicon-pushpin"></span> Address: xyz</p>
				<p><span class="glyphicon glyphicon-phone-alt"></span> Phone: 123</p>
				<p><span class="glyphicon glyphicon-envelope"></span> Email: xyz@123.com</p>
			</div>
		</div>
		<div class="col-md-3">
			<h4>Follow Us</h4>
			<img src="images/social/facebook.png" alt="Facebook">
			<img src="images/social/twitter.png" alt="Twitter">
		</div>
	</div>		
</div>
<div class="container" style="margin-top:20px">
	<div class="copyright" align="middle">
		<p>Copyright &copy 2014 One Med Health. All rights reserved</p>
		<p>Powered By: <a href="http://www.hitechskills.com">Hi-Tech Skills</a></p>
	</div>
</div>	
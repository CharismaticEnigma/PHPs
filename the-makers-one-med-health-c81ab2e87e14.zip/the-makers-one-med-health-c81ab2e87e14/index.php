<?php
include('cms_admin/connect1.php')
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>One Med Health</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
	<div class="container">
		<div class="row">
			<div class="col-md-8">
				<?php 
					include('include/slider.php')
				?>
			</div>
			<div class="col-md-4">
				<div class="custom-well">
				<?php
				$sq1="Select * from welcome;";
				$qr1=mysqli_query($connect,$sq1) or die("Error in mysqli:". mysqli_error($connect));
				$rs=mysqli_fetch_array($qr1);
				$title=$rs['welcomeTitle'];
				$desc=$rs['welcomeDesc'];
				?>
					<h2><?php echo $title; ?></h2>
					<p align="justify"><?php echo $desc; ?></p>
					<a href="contact_us.php" class="btn btn-info">Contact Info</a>
				</div>
			</div>
		</div>
		
	</div>
	<div class="content">
		<div class="container">
			<h3>New Products</h3>
			<div class="row">
			<?php
				$sql2="select * from product where productStatus='New' limit 4;";
				$result2=mysqli_query($connect,$sql2) or die("Error in Mysql :".mysqli_error($connect));
				while($row2=mysqli_fetch_array($result2)){
					$proname=$row2['productName'];
					$proprice=$row2['productPrice'];
					$proimage=$row2['productImagePath'];
					$pid=$row2['productID'];
				?>
			
					<div class="col-lg-3" style="padding:10px;">
						<div class="hover-over" align="middle">
							<img src="<?php echo $proimage; ?>" alt="<?php echo $proname; ?>" class="img-thumbnail custom-image">
							<strong><p><?php echo $proname; ?></p></strong>
							<p>Price: <?php echo "Rs ".$proprice; ?></p>
							<a href="<?php echo "product_details.php?iddetail=".$pid;?>"><p class="btn btn-danger">Learn More</p></a>
						</div>
					</div>
				<?php
				}
				?>
				
				<a href="products_status.php" class="btn btn-primary" style="float:right;">See More</a>
			</div>
			<hr>
			<div class="row">
				<div class="col-md-7">
					<h3>Brands</h3>
					<?php include('include/our_brands.php'); ?>
				</div>
				<div class="col-md-5">
					<h3>Message From CEO</h3>
					<p align="justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
				</div>				
			</div>
		</div>
	</div>
	<?php include('include/footer.php');?>	
</body>
</html>
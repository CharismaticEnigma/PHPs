<?php
class Aboutpage
{
	function insertAbout(){
		include("connect1.php");	
		$name=$_POST['nm'];		
		$desc=$_POST['desc'];
		$noimage="noimage";

		//the php script to upload the image
		$imagename = $_FILES["newsimg"]["name"];
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		//path to put into the database table
		$path = "images/about/article/$imagename";
		
		//actual server destination folder
		$dest = "../images/about/article/$imagename";
		$arr = explode(".",$imagename);
		//check whether the extention is correct
		$ext = $arr[1];
		
			if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG') or($ext==''))
			{
				if($ext=='')
				{
					$sql= "insert into about (aboutName,aboutDesc,aboutImagePath) values ('$name','$desc','$noimage');";
			
					mysqli_query($connect, $sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
					echo "data sucessfully added";
				}	
				elseif(file_exists($dest)){
					echo "an image with that name already exists.. Please change your file";
				}
				else{
						copy($tmpimage,$dest);
						
						$sql= "insert into about (aboutName,aboutDesc,aboutImagePath) values ('$name','$desc','$path');";
						mysqli_query($connect, $sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error());
						echo "data sucessfully added";
									
									//@rename($dest,"../studpics/$id.$ext");	
				}

			}
			else
			{
				echo "invalid photo! try again.";
				exit;
			}
				//upload script ends.
		
		
					
		//header('location:add_brand.php');
	}

	function editAbout(){

		$id=$_POST['id'];
		$nm=$_POST['nm'];
		$desc=$_POST['desc'];

		include("connect1.php");

		if(isset($nm) && $nm !=Null){
			$sqlup=mysqli_query($connect, "Update about Set aboutName='$nm' where aboutID='$id'");	
		}
		if(isset($desc)&& $desc !=Null){
			$sqlup=mysqli_query($connect, "Update about Set aboutDesc='$desc' where aboutID='$id'");	
		}
		//the php script to upload the image
		$imagename = $_FILES["newsimg"]["name"];
		//echo $imagename;
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		//path to put into the database table
		$path = "images/about/article/$imagename";
		
		//actual server destination folder
		$dest = "../images/about/article/$imagename";
		//echo "Destination: ".$dest;
		
		if (isset($imagename) && $imagename!= Null)
		{
		$arr = explode(".",$imagename);
		//check whether the extention is correct
		$ext = $arr[1];
		
		if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG') or($ext==''))
		{	
				if(file_exists($dest)){
			echo "an image with that name already exists.. Please change your file";
		}
		else{
			if(isset($path) && $path !=Null){

			$sql1="Select * from about where aboutID='$id';";
			$res=mysqli_query($connect, $sql1);
			while($row1 = mysqli_fetch_array($res))
			{
 				 //echo $row1['headingImagePath'];
 				 $imgs=$row1['aboutImagePath'];
 				 //echo $imgs;
 				 //echo $row1['headingImageName'];
 				$arr=array();
 				 $arr= (explode ("/",$imgs));
 				 //echo $arr[2];
 				 $cdr=getcwd();
 				 chdir("../images/about/article");
 				unlink($arr[3]);
 			}
 			chdir($cdr);
 			//echo "Recent dir: ".getcwd();
 			copy($tmpimage,$dest);
			$sqlup=mysqli_query($connect, "Update about Set aboutImagePath='$path' where aboutID='$id'");	

			}
			//copy the temporarily uploaded file to the server destination (actual upload)
			}
			}
		} 	
	}

}
$Aboutpage = new Aboutpage();
?>
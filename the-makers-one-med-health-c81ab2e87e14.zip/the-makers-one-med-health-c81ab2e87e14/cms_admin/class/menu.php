   <?php
   ?>
   <div id="menu">
        <ul>
       <li><a href="#">Brand</a>
                <ul>
                    <li class="top"><a href="add_brand.php"> Add Brand</a></li>
                    <li><a href="edit_delete_brand.php">Edit/Delete Brand</a></li>					
					</ul>
            </li>
					
			<li class="first"><a href="#">Category</a>
                <ul>
                    <li class="top"><a href="add_category.php"> Add category</a></li>
					<li class="top"><a href="edit_delete_category.php"> Edit/Delete Category</a></li>
                    </ul>
            </li>
			
			<li class="first"><a href="#">Slider Image</a>
                <ul>
                    <li class="top"><a href="add_slider1.php"> Add Image for Big Slider</a></li>
					<li class="top"><a href="edit_delete_slider1.php"> Delete Image for Big Slider</a></li>
                    </ul>
            </li>
            <li class="first"><a href="#">Product</a>
                <ul>
                    <li class="top"><a href="add_product.php"> Add New Product</a></li>
                    <li class="top"><a href="edit_delete_product.php"> Edit/Delete Product With Category</a></li>
                    </ul>
            </li>
            <li class="first"><a href="#">About</a>
                <ul>
                    <li class="top"><a href="add_about.php"> Add New Article</a></li>
                    <li class="top"><a href="edit_delete_about.php"> Edit/Delete Article</a></li>
                    </ul>
            </li>
            <li class="first"><a href="welcome_edit.php">Edit Welcome Note</a>
            </li>
			
			
			<?php
			/*
            <li class="first"><a href="#">Career</a>
                <ul>
                    <li class="top"><a href="career_main_add.php"> Add Main Heading</a></li>
                    <li><a href="career_main_edit-delete.php">Edit/Delete Main Heading</a></li>
                    <li><a href="career_sub_add.php">Add Sub Heading</a></li>
                    <li><a href="career_sub_edit-delete.php">Edit/Delete Sub Heading</a></li>
                    </ul>
            </li>
            <li><a href="#">Services</a>
                <ul>
                    <li class="top"><a href="service_main_add.php"> Add Main Heading</a></li>
                    <li><a href="service_main_edit-delete.php">Edit/Delete Main Heading</a></li>
                    <li><a href="service_sub_add.php">Add Sub Heading</a></li>
                    <li><a href="service_sub_edit-delete.php">Edit/Delete Sub Heading</a></li>
                    </ul>
            </li>
            <li class="first"><a href="#">Training</a>
                <ul>
                    <li class="top"><a href="training_main_add.php"> Add Main Heading</a></li>
                    <li><a href="training_main_edit-delete.php">Edit/Delete Main Heading</a></li>
                    <li><a href="training_sub_add.php">Add Sub Heading</a></li>
                    <li><a href="training_sub_edit-delete.php">Edit/Delete Sub Heading</a></li>
                    </ul>
            </li>
             <li><a href="#">Hosting Plans</a>
                    <ul>
                    <li class="top"><a href="hosting_add.php"> Add Hosting Plan</a></li>
                    <li><a href="hosting_edit.php">Edit/Delete Hosting Plan</a></li>
                    </ul>
            </li>
            <li><a href="#">Staff</a>
                    <ul>
                    <li class="top"><a href="staff_image_add.php"> Add Staffs</a></li>
                    <li><a href="staff_image_delete.php">Edit/Delete Staffs</a></li>
                    </ul>
            </li> */ ?>            
           </ul>
    </div>
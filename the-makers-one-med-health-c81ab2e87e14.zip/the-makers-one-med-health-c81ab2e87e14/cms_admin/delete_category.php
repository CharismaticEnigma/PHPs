<?php
	include("connect.php");

	$a = $_GET['dele'];
	$sql1="select * from product where categoryID='$a';";
	$res1=mysqli_query($connect, $sql1) or die ("error in mysql :".mysqli_error($connect));
	$row1=mysqli_num_rows($res1);
	if ($row1>=1){
		echo "this category contains product first delete those product";
	}
	else{
		if(isset($a)){
		$sql1="Select * from category where categoryID='$a';";
		$res=mysqli_query($connect, $sql1);
		while($row1 = mysqli_fetch_array($res))
			{
 				$imgs=$row1['categoryImagePath'];
 				$arr=array();
 				$arr= (explode ("/",$imgs));
 				chdir("../images/category");
 				unlink($arr[2]);
 			}
		$sql2="delete from category where categoryID='$a';";
	   	$res2=mysqli_query($connect, $sql2) or die ("error in mysql :".mysqli_error());
		$row2=mysqli_fetch_array($res2);
		//echo "file deleted";
		header('location:edit_delete_category.php');
	}
	
	}
	
	
?>
<?php
include("cms_admin/connect1.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>One Med Health</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">			
			<div class="row">
				<div class="col-lg-3">
					<?php
						include('include/sidebar.php');
					?>
				</div>
				<div class="col-lg-9">
				<?php
				$detailid=$_GET['iddetail'];
				$sql1="select * from product where productID='$detailid';";
				$result1=mysqli_query($connect,$sql1) or die("Error in Myslq : line 32".mysqli_error($connect));
				while($row1=mysqli_fetch_array($result1))
				{
					$name=$row1['productName'];
					$price=$row1['productPrice'];
					$cid=$row1['categoryID'];
					$bid=$row1['brandID'];
					$desc=$row1['productDesc'];
					$imagepath=$row1['productImagePath'];
				}
				//for brand name
				$sql2="select * from brand where brandID='$bid';";
				$result2=mysqli_query($connect,$sql2) or die("Error in Myslq : line 39".mysqli_error($connect));
				$row2=mysqli_fetch_array($result2);
				$brandname=$row2['brandName'];

				//for category name
				$sql3="select * from category where categoryID='$cid';";
				$result3=mysqli_query($connect,$sql3) or die("Error in Myslq : line 39".mysqli_error($connect));
				$row3=mysqli_fetch_array($result3);
				$categoryname=$row3['categoryName'];
					?>

					<h3><?php echo $name; ?></h3>
					<div class="row">				
						<div class="col-md-6">
							<img src="<?php echo $imagepath; ?>" alt="<?php echo $name; ?>" class="pro-details img-thumbnail" style="margin-bottom:8px;" rel="zoom">
						</div>
						<div class="col-md-6">
							<h4 style="color:#005E40; margin-top:-3px;"><?php echo $name; ?></h4>
							<h4 style="color:#BC0000"><?php echo "Rs ".$price; ?></h4>
							
							<h4>Overview</h4>
							<p align="justify"><?php echo $desc; ?></p>						

							<table class="table table-bordered table-hover">
								<tr>
									<td><strong>Category</strong></td>
									<td><?php echo $brandname; ?></td>								
								</tr>
								
								<tr>
									<td><strong>Brand</strong></td>
									<td><?php echo $categoryname; ?></td>
								</tr>
							</table>
						</div>						
					</div>					
				</div>
			</div>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
include("cms_admin/connect1.php");
$success=0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>One Med Health</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">			
			<div class="row">
				<div class="col-lg-3">
					<?php
						include('include/sidebar.php');
					?>
				</div>
				<div class="col-lg-9">
					<h3>Our Products</h3>
					<div class="row">
				<?php
					$prodName=$_GET['pnm'];
					if($prodName=="" || $prodName==null || $prodName==" "){

						echo "Please provide your search values to proceed the search Query";
					}
					else{

					$finalVal="%".$prodName."%";
					$a1=str_replace("'","",$finalVal);
						$st2="Select * from product where productName like '$a1';";
						$rs2=mysqli_query($connect, $st2) or die ("Mysqli error: ".mysqli_error($connect));
						$count=mysqli_num_rows($rs2);
						if($count==0){
							echo "Sorry! your query returned no results! Please try again with refined search";
						}
						else{


						while ($qr2=mysqli_fetch_array($rs2)){

					
						?>
						<!-------------- Repeat -------------->

						<div class="col-lg-4" style="padding:10px;">
							<div class="hover-over" align="middle">
								<img src="<?php echo $qr2['productImagePath']; ?>" alt="<?php echo $qr2['productName']; ?>" class="img-thumbnail custom-image">
								<strong><p><?php echo $qr2['productName']; ?></p></strong>
								<p><?php echo "Rs. ".$qr2['productPrice']; ?></p>
								<a href="<?php echo "product_details.php?iddetail=".$qr2['productID'];?>"><p class="btn btn-danger">Learn More</p></a>
							</div>
						</div>
					<!-------------- Repeat -------------->
						<?php
						}
							}
						}
					
				?>
					<!-------------- Repeat -------------->

								
					
				</div>
			</div>
		</div>
	<!------------------------ Main CONTENT ends here  ------------------------>

    </div>
    </div>
</body>
<?php
	include('include/footer.php');
?>
</html>
<?php
include('cms_admin/connect1.php');
$val="";
$pgnm="news.php";
////////////////////////////////////////////// FOR NEPALI CONTENTS ///////////////////////////////////
 if((isset($_GET['contType']))=="nep"){
	//echo "you are going to see in nepali";
	$val="nep";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>भि.पि.एच.अो - समाचार​</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<h3>समाचार​</h3>
		<ul class="media-list">
			<!------ Repeat ------>
			<?php
				$s1="Select * from news;";
				$qr1=mysqli_query($connect,$s1) or die("Error in Mysqli: ".mysqli_error($connect));
				while($rs1=mysqli_fetch_array($qr1)){
					$newsID=$rs1['newsID'];
						$newsNm=$rs1['newsName1'];
						$newsName=$rs1['newsImagePath'];
						$newsDesc=$rs1['newsDesc1'];
			?>
			<li class="media">
				<h4><?php echo $newsNm; ?></h4>
				<img src="<?php echo $newsName;?>" alt="<?php echo $newsNm; ?>" class="media-object pull-left custom-image" />
					<div class="media-body">
						<p align="justify"><?php echo $newsDesc?></p>
					</div>
			</li>
			<?php		
				}
			?>
			<!------ Repeat ------>
			
		</ul>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
}
////////////////////////////////////////////// FOR ENGLISH CONTENTS ///////////////////////////////////
else{
	//echo "you are going to see in english";
	$val="eng";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>VPHO - News</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<h3>News</h3>
		<ul class="media-list">
			<!------ Repeat ------>
			<?php
				$s1="Select * from news;";
				$qr1=mysqli_query($connect,$s1) or die("Error in Mysqli: ".mysqli_error($connect));
				while($rs1=mysqli_fetch_array($qr1)){
					$newsID=$rs1['newsID'];
						$newsNm=$rs1['newsName'];
						$newsName=$rs1['newsImagePath'];
						$newsDesc=$rs1['newsDesc'];
			?>
			<li class="media">
				<h4><?php echo $newsNm; ?></h4>
				<img src="<?php echo $newsName;?>" alt="<?php echo $newsNm; ?>" class="media-object pull-left custom-image" />
					<div class="media-body">
						<p align="justify"><?php echo $newsDesc?></p>
					</div>
			</li>
			<?php		
				}
			?>
			<!------ Repeat ------>
		</ul>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
	}
?>

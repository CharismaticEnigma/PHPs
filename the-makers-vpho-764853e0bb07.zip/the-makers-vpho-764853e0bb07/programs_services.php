<?php
include('cms_admin/connect1.php');
$val="";
$pgnm="programs_services.php";
////////////////////////////////////////////// FOR NEPALI CONTENTS ///////////////////////////////////
 if((isset($_GET['contType']))=="nep"){
	$val="nep";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>भि.पि.एच.अो- कार्यक्रम र सेवाहरु</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">		
		<div class="row">
			<div class="col-md-9">
			<h3>कार्यक्रम र सेवाहरु <!-- Programs & Services --></h3>
			<?php
				$sql1="select * from others where othersID='1';";
				$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
				$row1=mysqli_fetch_array($result1);
				$othersname1=$row1['othersName1'];
				$othersdesc1=$row1['othersDesc1'];
			?>	
				<h4 style="margin-top:30px;"><?php echo $othersname1;?></h4>
				<ul>
				<p align="justify"><?php echo $othersdesc1; ?></p>			
				</ul>

				<?php
				$sql2="select * from others where othersID='2';";
				$result2=mysqli_query($connect,$sql2) or die("Error in Mysql :".mysqli_error($connect));
				$row2=mysqli_fetch_array($result2);
				$othersname2=$row2['othersName1'];
				$othersdesc2=$row2['othersDesc1'];
			?>
				<!-- Services -->
				<h4 style="margin-top:30px;"><?php echo $othersname2;?></h4>
				<ul>
				<p align="justify"><?php echo $othersdesc2; ?></p>			
				</ul>
			
			</div>
			<div class="col-md-3">
				<?php include('include/sidebar.php'); ?>
			</div>
		</div>		
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
}
////////////////////////////////////////////// FOR ENGLISH CONTENTS ///////////////////////////////////
else{
	$val="eng";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>VPHO - Our Programs & Services</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">		
		<div class="row">
			<div class="col-md-9">
			<h3>Programs & Services <!-- कार्यक्रम र सेवाहरु --></h3>
			<?php
				$sql1="select * from others where othersID='1';";
				$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
				$row1=mysqli_fetch_array($result1);
				$othersname=$row1['othersName'];
				$othersdesc=$row1['othersDesc'];
			?>	
				<h4 style="margin-top:30px;"><?php echo $othersname;?></h4>
				<ul>
				<p align="justify"><?php echo $othersdesc; ?></p>			
				</ul>

				<?php
				$sql2="select * from others where othersID='2';";
				$result2=mysqli_query($connect,$sql2) or die("Error in Mysql :".mysqli_error($connect));
				$row2=mysqli_fetch_array($result2);
				$othersname2=$row2['othersName'];
				$othersdesc2=$row2['othersDesc'];
			?>
				<!-- Services -->
				<h4 style="margin-top:30px;"><?php echo $othersname2;?></h4>
				<ul>
				<p align="justify"><?php echo $othersdesc2; ?></p>			
				</ul>
			
			</div>
			<div class="col-md-3">
				<?php include('include/sidebar.php'); ?>
			</div>
		</div>		
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
 }
?>

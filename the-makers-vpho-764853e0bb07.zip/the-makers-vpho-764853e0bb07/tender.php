<?php
include('cms_admin/connect1.php');
$val="";
$pgnm="tender.php";
////////////////////////////////////////////// FOR NEPALI CONTENTS ///////////////////////////////////
 if((isset($_GET['contType']))=="nep"){
	//echo "you are going to see in nepali";
	$val="nep";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>भि.पि.एच.अो - सिलबंदी</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<h3> सिलबंदी</h3>
		<table class="table table-hover">
			<tr>
				<td><strong>शीर्षक</strong></td>
				<td><strong>लिंक​</strong></td>
			</tr>
			<?php
				$s1="Select * from tenderdownload where tenderdownloadType='Tender';";
				$qr1=mysqli_query($connect, $s1);
				while($rs1=mysqli_fetch_array($qr1)){
					$dwnID=$rs1['tenderdownloadID'];
					$dwnName=$rs1['tenderdownloadName1'];
					$dwnLink=$rs1['tenderdownloadLink'];

				?>
				<tr>
					<td><?php echo $dwnName;?></td>
					<td><a href="<?php echo $dwnLink;?>" class="btn btn-success">डाउनलोड</a></td>
				</tr>
			<?php
				}

			?>
		</table>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
}
////////////////////////////////////////////// FOR ENGLISH CONTENTS ///////////////////////////////////
else{
	//echo "you are going to see in english";
	$val="eng";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>VPHO - Tender</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<h3>Tender</h3>
		<table class="table table-hover">
			<tr>
				<td><strong>Title</strong></td>
				<td><strong>Link</strong></td>
				
			</tr>
			<?php
				$s1="Select * from tenderdownload where tenderdownloadType='Tender';";
				$qr1=mysqli_query($connect, $s1);
				while($rs1=mysqli_fetch_array($qr1)){
					$dwnID=$rs1['tenderdownloadID'];
					$dwnName=$rs1['tenderdownloadName'];
					$dwnLink=$rs1['tenderdownloadLink'];

				?>
				<tr>
					<td><?php echo $dwnName;?></td>
					<td><a href="<?php echo $dwnLink;?>" class="btn btn-success">Download</a></td>
				</tr>
			<?php
				}

			?>
		</table>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>

<?php
 }
?>

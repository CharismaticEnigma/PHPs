<?php
	include("connect1.php");
	/*if(!isset($_SESSION['Login_Name'])){
		header("Location:index.php");
		exit();
	}
	else{ */
	$a = $_GET['dele'];
	if(isset($a)){
				$sql2="delete from ourlinks where ourlinksID='$a';";
			   	$res2=mysqli_query($connect, $sql2) or die ("error in mysql :".mysqli_error($connect));
				$row2=mysqli_fetch_array($res2);
				//echo "file deleted";
				header('location:edit_delete_links.php');
			
	}
?>
	<?php
	include("connect.php");
		
		if(!isset($_SESSION['Login_Name'])){
		header("Location:index.php");
		exit();
	}

else{ 
	$imgID=$_GET['dele'];

		if(isset($imgID)){
			$sql1="Select * from staff where staffID='$imgID';";
			$res=mysqli_query($connect,$sql1);
			while($row1 = mysqli_fetch_array($res))
			{
 				 //echo $row1['newsImagePath'];
 				 $imgs=$row1['staffImage'];
 				 if($imgs!=null || $imgs!=""){
	 				 	 //echo $imgs;
	 				 //cho $row1['newsImageName'];
	 				$arr=array();
	 				 $arr= (explode ("/",$imgs));
	 				 //echo $arr[2];
	 				 chdir("../images/staff");
	 				unlink($arr[2]);
 				 }
 				
 				$sql= "delete from staff where staffID='$imgID';";
		
		mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
		//echo "data sucessfully deleted";
 			}
		
			
			
		header('location:edit_delete_staff.php');
		
		}
		}
		?>
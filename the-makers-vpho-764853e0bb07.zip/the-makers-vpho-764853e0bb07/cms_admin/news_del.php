	<?php
	include("connect.php");
		
		if(!isset($_SESSION['Login_Name'])){
		header("Location:index.php");
		exit();
	}

else{ 
	$imgID=$_GET['dele'];

		if(isset($imgID)){
			$sql1="Select * from news where newsID='$imgID';";
			$res=mysqli_query($connect,$sql1);
			while($row1 = mysqli_fetch_array($res))
			{
 				 //echo $row1['newsImagePath'];
 				 $imgs=$row1['newsImagePath'];
 				 if($imgs!="noimage"){


 				 //echo $imgs;
 				 //cho $row1['newsImageName'];
 				$arr=array();
 				 $arr= (explode ("/",$imgs));
 				 //echo $arr[2];
 				 chdir("../images/news");
 				unlink($arr[2]);
 				}
 			}
		
			$sql= "delete from news where newsID='$imgID';";
		
		mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
		//echo "data sucessfully deleted";
			
		header('location:news_edit_delete.php');
		
		}
		}
		?>
	<?php
	include("connect.php");
		
		if(!isset($_SESSION['Login_Name'])){
		header("Location:index.php");
		exit();
	}

else{ 
	$imgID=$_GET['dele'];

		if(isset($imgID)){
			$sql1="Select * from about where aboutID='$imgID';";
			$res=mysqli_query($connect,$sql1);
			while($row1 = mysqli_fetch_array($res))
			{
 				 //echo $row1['newsImagePath'];
 				 $imgs=$row1['aboutImagePath'];
 				 if($imgs!="noimage"){

 				 //echo $imgs;
 				 //cho $row1['newsImageName'];
 				$arr=array();
 				 $arr= (explode ("/",$imgs));
 				 //echo $arr[2];
 				 chdir("../images/about");
 				unlink($arr[2]);
 				}
 			}
		$sql2="delete from indexmodule where tableName='about' and headingID='$imgID';";
		mysqli_query($connect,$sql2) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
			$sql= "delete from about where aboutID='$imgID';";
		
		mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));

		//echo "data sucessfully deleted";
			
		header('location:edit_delete_about.php');
		
		}
		}
		?>
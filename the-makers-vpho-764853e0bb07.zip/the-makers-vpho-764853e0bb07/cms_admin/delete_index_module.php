<?php
include("connect.php");
	
$a = $_GET['dele'];

$sql2="delete from indexmodule where modID='$a';";
$res2=mysqli_query($connect,$sql2) or die ("error in mysql :".mysqli_error($connect));
header('location:index_model-delete.php');
	
?>
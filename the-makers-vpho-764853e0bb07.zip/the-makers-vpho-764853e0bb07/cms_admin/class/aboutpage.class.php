<?php
class Aboutpage
{
	function addAbout(){
		$neName=$_POST['arnm'];	
		$iDesc=$_POST['ardesc'];
		$neName1=$_POST['arnm1'];	
		$iDesc1=$_POST['ardesc1'];
		include("connect1.php");	
		$ext="";

		//the php script to upload the image
		$imagename = $_FILES["newsimg"]["name"];
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		//path to put into the database table
		$path = "images/about/$imagename";
		
		//actual server destination folder
		$dest = "../images/about/$imagename";
		if($imagename!=null || $imagename!=""){
			$arr = explode(".",$imagename);
			//check whether the extention is correct
			$ext = $arr[1];
		}
		
		if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG') or($ext==''))
		{	
			if($ext=='')
			{

				$sql= "insert into about (aboutName,aboutName1, aboutDesc,aboutDesc1,aboutImagePath) values ('$neName','$neName1','$iDesc','$iDesc1','noimage');";

		
				mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
				echo "data sucessfully added";
			}
			elseif(file_exists($dest)){
					echo "an image with that name already exists.. Please change your file";
				}
			else{

				//copy the temporarily uploaded file to the server destination (actual upload)
				copy($tmpimage,$dest);
				
				//@rename($dest,"../studpics/$id.$ext");


				$sql= "insert into about (aboutName,aboutName1, aboutDesc,aboutDesc1,aboutImagePath) values ('$neName','$neName1','$iDesc','$iDesc1','$path');";
		
				mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
				echo "data sucessfully added";
			}
		
		}
		else
		{
			echo "invalid photo! try again.";
			exit;
		}
				//upload script ends.
					
		//header('location:newsadd.php');
	}
	
	
	function editAbout(){
		$hid=$_POST['hid'];
		$iID=$_POST['iid'];
		$desc=$_POST['desc'];
		$iID1=$_POST['iid1'];
		$desc1=$_POST['desc1'];
		include("connect1.php");

		if(isset($iID) && $iID !=Null){
			$sqlup=mysqli_query($connect,"Update about Set aboutName='$iID' where aboutID='$hid'");	
		}
		if(isset($desc)&& $desc !=Null){
			$sqlup=mysqli_query($connect,"Update about Set aboutDesc='$desc' where aboutID='$hid'");	
		}
		if(isset($iID1) && $iID1 !=Null){
			$sqlup=mysqli_query($connect,"Update about Set aboutName1='$iID1' where aboutID='$hid'");	
		}
		if(isset($desc)&& $desc !=Null){
			$sqlup=mysqli_query($connect,"Update about Set aboutDesc1='$desc1' where aboutID='$hid'");	
		}
		
		
		//the php script to upload the image
		
		$imagename = $_FILES["newsimg"]["name"];
		//echo $imagename;
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		//path to put into the database table
		$path = "images/about/$imagename";
		
		//actual server destination folder
		$dest = "../images/about/$imagename";
		//echo "Destination: ".$dest;
		
		if (isset($imagename) && $imagename!= Null)
		{
		
		$arr = explode(".",$imagename);
		//check whether the extention is correct
		$ext = $arr[1];
		
		if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG'))
		{	
				if(file_exists($dest)){
			echo "an image with that name already exists.. Please change your file";
		}
		else{
			if(isset($path) && $path !=Null){

			$sql1="Select * from about where aboutID='$hid';";
			$res=mysqli_query($connect,$sql1);
			while($row1 = mysqli_fetch_array($res))
			{
 				 //echo $row1['headingImagePath'];
 				 $imgs=$row1['aboutImagePath'];
 				 if ($imgs!="noimage") {
 				 	$arr=array();
 				 	$arr= (explode ("/",$imgs));
 				 	$cdr=getcwd();
 				 	chdir("../images/about");
 					unlink($arr[2]);
 				 }
 				
 			}
 			if (isset($cdr)) {
 				chdir($cdr);
 			}
 			
 			//echo "Recent dir: ".getcwd();
 			copy($tmpimage,$dest);
			$sqlup=mysqli_query($connect,"Update about Set aboutImagePath='$path' where aboutID='$hid'");	

		}
			//copy the temporarily uploaded file to the server destination (actual upload)
		}
		}
		else
		{
			echo "invalid photo! try again.";
			exit;
		}	
		}		
		
		//echo "Data updated successfully";
		
	}
	
	
	
	
	}
	
	$Aboutpage = new Aboutpage();
	?>
   <?php
   ?>
   <div id="menu">
        <ul>
       <li><a href="#">Index Module</a>
             <ul>
                    <li class="top"><a href="add_index_module.php"> Add Module</a></li>
                    <li><a href="index_model-delete.php">Delete Module</a></li>
                                        
                    <li><a href="edit_welcome.php">Edit Welcome Message</a></li>
                    
                    </ul>
            </li>
					
			<li class="first"><a href="#">About Us</a>
                <ul>
                    <li class="top"><a href="add_about.php"> Add About</a></li>
					<li class="top"><a href="edit_delete_about.php"> Edit/Delete About</a></li>
                     <li class="top"><a href="add_staff.php"> Add Staff</a></li>
                    <li class="top"><a href="edit_delete_staff.php"> Edit/Delete Staff</a></li>
                    </ul>
            </li>
			<li class="first"><a href="#">Programs and Services</a>
                <ul>
					<li class="top"><a href="edit_program.php"> Edit Programs</a></li>
                    <li class="top"><a href="edit_service.php"> Edit Service</a></li>
                </ul>
            </li>		
            <li><a href="#">Images</a>
                    <ul>
                    <li class="top"><a href="gallery_image_add.php"> Add Gallery Image</a></li>
                    <li><a href="gallery_image_delete.php">Delete Gallery Image</a></li>
                    
					<li class="top"><a href="add_slider1.php"> Add Slider Image</a></li>
                    <li><a href="delete_slider1.php">Delete Slider Image</a></li>
					
                    </ul>
            </li>  
            <li><a href="#">News and Tenders</a>
                    <ul>
                    <li class="top"><a href="newsadd.php"> Add News</a></li>
                    <li><a href="news_edit_delete.php">Edit/Delete News</a></li>
					<li class="top"><a href="add_tender.php"> Add Tender/Download</a></li>
                    <li><a href="edit_delete_tender.php">Edit/Delete Tender/Download</a></li>
					<li class="top"><a href="add_links.php"> Add Associated Links</a></li>
                    <li><a href="edit_delete_links.php">Edit/Delete Associated LInks</a></li>
                    
                    </ul>                        
            
           </ul>
    </div>
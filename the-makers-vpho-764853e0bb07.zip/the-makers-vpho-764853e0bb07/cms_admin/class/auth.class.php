<?php
ob_start();
?>
<?php
class Auth
{

	function login(){
		
		$username= (md5($_POST['user']));
		$pass= (md5($_POST['pass']));
		include('connect1.php');
		
		$query=mysqli_query($connect,"select * from login where Login_Name='$username' and Login_Pass='$pass';");
		$row=mysqli_num_rows($query);
		
		if($row>0){
						
				$_SESSION['Login_Name']=$username;
				header("Location:add_index_module.php");
				exit();
				}
				else{
					echo "<h3 style='color:red'> Invalid Username or Password!! Please Try again..</h3>";
										
				exit ();
				}
				
				}
	
	}
	
	$Auth=new Auth();


?>
<?php
class Tenderpage
{
	function insertTender(){
		include("connect1.php");
	
		$name=$_POST['tendername'];		
		$name1=$_POST['tendername1'];	
		$type=$_POST['tdtype'];
		$ext="";


		//the php script to upload the image
		$imagename = $_FILES["newsimg"]["name"];
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		//path to put into the database table
		$path = "tenderdownload/$imagename";
		
		//actual server destination folder
		$dest = "../tenderdownload/$imagename";
		
		if($imagename!=null or $imagename!=""){
			$arr = explode(".",$imagename);
			//check whether the extention is correct
			$ext = $arr[1];
			//echo $tmpimage;	
		}
		
		
		if(($ext=='PDF') or ($ext=='TXT') or ($ext=='txt') or ($ext=='pdf') or($ext==''))
		{	
				//copy the temporarily uploaded file to the server destination (actual upload)
			if($ext==""){
				$path="nofile";
			}
			elseif(file_exists($dest)){
				echo "a file with that name already exists.. Please change your file";	
			}
			else
			{

				copy($tmpimage,$dest);
			}
				$sql= "insert into tenderdownload (tenderdownloadType, tenderdownloadName,tenderdownloadName1, tenderdownloadLink) values ('$type', '$name','$name1', '$path');";
		
				mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
				echo "data sucessfully added";		
				
				
		}
		else
		{
			echo "invalid photo! try again.";
			exit;
		}
		//script ends		
	}


	function editTenderDownload(){
		include("connect1.php");

		$id=$_POST['tenderdownloadid'];
		$nm=$_POST['upsubname'];
		$nm1=$_POST['upsubname1'];
		

		if(isset($nm) && $id!="-- Sub Heading --" && $nm!=Null){
			$sqlup=mysqli_query($connect, "Update tenderdownload Set tenderdownloadName='$nm' where tenderdownloadID='$id'");	
		}
		if(isset($nm1) && $id!="-- Sub Heading --" && $nm1!=Null){
			$sqlup=mysqli_query($connect, "Update tenderdownload Set tenderdownloadName1='$nm1' where tenderdownloadID='$id'");	
		}

		//the php script to upload the image
		
		$imagename = $_FILES["newsimg"]["name"];
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		//path to put into the database table
		$path = "tenderdownload/$imagename";
		
		//actual server destination folder
		$dest = "../tenderdownload/$imagename";
		
		
		if (isset($imagename) && $id!="-- Sub Heading --" && $imagename!=Null)
		{

			$arr = explode(".",$imagename);
			//check whether the extention is correct
			$ext = $arr[1];
		
			if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG') or ($ext=='txt') or ($ext=='pdf') or($ext==''))
			{	
				if(file_exists($dest)){
				echo "an image with that name already exists.. Please change your file";
			}
			else{
				if(isset($path) && $path !=Null){

				$sql1="Select * from tenderdownload where tenderdownloadID='$id';";
				$res=mysqli_query($connect,$sql1);
				while($row1 = mysqli_fetch_array($res))
				{
 					$imgs=$row1['tenderdownloadLink'];
 					if($imgs!="nofile"){
	 				 	$arr=array();
	 				 	$arr= (explode ("/",$imgs));
	 				 	$cdr=getcwd();
	 				 	chdir("../tenderdownload");
	 					unlink($arr[1]);
	 					chdir($cdr);
 					}
 				}
 				
	 			copy($tmpimage,$dest);

				$sqlup=mysqli_query($connect,"Update tenderdownload Set tenderdownloadLink='$path' where tenderdownloadID='$id';");	

					}
				//copy the temporarily uploaded file to the server destination (actual upload)
				}
			}
			else
			{
				echo "invalid photo! try again.";
				exit;
			}	
		}		
}

function deleteTenderDownload(){
		include("connect1.php");
		
		 $id=$_POST['tenderdownloadid'];
		
		
				$sql1="Select * from tenderdownload where tenderdownloadID='$id';";
				$res=mysqli_query($connect,$sql1);
				if($row1 = mysqli_fetch_array($res))
				{
	 				 $imgs=$row1['tenderdownloadLink'];
	 				 if($imgs!="nofile"){
		 				$arr=array();
		 				 $arr= (explode ("/",$imgs));
		 				chdir("../tenderdownload");
		 				unlink($arr[1]);
		 			}
		 				$sql= "delete from tenderdownload where tenderdownloadID='$id';";			
						mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
						echo "data sucessfully deleted";
	 			}	
	 		
	}


}
$Tenderpage = new Tenderpage();
?>
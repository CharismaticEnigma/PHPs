<?php
class SliderPage
{
	function insertImage(){
		//the php script to upload the image
		$imagename = $_FILES["newsimg"]["name"];
		$tmpimage = $_FILES["newsimg"]["tmp_name"];
		$ext="";

		//path to put into the database table
		$path = "images/bigslider/$imagename";
		
		//actual server destination folder
		$dest = "../images/bigslider/$imagename";
		if($imagename!=null || $imagename!=""){
			$arr = explode(".",$imagename);
			//check whether the extention is correct
			$ext = $arr[1];
		}
		
			if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG') or($ext==''))
			{	
				if($ext==""){
					echo "Please select an image before proceeding";
					//copy the temporarily uploaded file to the server destination (actual upload)
				}
				elseif(file_exists($dest)){
					echo "an image with that name already exists.. Please change your file";
				}
				else{
						copy($tmpimage,$dest);
						include("connect1.php");
						$sql= "insert into sliderimage (sliderimageImagePath) values ('$path');";
						mysqli_query($connect, $sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error());
						echo "data sucessfully added";
					
					//@rename($dest,"../studpics/$id.$ext");	
				}
				
			}
			else
			{
				echo "invalid photo! try again.";
				exit;
			}
				//upload script ends.
	
	}

	
}
$Sliderpage = new Sliderpage();
?>
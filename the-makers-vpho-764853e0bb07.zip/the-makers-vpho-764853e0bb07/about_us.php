<?php
include('cms_admin/connect1.php');
$val="";
$pgnm="about_us.php";
////////////////////////////////////////////// FOR NEPALI CONTENTS ///////////////////////////////////
 if((isset($_GET['contType']))=="nep"){
	$val="nep";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>भि.पि.एच.अो - हाम्रो बारेमा</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<h3><!--About Us-->हाम्रो बारेमा</h3>
		<div class="row">
			<div class="col-md-4">
				<div class="custom-wellwell">
					<ul>
					<?php
					$sql1="select * from about;";
					$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
					while($row1=mysqli_fetch_array($result1)){
						$aboutname1=$row1['aboutName1'];
					?>
						<li><a href="#<?php echo $aboutname1 ?>"><?php echo $aboutname1 ?></a></li>
					<?php
						}
					?>
					</ul>
				</div>
			</div>
		</div>		

		<?php
					$sql2="select * from about;";
					$result2=mysqli_query($connect,$sql2) or die("Error in Mysql :".mysqli_error($connect));
					while($row2=mysqli_fetch_array($result2)){
						$aboutname1=$row2['aboutName1'];
						$aboutdesc1=$row2['aboutDesc1'];
						$aboutimagepath=$row2['aboutImagePath'];

						if ($aboutimagepath!="images/about"){
							?>

								<div id="<?php echo $aboutname1; ?>">
									<h4 style="margin-top:30px;"><?php echo $aboutname1; ?></h4>
									<div class="row">
										<div class="col-md-6">
											<img src="<?php echo $aboutimagepath; ?>" alt="<?php echo $aboutname1; ?>" class="img-thumbnail" style="margin-bottom">
										</div>
									</div>
									<p align="justify">
										<?php echo $aboutdesc1; ?>
									</p>
								</div>

						<?php
							}
							else{
						?>

							<div id="<?php echo $aboutname1; ?>">
									<h4 style="margin-top:30px;"><?php echo $aboutname1; ?></h4>
									<p align="justify">
										<?php echo $aboutdesc1; ?>
									</p>
								</div>


						<?php
							}
						}
						?>

		<div id="Our staffs">
			<h4 style="margin-top:30px;">कार्यरत कर्मचार्य​</h4>
			<div class="row">
			<?php
			$sql3="select * from staff;";
			$result3=mysqli_query($connect,$sql3) or die("Error in Mysql :".mysqli_error($connect));
			while($row3=mysqli_fetch_array($result3)){
				$stafftitle1=$row3['staffTitle1'];
				$staffname1=$row3['staffName1'];
				$staffimg=$row3['staffImage'];
			?>
				<div class="col-md-3 col-xs-6" align="center">					
					<img src="<?php echo $staffimg; ?>" class="img-thumbnail custom-imagepp" alt="<?php echo $staffname1; ?>">
					<p><?php echo $staffname1; ?></p>
					<p><?php echo $stafftitle1; ?></p>
				</div>
			<?php
			}
			?>
			</div>
		</div>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
}
////////////////////////////////////////////// FOR ENGLISH CONTENTS ///////////////////////////////////
else{
	$val="eng";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>VPHO - About Us</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<h3>About Us<!--हाम्रो बारेमा--></h3>
		<div class="row">
			<div class="col-md-4">
				<div class="custom-wellwell">
					<ol>
					<?php
					$sql1="select * from about;";
					$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
					while($row1=mysqli_fetch_array($result1)){
						$aboutname=$row1['aboutName'];
					?>
						<li><a href="#<?php echo $aboutname ?>"><?php echo $aboutname ?></a></li>
					<?php
						}
					?>
					</ol>
				</div>
			</div>
		</div>		

		<?php
					$sql2="select * from about;";
					$result2=mysqli_query($connect,$sql2) or die("Error in Mysql :".mysqli_error($connect));
					while($row2=mysqli_fetch_array($result2)){
						$aboutname=$row2['aboutName'];
						$aboutdesc=$row2['aboutDesc'];
						$aboutimagepath=$row2['aboutImagePath'];

						if ($aboutimagepath!="images/about"){
							?>

								<div id="<?php echo $aboutname; ?>">
									<h4 style="margin-top:30px;"><?php echo $aboutname; ?></h4>
									<div class="row">
										<div class="col-md-6">
											<img src="<?php echo $aboutimagepath; ?>" alt="<?php echo $aboutname; ?>" class="img-thumbnail" style="margin-bottom">
										</div>
									</div>
									<p align="justify">
										<?php echo $aboutdesc; ?>
									</p>
								</div>

						<?php
							}
							else{
						?>

							<div id="<?php echo $aboutname; ?>">
									<h4 style="margin-top:30px;"><?php echo $aboutname; ?></h4>
									<p align="justify">
										<?php echo $aboutdesc; ?>
									</p>
								</div>


						<?php
							}
						}
						?>

		<div id="Our staffs">
			<h4 style="margin-top:30px;">Our Staffs</h4>
			<div class="row">
			<?php
			$sql3="select * from staff;";
			$result3=mysqli_query($connect,$sql3) or die("Error in Mysql :".mysqli_error($connect));
			while($row3=mysqli_fetch_array($result3)){
				$stafftitle=$row3['staffTitle'];
				$staffname=$row3['staffName'];
				$staffimg=$row3['staffImage'];
			?>
				<div class="col-md-3 col-xs-6" align="center">					
					<img src="<?php echo $staffimg; ?>" class="img-thumbnail custom-imagepp" alt="<?php echo $staffname; ?>">
					<p><?php echo $staffname; ?></p>
					<p><?php echo $stafftitle; ?></p>
				</div>
			<?php
			}
			?>
			</div>
		</div>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php 
	}
?>

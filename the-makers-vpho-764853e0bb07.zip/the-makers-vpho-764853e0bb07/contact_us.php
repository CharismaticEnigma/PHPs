<?php
include('cms_admin/connect1.php');
$val="";
$pgnm="contact_us.php";
 if((isset($_GET['contType']))=="nep"){
	//echo "you are going to see in nepali";
	$val="nep";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>भि.पि.एच.अो - सम्पर्क</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');

?>
<div class="content">
	<div class="container">
		<h3>सम्पर्क</h3>
		<p align="justify">
			सल्लाह सुझाव भएमा तल दिएको फारम भरेर हामीलाई सहयोग गरिदिनुहोला।
		</p>
		<hr>
		<div class="row">
			<div class="col-md-6">
				<div class="well">
					<h4> पशु जन स्वास्थ्य कार्यालय</h4>
					<p><span class="glyphicon glyphicon-pushpin"></span> ठेगाना: त्रिपुरेश्वर, काठमाडौं</p>
					<p><span class="glyphicon glyphicon-phone-alt"></span> टेलिफोन​:  ०१४२६७१५, ०१४२१२३७६</p>
					<p><span class="glyphicon glyphicon-print"></span> फ्याक्स: ०१४२१२३</p>
					<p><span class="glyphicon glyphicon-envelope"></span> इमेल: vphonep@gmail.com</p>

					<form name="form" action="include/mail.php" method="post">
						
						<div class="responsive-table">
						<table class="table">
							<tr>
								<td><p>नाम</p></td>
								<td><input type="text" name="name" id="name" style="width:100%;"></td>
							</tr>
							<tr>
								<td><p>इमेल</p></td>									
								<td><input type="text" name="email" id="email" style="width:100%;"></td>
							</tr>
							<tr>
								<td><p>विषय</p></td>
								<td><input type="text" name="subject" id="subject" style="width:100%;"></td>
							</tr>
							<tr>
								<td><p>तपाईको सन्देश</p></td>
								<td><textarea name="message" id="message" cols="45" rows="5" style="width:100%;"></textarea></td>
							</tr>
							<tr>
								<td></td>
								<td style="float:right;"><input class="btn btn-info" type="submit" name="submit" id="submit" value="बुझाउ"></td>
							</tr>
						</table>
					</div>
					</form>
				</div>
			</div>
			<div class="col-md-6">
				<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script><div style="height:100%;width:100%;"><div id="gmap_canvas" style="height:500px;width:100%;"></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style></div><script type="text/javascript"> function init_map(){var myOptions = {zoom:16,center:new google.maps.LatLng(27.694996400000008,85.31141659944456),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(27.694996400000008, 85.31141659944456)});infowindow = new google.maps.InfoWindow({content:"<b>Veterinary Public Health Office</b><br/>Tripureswor<br/> Kathmandu" });google.maps.event.addListener(marker, "click", function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>
			</div>
		</div>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
}
else{
	//echo "you are going to see in english";
	$val="eng";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>VPHO - Contact Us</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<h3>Contact Us </h3>
		<p align="justify">
			If you have any feedback and suggestions you can send us a message down below. We are happy to hear from you.
		</p>
		<hr>
		<div class="row">
			<div class="col-md-6">
				<div class="well">
					<h4>Veterinary Public Health Office</h4>
					<p><span class="glyphicon glyphicon-pushpin"></span> Address: Tripureswor Kathmandu</p>
					<p><span class="glyphicon glyphicon-phone-alt"></span> Phone: 01426715, 014212376</p>
					<p><span class="glyphicon glyphicon-print"></span> Fax: 0142123</p>
					<p><span class="glyphicon glyphicon-envelope"></span> Email: vphonep@gmail.com</p>
					<form name="form" action="include/mail.php" method="post">
						
						<div class="responsive-table">
						<table class="table">
							<tr>
								<td><p>Name</p></td>
								
								<td><input type="text" name="name" id="name" style="width:100%;"></td>
							</tr>
							<tr>
								<td><p>E-mail</td>
															
								<td><input type="text" name="email" id="email" style="width:100%;"></td>
							</tr>
							<tr>
								<td><p>Subject</p></td>
								
								<td><input type="text" name="subject" id="subject" style="width:100%;"></td>
							</tr>
							<tr>
								<td><p>Your Message</p></td>
								
								<td><textarea name="message" id="message" cols="45" rows="5" style="width:100%;"></textarea></td>
							</tr>
							<tr>
								<td></td>
								<td style="float:right;"><input class="btn btn-info" type="submit" name="submit" id="submit" value="Submit"></td>
							</tr>
						</table>
					</div>
					</form>
				</div>
			</div>
			<div class="col-md-6">
				<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script><div style="height:100%;width:100%;"><div id="gmap_canvas" style="height:500px;width:100%;"></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style></div><script type="text/javascript"> function init_map(){var myOptions = {zoom:16,center:new google.maps.LatLng(27.694996400000008,85.31141659944456),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(27.694996400000008, 85.31141659944456)});infowindow = new google.maps.InfoWindow({content:"<b>Veterinary Public Health Office</b><br/>Tripureswor<br/> Kathmandu" });google.maps.event.addListener(marker, "click", function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>
			</div>
		</div>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php }
?>


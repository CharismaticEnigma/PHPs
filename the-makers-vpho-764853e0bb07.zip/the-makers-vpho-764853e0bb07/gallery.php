<?php
include('cms_admin/connect1.php');
$val="";
$pgnm="gallery.php";
////////////////////////////////////////////// FOR NEPALI CONTENTS ///////////////////////////////////
 if((isset($_GET['contType']))=="nep"){
	$val="nep";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>भि.पि.एच.अो - तस्बिरहरु</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<div class="row">
			<div class="col-md-9">
				<h3>तस्बिरहरु <!-- Gallery --></h3>
				<div class="row">
				<?php
				$sql1="select * from galleryimage;";
				$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
				while($row1=mysqli_fetch_array($result1)){
					$galleryimagename1=$row1['galleryimageName1'];
					$galleryimageimgpath1=$row1['galleryimageImagePath'];
				?>
				<div class="col-md-4 col-xs-6"  style="text-align:center;">
						<a class="group1" href="<?php echo $galleryimageimgpath1; ?>" title="<?php echo $galleryimagename1; ?>" alt="I<?php echo $galleryimagename1; ?>">
							<img src="<?php echo $galleryimageimgpath1; ?>" class="img-thumbnail" alt="I<?php echo $galleryimagename1; ?>" style="width:200px; height:200px;">
						</a>
						<p><?php echo $galleryimagename1; ?></p>
					</div>
				<?php
				}
				?>
				</div>					
			</div>
			<div class="col-md-3">
				<?php include('include/sidebar.php'); ?>
			</div>
		</div>		
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
}
////////////////////////////////////////////// FOR ENGLISH CONTENTS ///////////////////////////////////
else{
	$val="eng";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>VPHO - Gallery</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<div class="row">
			<div class="col-md-9">
				<h3>Gallery <!-- तस्बिरहरु --></h3>
				<div class="row">
				<?php
				$sql1="select * from galleryimage;";
				$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
				while($row1=mysqli_fetch_array($result1)){
					$galleryimagename1=$row1['galleryimageName'];
					$galleryimageimgpath1=$row1['galleryimageImagePath'];
				?>
				<div class="col-md-4 col-xs-6"  style="text-align:center;">
						<a class="group1" href="<?php echo $galleryimageimgpath1; ?>" title="<?php echo $galleryimagename1; ?>" alt="I<?php echo $galleryimagename1; ?>">
							<img src="<?php echo $galleryimageimgpath1; ?>" class="img-thumbnail" alt="I<?php echo $galleryimagename1; ?>" style="width:200px; height:200px;">
						</a>
						<p><?php echo $galleryimagename1; ?></p>
					</div>
				<?php
				}
				?>
				</div>					
			</div>
			<div class="col-md-3">
				<?php include('include/sidebar.php'); ?>
			</div>
		</div>		
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
 }
?>

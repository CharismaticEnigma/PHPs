<?php
////////////////////////////nepali ko lai//////////////////////////////////////////////////////////////////////

if($val=="nep"){
?>
<script src="js/jquery.bootstrap.newsbox.js" type="text/javascript"></script>


<div class="panel panel-default">
	<div class="panel-heading"> <span class="glyphicon glyphicon-list-alt"></span><b>समाचार​ र​ घटना   <!-- News & Events --></b></div>
		<div class="panel-body">
			<div class="row">
				<div class="col-xs-12">
					<ul class="demo1">
					<?php
					$s1="Select * from news;";
					$qr1=mysqli_query($connect, $s1);
					while($rs1=mysqli_fetch_array($qr1)){
						$newsID=$rs1['newsID'];
						$newsNm=$rs1['newsName1'];
						$newsName=$rs1['newsImagePath'];
						$newsDesc=$rs1['newsDesc1'];

					?>
						<li class="news-item">
								<table cellpadding="4">
									<tr>
										<td><img src="<?php echo $newsName; ?>" alt="<?php echo $newsNm;?>" width="60" class="img-circle" /></td>
										<td><?php echo $newsDesc?><a href="<?php echo "news.php?contType=nep#".$newsID;?>" style="text-decoration:none;">थप जान्कारी...</a></td>
										
									</tr>
								</table>
						</li>
					<?php
					}

				?>						
					</ul>
				</div>
			</div>
		</div>
<div class="panel-footer"> </div>
</div>
<script type="text/javascript">
    $(function () {
        $(".demo1").bootstrapNews({
            newsPerPage: 3,
            autoplay: true,
			pauseOnHover:true,
            direction: 'up',
            newsTickerInterval: 4000,
            onToDo: function () {
                //console.log(this);
            }
        });
		
		$(".demo2").bootstrapNews({
            newsPerPage: 4,
            autoplay: true,
			pauseOnHover: true,
			navigation: false,
            direction: 'down',
            newsTickerInterval: 2500,
            onToDo: function () {
                //console.log(this);
            }
        });

        $("#demo3").bootstrapNews({
            newsPerPage: 3,
            autoplay: false,
            
            onToDo: function () {
                //console.log(this);
            }
        });
    });
</script>
<?php 
}
///////////////////////////////////////////////////////ENGLISH KO LAGI////////////////////////////////////////////////
else if($val=="eng"){
?>
<script src="js/jquery.bootstrap.newsbox.js" type="text/javascript"></script>


<div class="panel panel-default">
	<div class="panel-heading"> <span class="glyphicon glyphicon-list-alt"></span><b> News & Events <!-- समाचार​ र​ घटना --></b></div>
		<div class="panel-body">
			<div class="row">
				<div class="col-xs-12">
					<ul class="demo1">
						<?php
					$s1="Select * from news;";
					$qr1=mysqli_query($connect, $s1);
					while($rs1=mysqli_fetch_array($qr1)){
						$newsID=$rs1['newsID'];
						$newsNm=$rs1['newsName'];
						$newsName=$rs1['newsImagePath'];
						$newsDesc=$rs1['newsDesc'];

					?>
						<li class="news-item">
								<table cellpadding="4">
									<tr>
										<td><img src="<?php echo $newsName; ?>" alt="<?php echo $newsNm;?>" width="60" class="img-circle" /></td>
										<td><?php echo $newsDesc?><a href="<?php echo "news.php#".$newsID;?>" style="text-decoration:none;">Read more...</a></td>
										
									</tr>
								</table>
						</li>
					<?php
					}

				?>	
						
					</ul>
				</div>
			</div>
		</div>
<div class="panel-footer"> </div>
</div>
<script type="text/javascript">
    $(function () {
        $(".demo1").bootstrapNews({
            newsPerPage: 3,
            autoplay: true,
			pauseOnHover:true,
            direction: 'up',
            newsTickerInterval: 4000,
            onToDo: function () {
                //console.log(this);
            }
        });
		
		$(".demo2").bootstrapNews({
            newsPerPage: 4,
            autoplay: true,
			pauseOnHover: true,
			navigation: false,
            direction: 'down',
            newsTickerInterval: 2500,
            onToDo: function () {
                //console.log(this);
            }
        });

        $("#demo3").bootstrapNews({
            newsPerPage: 3,
            autoplay: false,
            
            onToDo: function () {
                //console.log(this);
            }
        });
    });
</script>
<?php
}
?> 
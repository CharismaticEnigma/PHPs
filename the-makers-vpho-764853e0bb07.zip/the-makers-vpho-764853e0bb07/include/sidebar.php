<?php
////////////////////////////nepali ko lai//////////////////////////////////////////////////////////////////////

if($val=="nep"){
 /* echo "you will see nepali header";*/
?>
<div class="row">
	<div class="col-md-12" style="padding:10px;">
		 <div class="tender">
			<h4>सिलबंदी सूचना  <!-- Tender Notice--></h4>
			<?php include('include/tender.php'); ?> 
		</div> 
	</div>
	<div class="col-md-12">
		<div class="tender">
			<?php include('include/side_news_&_events.php'); ?>								
		</div> 							
	</div>
</div>
<?php 
}
///////////////////////////////////////////////////////ENGLISH KO LAGI////////////////////////////////////////////////
else if($val=="eng"){
 // echo "you are going to see english header";
?>
<div class="row">
	<div class="col-md-12" style="padding:10px;">
		 <div class="tender">
			<h4>Tender Notice <!-- सिलबंदी सूचना --></h4>
			<?php include('include/tender.php'); ?> 
		</div> 
	</div>
	<div class="col-md-12">
		<div class="tender">
			<?php include('include/side_news_&_events.php'); ?>								
		</div> 							
	</div>
</div>
<?php
}
?>
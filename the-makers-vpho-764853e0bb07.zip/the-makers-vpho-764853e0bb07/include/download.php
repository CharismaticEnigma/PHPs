<?php
////////////////////////////nepali ko lai//////////////////////////////////////////////////////////////////////

if($val=="nep"){
 /* echo "you will see nepali header";*/
?>
<link rel="stylesheet" type="text/css" href="css/style.css"/>

<script type="text/javascript" src="js/jquery.totemticker.js"></script>

<ul id="vertical-ticker">
<!-- limit characters : 26 -->
	<?php
		$s1="Select * from tenderdownload where tenderdownloadType='Download';";
		$qr1=mysqli_query($connect, $s1);
		while($rs1=mysqli_fetch_array($qr1)){
			$dwnID=$rs1['tenderdownloadID'];
			$dwnName=$rs1['tenderdownloadName1'];
		?>
			<li><a href="<?php echo "download.php?contType=nep#".$dwnID;?>"><?php echo $dwnName; ?></a></li>
		<?php
		}

	?>
</ul>
	<div style="float:left;">
		<a href="#" id="ticker-previous" class="btn btn-success" ><span class="glyphicon glyphicon-chevron-down"></span></a> 
		<a href="#" id="ticker-next" class="btn btn-success"><span class="glyphicon glyphicon-chevron-up"></span></a>
	</div>	

<script type="text/javascript">
    $(function(){
      $('#vertical-ticker').totemticker({
        row_height  : '100px',
        next    : '#ticker-next',
        previous  : '#ticker-previous',
        stop    : '#stop',
        start   : '#start',
        mousestop : true,
      });
    });
</script>
  <?php 
}
///////////////////////////////////////////////////////ENGLISH KO LAGI////////////////////////////////////////////////
else if($val=="eng"){
 // echo "you are going to see english header";
?>
<link rel="stylesheet" type="text/css" href="css/style.css"/>

<script type="text/javascript" src="js/jquery.totemticker.js"></script>

<ul id="vertical-ticker">
<!-- limit characters : 26 -->
	<?php
		$s1="Select * from tenderdownload where tenderdownloadType='Download';";
		$qr1=mysqli_query($connect, $s1);
		while($rs1=mysqli_fetch_array($qr1)){
			$dwnID=$rs1['tenderdownloadID'];
			$dwnName=$rs1['tenderdownloadName'];
		?>
			<li><a href="<?php echo "download.php?#".$dwnID;?>"><?php echo $dwnName; ?></a></li>
		<?php
		}

	?>
</ul>
	<div style="float:left;">
		<a href="#" id="ticker-previous" class="btn btn-success" ><span class="glyphicon glyphicon-chevron-down"></span></a> 
		<a href="#" id="ticker-next" class="btn btn-success"><span class="glyphicon glyphicon-chevron-up"></span></a>
	</div>	

<script type="text/javascript">
    $(function(){
      $('#vertical-ticker').totemticker({
        row_height  : '100px',
        next    : '#ticker-next',
        previous  : '#ticker-previous',
        stop    : '#stop',
        start   : '#start',
        mousestop : true,
      });
    });
</script>
<?php
}
?>
<?php
////////////////////////////nepali ko lai//////////////////////////////////////////////////////////////////////

if($val=="nep"){
 /* echo "you will see nepali header";*/
?>
<!------ CSS & JS ------>       
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/bootstrap-theme.css">  
  <link rel="stylesheet" href="css/custom-css.css">
  <link rel="stylesheet" href="css/newsbox.css">
 
  <link rel="stylesheet" href="css/menustyles.css">
  <link rel="stylesheet" href="css/hint.css">

  <script src="js/jquery-latest.min.js" type="text/javascript"></script>
  <script src="js/menuscript.js"></script>
  <script src="js/ajax.googleapis"></script>  
  <script src="js/modernizr.js"></script>    
  <script src="js/jquery.min.js" type="text/javascript"></script>
  <script src="js/modernizr.custom.17475.js" type="text/javascript"></script>
  
  <script src="js/bootstrap.js"></script>

  <!-- color box css and jquery -->

  <link rel="stylesheet" href="css/colorbox.css" />
  <script src="js/jquery.colorbox.js"></script>
  <script>
      $(document).ready(function(){
        //Examples of how to assign the Colorbox event to elements
        $(".group1").colorbox({rel:'group1'});
        $(".group2").colorbox({rel:'group2', transition:"fade"});
        $(".group3").colorbox({rel:'group3', transition:"none", width:"75%", height:"75%"});
        $(".group4").colorbox({rel:'group4', slideshow:true});
        $(".ajax").colorbox();
        $(".youtube").colorbox({iframe:true, innerWidth:640, innerHeight:390});
        $(".vimeo").colorbox({iframe:true, innerWidth:500, innerHeight:409});
        $(".iframe").colorbox({iframe:true, width:"80%", height:"80%"});
        $(".inline").colorbox({inline:true, width:"50%"});
        $(".callbacks").colorbox({
          onOpen:function(){ alert('onOpen: colorbox is about to open'); },
          onLoad:function(){ alert('onLoad: colorbox has started to load the targeted content'); },
          onComplete:function(){ alert('onComplete: colorbox has displayed the loaded content'); },
          onCleanup:function(){ alert('onCleanup: colorbox has begun the close process'); },
          onClosed:function(){ alert('onClosed: colorbox has completely closed'); }
        });

        $('.non-retina').colorbox({rel:'group5', transition:'none'})
        $('.retina').colorbox({rel:'group5', transition:'none', retinaImage:true, retinaUrl:true});
        
        //Example of preserving a JavaScript event for inline calls.
        $("#click").click(function(){ 
          $('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
          return false;
        });
      });
    </script>
  <!-- color box css and jquery end -->
 

<!------ --------- ------>

<div class="container">
  <div class="row" style="width:99%;">
    <div class="col-md-10">
      <div class="col-md-2 col-xs-4">
        <div style="margin-bottom:20px;">
          <img src="images/logo.png" class="img-responsive">
        </div>
      </div>
      <div class="col-md-10 col-xs-8" align="center">

        <h6 style="color:#d30500;">नेपाल सरकार</h6>
        <h5 style="color:#15729f;"><strong>कृषि विकास मन्त्रालय</strong></h5>
        <h5 style="color:#15729f;"><strong>कृषि विभाग</strong></h5>
        <h3 style="color:#d30500;">पशु जन स्वास्थ्य कार्यालय </h3>
        
      </div>
            
    </div>
    <div class="col-md-2">
      <div class="search">
          <form>
            <input type="search" placeholder="खोजनुस्">
          </form>
      </div>
      <div style="margin-left:20px;">
        <a href="<?php echo $pgnm ?>" class="hint--top hint--rounded" data-hint="अंग्रेजी"><img src="images/British-icon.png"></a>
        <a href="<?php echo $pgnm."?contType=nep" ?>" class="hint--top hint--rounded" data-hint="नेपाली"><img src="images/Nepal-flat-icon.png"></a>
      </div>    
    </div>
  </div>
  
  <div id='maincssmenu' style="margin-bottom:20px;">
    <ul>
       <li><a href='index.php?contType=nep'><span class="glyphicon glyphicon-home"></span><span> गृहपृष्ठ</span></a></li>
       <li><a href='about_us.php?contType=nep'><span class="glyphicon glyphicon-info-sign"></span><span> हाम्रो बारेमा</span></a></li>
       <li><a href='programs_services.php?contType=nep'><span class="glyphicon glyphicon-certificate"></span><span> कार्यक्रम र सेवाहरु</span></a></li>
       <li><a href='gallery.php?contType=nep'><span class="glyphicon glyphicon-picture"></span><span> तस्बिरहरु</span></a></li>
       <li><a href='news.php?contType=nep'><span class="glyphicon glyphicon-globe"></span><span> समाचार​</span></a></li>
       <li><a href='download.php?contType=nep'><span class="glyphicon glyphicon-download"></span><span> डाउन्लोड</span></a></li>
       <li><a href='tender.php?contType=nep'><span class="glyphicon glyphicon-file"></span><span> सिलबंदी</span></a></li>
       <li class='last'><a href='contact_us.php?contType=nep'><span class="glyphicon glyphicon-earphone"></span><span> सम्पर्क</span></a></li>
    </ul>    
  </div>
</div>

<?php 
}
///////////////////////////////////////////////////////ENGLISH KO LAGI////////////////////////////////////////////////
else if($val=="eng"){
 // echo "you are going to see english header";
?>
  <!------ CSS & JS ------>       
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/bootstrap-theme.css">  
  <link rel="stylesheet" href="css/custom-css.css">
  <link rel="stylesheet" href="css/newsbox.css">
 
  <link rel="stylesheet" href="css/menustyles.css">
  <link rel="stylesheet" href="css/hint.css">

  <script src="js/jquery-latest.min.js" type="text/javascript"></script>
  <script src="js/menuscript.js"></script>
  <script src="js/ajax.googleapis"></script>  
  <script src="js/modernizr.js"></script>    
  <script src="js/jquery.min.js" type="text/javascript"></script>
  <script src="js/modernizr.custom.17475.js" type="text/javascript"></script>
  
  <script src="js/bootstrap.js"></script>

  <!-- color box css and jquery -->

  <link rel="stylesheet" href="css/colorbox.css" />
  <script src="js/jquery.colorbox.js"></script>
  <script>
      $(document).ready(function(){
        //Examples of how to assign the Colorbox event to elements
        $(".group1").colorbox({rel:'group1'});
        $(".group2").colorbox({rel:'group2', transition:"fade"});
        $(".group3").colorbox({rel:'group3', transition:"none", width:"75%", height:"75%"});
        $(".group4").colorbox({rel:'group4', slideshow:true});
        $(".ajax").colorbox();
        $(".youtube").colorbox({iframe:true, innerWidth:640, innerHeight:390});
        $(".vimeo").colorbox({iframe:true, innerWidth:500, innerHeight:409});
        $(".iframe").colorbox({iframe:true, width:"80%", height:"80%"});
        $(".inline").colorbox({inline:true, width:"50%"});
        $(".callbacks").colorbox({
          onOpen:function(){ alert('onOpen: colorbox is about to open'); },
          onLoad:function(){ alert('onLoad: colorbox has started to load the targeted content'); },
          onComplete:function(){ alert('onComplete: colorbox has displayed the loaded content'); },
          onCleanup:function(){ alert('onCleanup: colorbox has begun the close process'); },
          onClosed:function(){ alert('onClosed: colorbox has completely closed'); }
        });

        $('.non-retina').colorbox({rel:'group5', transition:'none'})
        $('.retina').colorbox({rel:'group5', transition:'none', retinaImage:true, retinaUrl:true});
        
        //Example of preserving a JavaScript event for inline calls.
        $("#click").click(function(){ 
          $('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
          return false;
        });
      });
    </script>
  <!-- color box css and jquery end -->
 

<!------ --------- ------>

<div class="container">
  <div class="row" style="width:99%;">
    <div class="col-md-10">
      <div class="col-md-2 col-xs-4">
        <div style="margin-bottom:20px;">
          <img src="images/logo.png" class="img-responsive">
        </div>
      </div>
      <div class="col-md-10 col-xs-8" align="center">
        <h6 style="color:#d30500;">Government Of Nepal</h6>
        <h5 style="color:#15729f;"><strong>Ministry Of Agriculture Development</strong></h5>
        <h5 style="color:#15729f;"><strong>Department Of Agriculture</strong></h5>
        <h3 style="color:#d30500;">Veterinary Public Health Office </h3>        
      </div>
            
    </div>
    <div class="col-md-2">
      <div class="search">
          <form>
            <input type="search" placeholder="Search">
          </form>
      </div>
      <div style="margin-left:20px;">
        <a href="<?php echo $pgnm."?contType=eng" ?>" class="hint--top hint--rounded" data-hint="English"><img src="images/British-icon.png"></a>
        <a href="<?php echo $pgnm."?contType=nep" ?>" class="hint--top hint--rounded" data-hint="Nepali"><img src="images/Nepal-flat-icon.png"></a>
      </div>    
    </div>
  </div>
  
  <div id='maincssmenu' style="margin-bottom:20px;">
    <ul>
       <li><a href='index.php'><span class="glyphicon glyphicon-home"></span><span> Home</span></a></li>
       <li><a href='about_us.php'><span class="glyphicon glyphicon-info-sign"></span><span> About Us </span></a></li>
       <li><a href='programs_services.php'><span class="glyphicon glyphicon-certificate"></span><span> Programs & Services</span></a></li>
       <li><a href='gallery.php'><span class="glyphicon glyphicon-picture"></span><span> Gallery</span></a></li>
       <li><a href='news.php'><span class="glyphicon glyphicon-globe"></span><span> News</span></a></li>
       <li><a href='download.php'><span class="glyphicon glyphicon-download"></span><span> Download</span></a></li>
       <li><a href='tender.php'><span class="glyphicon glyphicon-file"></span><span> Tender</span></a></li>
       <li class='last'><a href='contact_us.php'><span class="glyphicon glyphicon-earphone"></span><span> Contact Us</span></a></li>
    </ul>
  </div>
</div>
<?php
}
?>

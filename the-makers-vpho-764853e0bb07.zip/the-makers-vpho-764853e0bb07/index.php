<?php
include('cms_admin/connect1.php');
$val="";
$pgnm="index.php";
////////////////////////////////////////////// FOR NEPALI CONTENTS ///////////////////////////////////
 if((isset($_GET['contType']))=="nep"){
	//echo "you are going to see in nepali";
	$val="nep";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>भि.पि.एच.अो</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<div class="custom-well">
				<?php
				$sql1="select * from welcome;";
				$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
				$row1=mysqli_fetch_array($result1);
				$welcometitle1=$row1['welcomeTitle1'];
				$welcomedesc1=$row1['welcomeDesc1'];
				?>
					<h2><?php echo $welcometitle1; ?></span></h2>
					<p align="justify"><?php echo $welcomedesc1; ?></p>
					<a href="about_us.php?contType=nep" class="btn btn-info">थप जान्कारी</a>
				</div>
			</div>
			<div class="col-md-8">
				<?php 
					include('include/slider.php')
				?>
			</div>		
		</div>	
	</div>
	<div class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="row">
						<div class="col-md-12 col-xs-6">
							<div class="tender">
								<h4>डाउन्लोड <!-- Download --></h4>
									<?php include('include/download.php'); ?>
							</div>							
						</div>
						<div class="col-md-12 col-xs-6">
							<div class="calender">								
								<h4>पात्रो  <!-- Calender --></h4>
								<iframe src="http://www.nepcal.com/m_e_j3.php" frameborder="0" scrolling="no" marginwidth="0" marginheight="0" style="border:none; overflow:hidden; width:189px; height:279px;" allowtransparency="true"></iframe>
							</div> 
						</div>
					</div>				
				</div>
				<div class="col-md-6">
					<div class="row" style="padding:10px;">
					<?php
					$sqlstaff1="select * from staff where staffTitle='Senior Veterinary Officer';";
					$resultstaff1=mysqli_query($connect,$sqlstaff1) or die("Error in Mysql :".mysqli_error($connect));
					$rowstaff1=mysqli_fetch_array($resultstaff1);
					$stafftitle1=$rowstaff1['staffTitle1'];
					$staffname1=$rowstaff1['staffName1'];
					$staffimg1=$rowstaff1['staffImage'];

					$sqlstaff2="select * from staff where staffTitle='Veterinary Officer';";
					$resultstaff2=mysqli_query($connect,$sqlstaff2) or die("Error in Mysql :".mysqli_error($connect));
					$rowstaff2=mysqli_fetch_array($resultstaff2);
					$stafftitle2=$rowstaff2['staffTitle1'];
					$staffname2=$rowstaff2['staffName1'];
					$staffimg2=$rowstaff2['staffImage'];

					?>
					
						<div class="col-md-6 col-xs-6" align="center">
							<img src="<?php echo $staffimg1; ?>" class="img-thumbnail custom-imagepp" alt="<?php echo $stafftitle1; ?>">
							<p><?php echo $staffname1; ?></p>
							<p style="color:#2787BA"><?php echo $stafftitle1; ?></p>
						</div>

						<div class="col-md-6 col-xs-6" align="center">
							<img src="<?php echo $staffimg2; ?>" class="img-thumbnail custom-imagepp" alt="<?php echo $stafftitle2; ?>">
							<p><?php echo $staffname2; ?></p>
							<p style="color:#2787BA"><?php echo $stafftitle2; ?></p>
						</div>
					</div>
					<div class="row">
					<?php	
					$sql="Select * from indexmodule;";
					$query=mysqli_query($connect, $sql) or die ("Error in mysql:".mysqli_error($connect));
					while($row=(mysqli_fetch_array($query))){
						$tbname=$row['tableName'];
						$id=$row['headingID'];
						$hrefLink=$row['modLink'];
						$hrefLink1=str_replace(" ","", $hrefLink);

						$colID=str_replace(" ","", $tbname."ID");
						
						$sql1="Select * from $tbname where $colID=$id;";
						$query1=mysqli_query($connect, $sql1) or die ("Error in mysql:".mysqli_error($connect));
						
						if ($row1=(mysqli_fetch_array($query1))){

							$colTitle=str_replace(" ","", $tbname."Name1");
							$title=$row1[$colTitle];
														
							$coldesc=str_replace(" ","", $tbname."Desc1");
							$description=$row1[$coldesc];
						}
				?>

						<div class="col-md-12 custom-wellwell">
							<h4><?php echo $title ?></h4>
							<!-- Limit the amount of texts -->
							<p align="justify"><?php echo substr($description,0,350).".....";?></p>
							<a href="<?php echo $hrefLink1."?contType=nep"; ?>#<?php echo $title; ?>" class="btn btn-info" style="">थप जान्कारी</a>
						</div>
				<?php
						
					}
				?>
					</div>
				</div>
				<div class="col-md-3">
					<?php include('include/sidebar.php');?>
				</div>
			</div>
		</div>
	</div>
	<?php include('include/footer.php');?>	
</body>
</html>

<?php
}
////////////////////////////////////////////// FOR ENGLISH CONTENTS ///////////////////////////////////
else{
	//echo "you are going to see in english";
	$val="eng";
?>
	<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>VPHO</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<div class="custom-well">
				<?php
				$sql1="select * from welcome;";
				$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
				$row1=mysqli_fetch_array($result1);
				$welcometitle1=$row1['welcomeTitle'];
				$welcomedesc1=$row1['welcomeDesc'];
				?>
					<h2><?php echo $welcometitle1; ?></span></h2>
					<p align="justify"><?php echo $welcomedesc1; ?></p>
					<a href="about_us.php" class="btn btn-info">Learn More</a>
				</div>
			</div>
			<div class="col-md-8">
				<?php 
					include('include/slider.php')
				?>
			</div>		
		</div>	
	</div>
	<div class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="row">
						<div class="col-md-12 col-xs-6">
							<div class="tender">
								<h4>Download  <!--  डाउन्लोड --></h4>
									<?php include('include/download.php'); ?>
							</div>							
						</div>
						<div class="col-md-12 col-xs-6">
							<div class="calender">								
								<h4>Calender <!-- पात्रो --></h4>
								<iframe src="http://www.nepcal.com/m_e_j3.php" frameborder="0" scrolling="no" marginwidth="0" marginheight="0" style="border:none; overflow:hidden; width:189px; height:279px;" allowtransparency="true"></iframe>
							</div> 
						</div>
					</div>				
				</div>
				<div class="col-md-6">
					<div class="row" style="padding:10px;">
					<?php
					$sqlstaff1="select * from staff where staffTitle='Senior Veterinary Officer';";
					$resultstaff1=mysqli_query($connect,$sqlstaff1) or die("Error in Mysql :".mysqli_error($connect));
					$rowstaff1=mysqli_fetch_array($resultstaff1);
					$stafftitle1=$rowstaff1['staffTitle'];
					$staffname1=$rowstaff1['staffName'];
					$staffimg1=$rowstaff1['staffImage'];

					$sqlstaff2="select * from staff where staffTitle='Veterinary Officer';";
					$resultstaff2=mysqli_query($connect,$sqlstaff2) or die("Error in Mysql :".mysqli_error($connect));
					$rowstaff2=mysqli_fetch_array($resultstaff2);
					$stafftitle2=$rowstaff2['staffTitle'];
					$staffname2=$rowstaff2['staffName'];
					$staffimg2=$rowstaff2['staffImage'];

					?>
					
						<div class="col-md-6 col-xs-6" align="center">
							<img src="<?php echo $staffimg1; ?>" class="img-thumbnail custom-imagepp" alt="<?php echo $stafftitle1; ?>">
							<p><?php echo $staffname1; ?></p>
							<p style="color:#2787BA"><?php echo $stafftitle1; ?></p>
						</div>

						<div class="col-md-6 col-xs-6" align="center">
							<img src="<?php echo $staffimg2; ?>" class="img-thumbnail custom-imagepp" alt="<?php echo $stafftitle2; ?>">
							<p><?php echo $staffname2; ?></p>
							<p style="color:#2787BA"><?php echo $stafftitle2; ?></p>
						</div>
					</div>
					<div class="row">
					<?php	
					$sql="Select * from indexmodule;";
					$query=mysqli_query($connect, $sql) or die ("Error in mysql:".mysqli_error($connect));
					while($row=(mysqli_fetch_array($query))){
						$tbname=$row['tableName'];
						$id=$row['headingID'];
						$hrefLink1=$row['modLink'];

						$colID=str_replace(" ","", $tbname."ID");
						
						$sql1="Select * from $tbname where $colID=$id;";
						$query1=mysqli_query($connect, $sql1) or die ("Error in mysql:".mysqli_error($connect));
						
						if ($row1=(mysqli_fetch_array($query1))){

							$colTitle=str_replace(" ","", $tbname."Name");
							$title=$row1[$colTitle];
														
							$coldesc=str_replace(" ","", $tbname."Desc");
							$description=$row1[$coldesc];
						}
				?>

						<div class="col-md-12 custom-wellwell">
							<h4><?php echo $title ?></h4>
							<!-- Limit the amount of texts -->
							<p align="justify"><?php echo substr($description,0,350).".....";?></p>
							<a href="<?php echo $hrefLink1; ?>#<?php echo $title; ?>" class="btn btn-info" style="">More</a>
						</div>
				<?php
						
					}
				?>
					</div>
				</div>
				<div class="col-md-3">
					<?php include('include/sidebar.php');?>
				</div>
			</div>
		</div>
	</div>
	<?php include('include/footer.php');?>	
</body>
</html>


<?php
 }
?>


<?php
include("cms_admin/connect1.php");
$count1=0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Sai Baba</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">			
			<div class="row">
				<div class="col-lg-3">
					<?php
						include('include/sidebar.php');
					?>
				</div>
				<div class="col-lg-9">
					<h3>Our Products</h3>
					<div class="row">
					<?php
						if(isset($_GET['brandid'])){
							$bid=$_GET['brandid'];


						$sqlc1="select * from product where brandID='$bid';";
						$resultc1=mysqli_query($connect,$sqlc1) or die("Error in Myslq :".mysqli_error($connect));
						$count1=mysqli_num_rows($resultc1);

						$sql1="select * from product where brandID='$bid' limit 18;";
						$result1=mysqli_query($connect,$sql1) or die("Error in Myslq :".mysqli_error($connect));
						
					?>
						<script>
					function showUser(str)
					{
					if (str=="")
					  {
					  document.getElementById("txtHint2").innerHTML="";
					  return;
					  } 
					if (window.XMLHttpRequest)
					  {// code for IE7+, Firefox, Chrome, Opera, Safari
					  xmlhttp=new XMLHttpRequest();
					  }
					else
					  {// code for IE6, IE5
					  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
					  }
					xmlhttp.onreadystatechange=function()
					  {
					  if (xmlhttp.readyState==4 && xmlhttp.status==200)
						{
						document.getElementById("txtHint2").innerHTML=xmlhttp.responseText;
						}
					  }
					xmlhttp.open("GET","product_get.php?q2=<?php echo $bid; ?> &q3="+str,true);
					xmlhttp.send();
					}
			</script> 
					<br>
 					<span id="txtHint2">
 						<?php
	 						while($row1=mysqli_fetch_array($result1))
						{
							$productname=$row1['productName'];
							$price=$row1['productPrice'];
							$image=$row1['productImagePath'];
							?>
							<!-------------- Repeat -------------->
						<div class="col-lg-4" style="padding:10px;">
							<div class="hover-over" align="middle">
								<img src="<?php echo $image;?>" alt="<?php echo $productname;?>" class="img-thumbnail custom-image">
								<strong><p><?php echo $productname;?></p></strong>
								<p><?php echo "Rs. ".$price;?></p>
								<a href="<?php echo "product_details.php?iddetail=".$row1['productID'];?>"><p class="btn btn-danger">Learn More</p></a>
							</div>
						</div>
							<!-------------- Repeat -------------->
							<?php
						}
						?>

 					</span>
 					<?php

					}
				?>
				<!-- now if product page gets category id -->
				<?php
						if(isset($_GET['cateid'])){
							$cid=$_GET['cateid'];


						$sqlc1="select * from product where categoryID='$cid';";
						$resultc1=mysqli_query($connect,$sqlc1) or die("Error in Myslq :".mysqli_error($connect));
						$count1=mysqli_num_rows($resultc1);

						$sql1="select * from product where categoryID='$cid' limit 18;";
						$result1=mysqli_query($connect,$sql1) or die("Error in Myslq :".mysqli_error($connect));
						
					?>
						<script>
					function showUser(str)
					{
					if (str=="")
					  {
					  document.getElementById("txtHint2").innerHTML="";
					  return;
					  } 
					if (window.XMLHttpRequest)
					  {// code for IE7+, Firefox, Chrome, Opera, Safari
					  xmlhttp=new XMLHttpRequest();
					  }
					else
					  {// code for IE6, IE5
					  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
					  }
					xmlhttp.onreadystatechange=function()
					  {
					  if (xmlhttp.readyState==4 && xmlhttp.status==200)
						{
						document.getElementById("txtHint2").innerHTML=xmlhttp.responseText;
						}
					  }
					xmlhttp.open("GET","product_get.php?q4=<?php echo $cid; ?> &q3="+str,true);
					xmlhttp.send();
					}
			</script> 
					<br>
 					<span id="txtHint2">
 						<?php
	 						while($row1=mysqli_fetch_array($result1))
						{
							$productname=$row1['productName'];
							$price=$row1['productPrice'];
							$image=$row1['productImagePath'];
							?>
							<!-------------- Repeat -------------->
						<div class="col-lg-4" style="padding:10px;">
							<div class="hover-over" align="middle">
								<img src="<?php echo $image;?>" alt="<?php echo $productname;?>" class="img-thumbnail custom-image">
								<strong><p><?php echo $productname;?></p></strong>
								<p><?php echo "Rs. ".$price;?></p>
								<a href="<?php echo "product_details.php?iddetail=".$row1['productID'];?>"><p class="btn btn-danger">Learn More</p></a>
							</div>
						</div>
							<!-------------- Repeat -------------->
							<?php
						}
						?>

 					</span>
 					<?php

					}
				?>
						
					</div>
					<div class="row">
				
					<?php
					$pagenum=$count1/18;
					if($count1%18!=0){
						$pagenum++;
					}
					// check if page in greater than 1 or not if is greater display pageno text else don't
					if($pagenum>=2){
					?>
						<ul class="pagination pagination-lg">Page no.
					<?php
					}
					for ($i=1; $i<=$pagenum; $i++)
					{
						if($pagenum>=2){ // check if page in greater than 1 or not if is greater display pageno button else don't

					?>					
					<li><button value="<?php echo $i; ?> " onclick="showUser(this.value)" style="width:40px; height:30px; font-size:16px; margin:1px;"> <?php echo $i; ?> </button></li>
					<?php
					}
				
				 }
				?>
						
					</ul>
				</div>		
				</div>
			</div>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
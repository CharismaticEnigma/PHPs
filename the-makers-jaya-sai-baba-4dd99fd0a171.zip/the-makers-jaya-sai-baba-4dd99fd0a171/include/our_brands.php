<?php
include("cms_admin/connect1.php");
?>
<!-- carousel CSS and Jquery -->
<link href="css/flexistyle.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/jquery.flexisel.js"></script>
<!------ carousel CSS and Jquery ------>
<ul id="flexiselDemo3">
<?php
$sql1="select * from brand;";
$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
while ($row1=mysqli_fetch_array($result1)) {
    $imagebrand=$row1['brandImagePath'];

    if ($imagebrand=="images/brand") {
        $imagebrand="images/brand/default.png";
    }

    else{
         $imagebrand=$row1['brandImagePath'];
    }
?>
    <li><img src="<?php echo $imagebrand;?>" class="custom-image150" alt="<?php echo $row1['brandName'];?>" /><p><?php echo $row1['brandName'];?></p></li>
<?php
}
?>                                             
</ul>   
<div class="clearout"></div>
<script type="text/javascript">

$(window).load(function() {
    $("#flexiselDemo1").flexisel();
    $("#flexiselDemo2").flexisel({
        enableResponsiveBreakpoints: true,
        responsiveBreakpoints: { 
            portrait: { 
                changePoint:480,
                visibleItems: 1
            }, 
            landscape: { 
                changePoint:640,
                visibleItems: 2
            },
            tablet: { 
                changePoint:768,
                visibleItems: 3
            }
        }
    });

    $("#flexiselDemo3").flexisel({
        visibleItems: 3,
        animationSpeed: 1000,
        autoPlay: true,
        autoPlaySpeed: 3000,            
        pauseOnHover: true,
        enableResponsiveBreakpoints: true,
        responsiveBreakpoints: { 
            portrait: { 
                changePoint:480,
                visibleItems: 1
            }, 
            landscape: { 
                changePoint:640,
                visibleItems: 2
            },
            tablet: { 
                changePoint:768,
                visibleItems: 3
            }
        }
    });

    $("#flexiselDemo4").flexisel({
        clone:false
    });
    
});
</script>
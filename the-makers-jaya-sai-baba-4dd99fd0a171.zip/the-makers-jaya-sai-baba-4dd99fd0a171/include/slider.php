<?php

?>
<div id="slider" style="margin-top:30px;">
					<section class="slider">
				        <div class="flexslider">
				          <ul class="slides">
				          <?php
				          $sql1="select * from sliderimage;";
				          $result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysql_error($connect));
				          while($row1=mysqli_fetch_array($result1)){
				          	?>
				          	<li>
				              <img src="<?php echo $row1['sliderimageImagePath'];?>" />
				            </li>
				          	<?php
				          }
				          ?>
				           </ul>
				        </div>
	      			</section>      		
				
		  			<!-- FlexSlider -->
		  			<script defer src="js/jquery.flexslider.js"></script>

		  			<script type="text/javascript">
		    			$(function(){
		      				SyntaxHighlighter.all();
		    			});
		    			$(window).load(function(){
		      			$('.flexslider').flexslider({
		        			animation: "slide",
		       	 			start: function(slider){
		          		$('body').removeClass('loading');
		        		}
		      			});
		    			});
		  				</script>


		  			<!-- Syntax Highlighter -->
		  			<script type="text/javascript" src="jquery/shCore.js"></script>
		  			<script type="text/javascript" src="jquery/shBrushXml.js"></script>
		  			<script type="text/javascript" src="jquery/shBrushJScript.js"></script>

		  			<!-- Optional FlexSlider Additions -->
		  			<script src="jquery/jquery.easing.js"></script>
		  			<script src="jquery/jquery.mousewheel.js"></script>
				</div>
<?php
include('cms_admin/connect1.php');
?>
<!------ CSS & JS ------>       
  <link rel="stylesheet" href="css/bootstrap.css"> 
  <link rel="stylesheet" href="css/bootswatch.css">       
  <link rel="stylesheet" href="css/flexslider.css">        
  <link rel="stylesheet" href="css/custom-css.css">
  <link rel="stylesheet" href="css/sidemenu.css">
  <link rel="stylesheet" href="css/smoothzoom.css">

  <script src="js/ajax.googleapis"></script>
  <script src="js/jquery.flexslider.js" type="text/javascript"></script>
  <script src="js/modernizr.js"></script>    
  <script src="js/jquery.min.js" type="text/javascript"></script>
  <script src="js/modernizr.custom.17475.js" type="text/javascript"></script>
  <script src="js/jquery-1.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="js/bootswatch.js"></script>

<!------ --------- ------>

<div class="navbar navbar-default navbar-fixed-top">
  <div class="container" align="middle">
    <div class="navbar-header">
          <a href="index.php" class="navbar-brand"><h2 style="margin-top:-6px;">Jaya Sai Baba</h2></a>
          <button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target="#navbar-main">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
    </div>
    <div style="height: 1px;" class="navbar-collapse collapse" id="navbar-main">
      <ul class="nav navbar-nav">
          <li class="dropdown"><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
          <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="themes"><span class="glyphicon glyphicon-credit-card"></span> Products <span class="caret"></span></a>
            <ul class="dropdown-menu" aria-labelledby="themes">
            <?php
              $sql1="select * from category;";
              $result1=mysqli_query($connect, $sql1) or die("Error in Mysql :".mysqli_error($connect));
              while ($row1=mysqli_fetch_array($result1)){
            ?>
              <li><a href="<?php echo "categories.php?id=".$row1['categoryID'];?>"><?php echo $row1['categoryName'];?></a></li>
            <?php
              }
            ?>
            </ul>
          </li>
          <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="themes">
            <span class="glyphicon glyphicon-tasks"></span> Brands <span class="caret"></span></a>
            <ul class="dropdown-menu" aria-labelledby="themes">
            <?php
               $sql2="select * from brand;";
               $result2=mysqli_query($connect, $sql2) or die("Error in Mysql :".mysqli_error());
               while ($row2=mysqli_fetch_array($result2))
               {
            ?>
              <li><a href="<?php echo "brands.php?id=".$row2['brandID']; ?>"><?php echo $row2['brandName']; ?></a></li>
            <?php
              }
            ?>
            </ul>
          </li>
          <li>
            <a href="about_us.php"><span class="glyphicon glyphicon-info-sign"></span> About</a>
          </li>
          <li>
            <a href="contact_us.php" id="contact"><span class="glyphicon glyphicon-envelope"></span> Contact</a>             
          </li>
      </ul>
      <ul class="search">
        <li>
          <div class="search">
            <form action="search.php" method="get">
              <input type="search" placeholder="Search Products" name="pnm">
            </form>
          </div>
        </li>
      </ul>
    </div>    
  </div>
</div>

        
          

       
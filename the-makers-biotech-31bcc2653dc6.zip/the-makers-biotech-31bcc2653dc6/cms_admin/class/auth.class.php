<?php
class Auth
{

	function login(){
		include("connect1.php");
		$username= mysql_real_escape_string($_POST['user']);
		$password= mysql_real_escape_string(md5($_POST['pass']));
		
		
		$query=mysqli_query($connect,"select * from login where Login_Name='$username' && Login_Pass='$password'");
		$row=mysqli_num_rows($query);
		
		if($row>0){
						
				$_SESSION['Login_Name']=$username;
				header("Location:add_category.php");
				exit();
				}
				else{
					echo "<h3 style='color:red'> Invalid Username or Password!! Please Try again..</h3>";
										
				exit ();
				}
				
				}
	
	}
	
	$Auth=new Auth();


?>
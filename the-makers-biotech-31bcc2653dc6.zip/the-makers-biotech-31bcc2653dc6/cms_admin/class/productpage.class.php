<?php

class Productpage
{
	function insertProduct(){
	
		$name=$_POST['productname'];		
		$price=$_POST['productprice'];
		$bid=$_POST['brandid'];
		$scid=$_POST['categoryid'];
		$desc=$_POST['productdesc'];
		$pdate=$_POST['productdate'];
		$pstatus=$_POST['productstatus'];

		if($bid!="-- Choose Title --" && $scid!="-- Choose Title --"){
			//the php script to upload the image
		$imagename = $_FILES["newsimg"]["name"];
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		//path to put into the database table
		$path = "images/product/$imagename";
		
		//actual server destination folder
		$dest = "../images/product/$imagename";
		$arr = explode(".",$imagename);
		//check whether the extention is correct
		$ext = $arr[1];
		
			if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG') or($ext==''))
			{
				if(file_exists($dest)){
				echo "an image with that name already exists.. Please change your file";
				}
			else{	
					//copy the temporarily uploaded file to the server destination (actual upload)
					copy($tmpimage,$dest);
					//@rename($dest,"../studpics/$id.$ext");
					include("connect1.php");

					$sql= "insert into product (productName,productPrice,categoryID,brandID,productDesc,productImagePath,productEntryDate,productStatus) values ('$name','$price',$scid,$bid,'$desc','$path','$pdate','$pstatus');";
					mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
					
					//echo "data sucessfully added";
				}
			}
			else
			{
				echo "invalid photo! try again.";
				exit;
			}

		}
		else{
			echo "Please select brand name and category name before proceeding";
		}
				

		
				//upload script ends				
		
		
	}


	function editProduct(){
		include("connect1.php");
		$name=$_POST['nm'];
		$price=$_POST['price'];
		$brand=$_POST['brand'];
		$category=$_POST['sub'];
		$date=$_POST['date'];
		$status=$_POST['status'];
		$desc=$_POST['desc'];
		$pid=$_POST['pid'];


		
		if(isset($name) && $name !=Null){
			$sqlup=mysqli_query($connect,"Update product Set productName='$name' where productID='$pid';");	
		}
		if(isset($price) && $price !=Null){
			$sqlup=mysqli_query($connect,"Update product Set productPrice='$price' where productID='$pid';");	
		}

		if(isset($desc)&& $desc !=Null){
			$sqlup=mysqli_query($connect,"Update product Set productDesc='$desc' where productID='$pid';");	
		}
		if(isset($date)&& $date !=Null){
			$sqlup=mysqli_query($connect,"Update product Set productEntryDate='$date' where productID='$pid';");	
		}

		if($status !="-- Select --" && $status !=Null){			
			$sqlup=mysqli_query($connect,"Update product Set productStatus='$date' where productID='$pid';");	
		}

		
		if($brand!="-- Select --" && $brand !=Null){
			$sqlup=mysqli_query($connect, "Update product Set brandID='$brand' where productID='$pid';");
						
		}

		if($category!="-- Select --" && $category !=Null){
			$sqlup=mysqli_query($connect, "Update product set categoryID='$category' where productID='$pid';");
		}


			//the php script to upload the image
		$imagename = $_FILES["newsimg"]["name"];
		
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		//path to put into the database table
		$path = "images/product/$imagename";
		
		//actual server destination folder
		$dest = "../images/product/$imagename";
		
		
		if (isset($imagename) && $imagename!= Null)
		{
		
		$arr = explode(".",$imagename);
		//check whether the extention is correct
		$ext = $arr[1];
		
		if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG') or($ext==''))
		{	
				if(file_exists($dest)){
					echo "an image with that name already exists.. Please change your file";
				}
				else{
					if(isset($path) && $path !=Null){

						$sql1="Select * from product where productID='$pid';";
						$res=mysqli_query($connect,$sql1);
						while($row1 = mysqli_fetch_array($res))
						{
			 				$imgs=$row1['productImagePath'];
			 				$arr=array();
			 				 $arr= (explode ("/",$imgs));
			 				 $cdr=getcwd();
			 				 chdir("../images/product");
			 				 unlink($arr[2]);
			 			}
			 			chdir($cdr);
			 			echo "Recent dir: ".getcwd();
			 			copy($tmpimage,$dest);
						$sqlup=mysqli_query($connect,"Update product Set productImagePath='$path' where productID='$pid'");	

					}
			//copy the temporarily uploaded file to the server destination (actual upload)
			}
		}
		else
		{
			echo "invalid photo! try again.";
			exit;
		}		
	}
	//end of image edit

		
		
		
	}

	function deleteProduct(){
		include("connect1.php");
		 $pid=$_POST['pid'];
		 $path=$_POST['imagepath'];
		 	$arr=array();
 			$arr= (explode ("/",$path));
 			chdir("../images/product");
 			unlink($arr[2]);
		 	$s2="Delete from product where productID='$pid';";
		 	mysqli_query($connect,$s2) or die("Error in mysql: ".mysqli_error($connect));
		 	//echo "Product Deleted";
		 	header('location:edit_delete_product.php');

	}




	


	
	
	
	}
$Productpage= new Productpage();
?>
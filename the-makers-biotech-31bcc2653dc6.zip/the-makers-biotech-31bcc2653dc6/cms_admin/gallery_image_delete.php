<?php
include("connect.php");
	/*if(!isset($_SESSION['Login_Name'])){
		header("Location:index.php");
		exit();
	}

else{ */
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Gallery</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css" />
</head>

<body>



              
<div id="wrapper">
<div style="text-align:right;"><a href="logout.php" style="font-size:20px; text-decoration:none;" > Logout </a></div>
<div class="header"><a href="#" style="text-decoration:none; color:#333;">Delete Gallery Image</a></div>
<div class="header2">
    <?php
 include('class/menu.php');
 ?>
</div>

		<div class="form_wrapper">

		

    <div class="form1" style="margin-left:-90px">
    <?php
$imgName=array();
$imgPath=array();
$imageID=array();
                $query = "select * from galleryimage;";
                $result = mysqli_query($connect,$query) or die ("Error in Mysqli: ".mysqli_error($connect));
        while ($row=mysqli_fetch_array($result)){
            array_push($imgName, $row['galleryimageName']);
            array_push($imgPath, $row['galleryimageImagePath']);
            array_push($imageID, $row['galleryimageID']);
            }
			              ?>
        <table >
        <?php
            for($i=0;$i<sizeof($imgName);$i=$i+3){
                ?>
                
<?php
                if (isset($imgName[$i])){

     ?>
     <tr>
     <td >
            <div style="margin-left:-60;"><img src="<?php echo "../../mrs/".$imgPath[$i]?>" height="170px" width ="170px" ></div>
            <div style="width:200px;"><?php echo $imgName[$i]?></div>
          <a style="text-decoration:none;" href="gallery_delete.php?id=<?php echo $imageID[$i]?>">Delete</a> 
          <div style="visibility:hidden"><?php echo $imageID[$i]?></div>
            </td>
     <?php           
               }
                if (isset($imgName[$i+1])){

     ?>
     <td >
            <div style="margin-left:-60;"><img src="<?php echo "../../mrs/".$imgPath[$i+1]?>" height="170px" width ="170px"></div>
            <div style="width:200px;"><?php echo $imgName[$i+1]?></div>
            <a style="text-decoration:none;" href="gallery_delete.php?id=<?php echo $imageID[$i+1]?>">Delete</a> 
            <div style="visibility:hidden"><?php echo $imageID[$i+1]?></div>
            </td>
     <?php           
               }
                if (isset($imgName[$i+2])){
     ?>
     <td >
            <div style="margin-left:-60;"><img src="<?php echo "../../mrs/".$imgPath[$i+2]?>" height="170px" width ="170px"></div>
            <div style="width:200px;"><?php echo $imgName[$i+2]?></div>
            <a style="text-decoration:none;" href="gallery_delete.php?id=<?php echo $imageID[$i+2]?>">Delete</a> 
            <div style="visibility:hidden"><?php echo $imageID[$i+2]?></div>
            </td>
            </tr>
     <?php           
               }    
            }
        ?>
           
         </table>
		 
		 
    </div>
		</div>
</div>
</body>
</html>
<?php
//}
?>
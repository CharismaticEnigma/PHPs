<?php
include("cms_admin/connect1.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Biotech Trading Concern</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

</head>

<body>
  <?php include('include/header.php') ?>
    <div class="container well" style="">
          <div class="row clearfix ">
          <?php
           $sql1="select * from about;";
           $result1=mysqli_query($connect,$sql1) or die("Error in Myslq : line 21".mysqli_error($connect));
           while($row1=mysqli_fetch_array($result1)){
              $aboutname=$row1['aboutName'];
              $aboutdesc=$row1['aboutDesc'];
              $aboutimagepath=$row1['aboutImagePath'];
     
        if ($aboutimagepath!="noimage")
        { 
          ?>
              <h3> <?php echo $aboutname; ?></h3>
                  <div class="col-md-12 column" >
                      <div class="media ">
                            <a href="#" class="pull-left"><img src="<?php echo $aboutimagepath; ?>" height="100"  class="media-object thumbnail custom-image" alt="$aboutname"></a>
                            <div class="media-body">
                                <p><?php echo $aboutdesc;?></p>
                            </div>
                      </div>
                  </div>
                  <?php
                  }
                  else{
                    ?>
                     <h3> <?php echo $aboutname; ?></h3>
                  <div class="col-md-12 column" >
                      <div class="media ">
                            <div class="media-body">
                            <p><?php echo $aboutdesc; ?></p>
                            </div>
                      </div>
                  </div>
                  <?php

                  }
                }
                  ?>
          </div>
    </div>

  <?php include('include/footer.php') ?>

</body>
</html>
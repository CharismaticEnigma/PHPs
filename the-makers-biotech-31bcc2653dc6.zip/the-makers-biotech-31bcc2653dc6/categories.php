<?php
include("cms_admin/connect1.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Biotech Trading Concern</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">			
		<div class="row">
			<div class="col-lg-3">
				<?php
					include('include/sidebar.php');
				?>
			</div>
			<div class="col-lg-9">
			<?php
					$cid=$_GET['id'];
					$sql1="select * from category where categoryID='$cid';";
					$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :line 28".mysqli_error($connect));
					while ($row1=mysqli_fetch_array($result1)) {
						$categoryName=$row1['categoryName'];
						$categoryimage=$row1['categoryImagePath'];
						$categoryDesc=$row1['categoryDesc'];
						if ($categoryimage=="images/category")
						{
							$categoryimage="images/category/default.png";
						}
						else{
							$categoryimage=$row1['categoryImagePath'];
						}
					}
				?>
				<h3><?php echo $categoryName ?></h3>
				<ul class="media-list">						
					<li class="media">
						<img src="<?php echo $categoryimage ?>" class="pull-left img-thumbnail" alt="<?php echo $categoryName ?>">
						<div class="media-body">
							<p align="justify">
								<?php echo $categoryDesc; ?>
							</p>
						</div>
					</li>
				</ul>
				<div class="well">
					<h3>Brands</h3>
						<div class="row" align="center">
						<?php
				
					$sql2="select distinct brandID from product where categoryID='$cid';";
					$result2=mysqli_query($connect,$sql2) or die("Error in Mysql :line 48".mysqli_error($connect));
					while($row2=mysqli_fetch_array($result2)){
						$brandid=$row2['brandID'];
												
						$sql3="select * from brand where brandID='$brandid';";
						$result3=mysqli_query($connect,$sql3) or die("Error in Mysql :line 59".mysqli_error($connect));
						while($row3=mysqli_fetch_array($result3)){
							$brandimage=$row3['brandImagePath'];
							$brandname=$row3['brandName'];
							$branddesc=$row3['brandDesc'];

							if($brandimage=="images/brand")
							{
								?>
							<div class="col-md-3">
								<div class="cat-container" style="margin-bottom: 8px;">
									<a href="<?php echo "products.php?id=".$brandid;?>"><img src="images/brand/default1.png" class="img-thumbnail custom-otherimage" alt="<?php echo $brandname; ?>" style="margin-top:-60px;"></a>
									<h4><?php echo $brandname; ?></h4>
								</div>														
							</div>
							<?php
							}
							else
							{

							?>
							<div class="col-md-3">
									<div class="cat-container" style="margin-bottom: 8px;">
										<a href="<?php echo "products.php?brandid=".$brandid;?>"><img src="<?php echo $brandimage; ?>" class="img-thumbnail custom-otherimage" alt="<?php echo $brandname; ?>" style="margin-top:-60px;"></a>
										<h4><?php echo $brandname; ?></h4>
									</div>														
								</div>
							<?php
							}
						
						}

					}
				?>

						</div>
					
				</div>
			</div>
		</div>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    
    <link href="css/style.css" rel="stylesheet">
    <link href="css/custom-css.css" rel="stylesheet">
    
   <link rel="stylesheet" href="css/sidemenu.css">
   <script type='text/javascript' src='js/ajax.googleapis.js'></script>
   

  
  <link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
  <link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  <link rel="shortcut icon" href="img/favicon.png">  
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>

    <script type="text/javascript" src="js/scripts.js"></script>
    <link rel="stylesheet" href="css/colorbox.css" />
  <script src="js/jquery.colorbox.js"></script>
  <script>
      $(document).ready(function(){
        //Examples of how to assign the Colorbox event to elements
        $(".group1").colorbox({rel:'group1'});
        $(".group2").colorbox({rel:'group2', transition:"fade"});
        $(".group3").colorbox({rel:'group3', transition:"none", width:"75%", height:"75%"});
        $(".group4").colorbox({rel:'group4', slideshow:true});
        $(".ajax").colorbox();
        $(".youtube").colorbox({iframe:true, innerWidth:640, innerHeight:390});
        $(".vimeo").colorbox({iframe:true, innerWidth:500, innerHeight:409});
        $(".iframe").colorbox({iframe:true, width:"80%", height:"80%"});
        $(".inline").colorbox({inline:true, width:"50%"});
        $(".callbacks").colorbox({
          onOpen:function(){ alert('onOpen: colorbox is about to open'); },
          onLoad:function(){ alert('onLoad: colorbox has started to load the targeted content'); },
          onComplete:function(){ alert('onComplete: colorbox has displayed the loaded content'); },
          onCleanup:function(){ alert('onCleanup: colorbox has begun the close process'); },
          onClosed:function(){ alert('onClosed: colorbox has completely closed'); }
        });

        $('.non-retina').colorbox({rel:'group5', transition:'none'})
        $('.retina').colorbox({rel:'group5', transition:'none', retinaImage:true, retinaUrl:true});
        
        //Example of preserving a JavaScript event for inline calls.
        $("#click").click(function(){ 
          $('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
          return false;
        });
      });
    </script>
  <!-- color box css and jquery end --> 
<div class="row clearfix" style="width:100%; margin-bottom:100px;">
            <div class="col-md-12 column">
              <nav class="navbar navbar-default navbar-inverse navbar-fixed-top" role="navigation">
                    <div class="navbar-header" style="margin-left:40px;">
                         <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> 
                         <span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span>
                         <span class="icon-bar"></span></button> <a class="navbar-brand" href="#"><img src="img/logo.png"/></a>
                    </div>
                    
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style=" ">
                        <ul class="nav navbar-nav " style="margin-top:15px;  margin-left:10px;">
                            <li class="">
                                <a href="index.php">Home</a>
                            </li>
                           <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Products<strong class="caret"></strong></a>
                                <ul class="dropdown-menu">
                                  <?php
                                      $sql1="select * from category;";
                                      $result1=mysqli_query($connect, $sql1) or die("Error in Mysql :".mysqli_error($connect));
                                      while ($row1=mysqli_fetch_array($result1)){
                                  ?>
                                  <li><a href="<?php echo "categories.php?id=".$row1['categoryID'];?>"><?php echo $row1['categoryName'];?></a></li>
                                  <?php
                                      }
                                  ?>
             
          </ul>
                            </li>
                             <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Brands<strong class="caret"></strong></a>
                                <ul class="dropdown-menu">
                                    <?php
                                       $sql2="select * from brand;";
                                       $result2=mysqli_query($connect, $sql2) or die("Error in Mysql :".mysqli_error());
                                       while ($row2=mysqli_fetch_array($result2))
                                       {
                                    ?>
                                    <li><a href="<?php echo "brands.php?id=".$row2['brandID']; ?>"><?php echo $row2['brandName']; ?></a></li>
                                  <?php
                                    }
                                  ?>
                                 </ul>
                            </li>
                            <li>
                                <a href="news.php">News And Events</a>
                            </li>
                            <li>
                                <a href="gallery.php">Gallery</a>
                            </li>
                            <li>
                                <a href="about.php">About Us</a>
                            </li>
                            <li>
                                <a href="contact.php">Contact Us</a>
                            </li>
                            <li>
                                <div class="search">
                                    <form action="search.php" method="get">
                                      <input type="search" placeholder="Product" name="pnm">
                                    </form>
                                </div>
                            </li>
                        </ul>
                        
                        
                    </div>
                    
                </nav>
            </div>
      </div>
    
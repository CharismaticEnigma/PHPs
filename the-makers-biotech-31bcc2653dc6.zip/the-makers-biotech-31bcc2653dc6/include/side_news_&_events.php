<?php
	
?>
<script src="js/jquery.bootstrap.newsbox.js" type="text/javascript"></script>


<div class="panel panel-default">
	<div class="panel-heading"> <span class="glyphicon glyphicon-list-alt"></span><b>News & Events Check it out</b></div>
		<div class="panel-body">
			<div class="row">
				<div class="col-xs-12">
					<ul class="demo1">
					<?php
						$sql="Select * from news;";
						$result=mysqli_query($connect,$sql) or die("Error in mysql: ".mysqli_error());
						while ($row=mysqli_fetch_array($result)){
							$newstitle=$row['newsTitle'];
							$newsimagepath=$row['newsImagePath'];
							$newsdesc=$row['newsDesc'];
							if ($newsimagepath=="images/news")
							{
							?>

								<li class="news-item">
									<table cellpadding="4">
										<tr>
											<td><img src="images/news/defaultnews.jpg" alt="<?php echo $newstitle; ?>" width="40" class="img-circle" /></td>
											<td><?php echo substr($newsdesc,0,125)."....";?> <a href="news.php#<?php echo $row['newsID']?>">Read more...</a></td>
											
										</tr>
									</table>
								</li>
					<?php
							}
							else{
								?>
								<li class="news-item">
									<table cellpadding="4">
										<tr>
											<td><img src="<?php echo $newsimagepath ?>" alt="<?php echo $newstitle?>" width="40" class="img-circle" /></td>
											<td><?php echo substr($newsdesc,0,125)."....";?> <a href="news.php#<?php echo $row['newsID']?>">Read more...</a></td>
											
										</tr>
									</table>
								</li>
								<?php
							}
					}
						?>
						
					</ul>
				</div>
			</div>
		</div>
<div class="panel-footer"> </div>
</div>
<script type="text/javascript">
    $(function () {
        $(".demo1").bootstrapNews({
            newsPerPage: 3,
            autoplay: true,
			pauseOnHover:true,
            direction: 'up',
            newsTickerInterval: 4000,
            onToDo: function () {
                //console.log(this);
            }
        });
		
		$(".demo2").bootstrapNews({
            newsPerPage: 4,
            autoplay: true,
			pauseOnHover: true,
			navigation: false,
            direction: 'down',
            newsTickerInterval: 2500,
            onToDo: function () {
                //console.log(this);
            }
        });

        $("#demo3").bootstrapNews({
            newsPerPage: 3,
            autoplay: false,
            
            onToDo: function () {
                //console.log(this);
            }
        });
    });
</script>
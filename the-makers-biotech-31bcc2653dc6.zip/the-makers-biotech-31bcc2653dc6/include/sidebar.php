<?php
?>
<div id='cssmenu'>
   <ul>
      <li class="heading"><a><strong><span>Categories</span></strong></a></li>
         <ul class="custom-ul">
         <?php
         $sql1="select * from category;";
       	 $result1=mysqli_query($connect,$sql1) or die("Error in Myslq : line 10".mysqli_error($connect));
       	 while($row1=mysqli_fetch_array($result1))
       	 {
         ?>
            <li><a href='<?php echo "categories.php?id=".$row1['categoryID'];?>'><span><?php echo $row1['categoryName'];?></span></a></li>
        <?php
    	}
        ?>
           
         </ul>   
   </ul>
</div>
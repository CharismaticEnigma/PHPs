<div style="background-color:#000;  width:100%; color:#CCC;">
    <div class="row clearfix" style=" width:80%; margin:0 auto;">
        <div class="col-md-4 well-lg ">
          <h3>Gallery</h3>
          <?php
            $sq1="Select * from galleryimage limit 6;";
            $qr1=mysqli_query($connect, $sq1) or die ("Error in Mysqli: ".mysqli_error($connect));
            while($rs=mysqli_fetch_array($qr1)){
              $galImg=$rs['galleryimageImagePath'];
              $galName=$rs['galleryimageName'];
         ?>        
            <a href="<?php echo $galImg;?>" target="_blank"><img src="<?php echo $galImg;?>" style="height:100px; max-width:75px; float:left;"  alt="<?php echo $galName;?>"class=" image img-rounded" /></a>
         <?php
            }
         ?>
        </div>
        <div class="col-md-3 well-lg">
                    <h3>
                        Partners
                    </h3>
                    <ul class="list-unstyled" style="color:#ffffff;" >
                              <?php
                        $sq1="Select * from brand limit 5;";
                        $q1=mysqli_query($connect,$sq1) or die ("Error in Mysqli: ".mysqli_error($connect));
                        while ($rs1=mysqli_fetch_array($q1)){
                          $id=$rs1['brandID'];
                          $name=$rs1['brandName'];
                       ?>
                         <li><a href="brands.php?id=<?php echo $id; ?>" ><?php echo $name; ?></a></li><br />
                      <?php
                        }
                     ?>
                    </ul>
        </div>
        <div class="col-md-3 well-lg">
              <h3>
                   Contact Us
              </h3>
              <address> 
                        Tripureshwor Plaza
                        <p class="contact_info">
                             <span>Address: </span>Tripureshwor,Ktahmandu,Nepal <br />
                             <span>Telephone: </span>+977-01-4282096,4223461<br />
                             <span>E-mail: </span>biotech.bijay@gmail.com,<br /> 
                             <span>&nbsp; &nbsp; &nbsp;</span>mala.techno@gmail.com
                        </p>
              </address>
        </div>
        <div class="col-md-2 well-lg">
                    <h3>
                        Follow Us
                    </h3>
                    <p><a href="#"><img src="img/fb.png" alt="Facebook"></a></p>
                    <p><a href="#"><img src="img/twitter.png" alt="Twitter"></a></p>
        </div>
    </div>
    <div class="row clearfix" style="width:80%; margin:0 auto; border-top:1px solid #fff;" align="center"  >
        Copyright &copy BIOTECH NEPAL All Rights Reserved.<br />
        Powered By: <a href="http://www.hitechskills.com" style="color:#fff;">Hi - Tech Skills</a>
    </div>
</div>
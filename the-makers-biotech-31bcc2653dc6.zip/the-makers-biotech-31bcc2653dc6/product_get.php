<?php
include("cms_admin/connect1.php");

										
					
					if(isset($_GET['q2'])){
						$bidget=$_GET['q2'];
						$pagenumber=$_GET['q3'];


						if ($pagenumber==1){

							$sql1="select * from product where brandID='$bidget' limit 18;";
							$result1=mysqli_query($connect,$sql1) or die("Error in Myslq :".mysqli_error($connect));

							while($row1=mysqli_fetch_array($result1))
							{
								$productname=$row1['productName'];
								$price=$row1['productPrice'];
								$image=$row1['productImagePath'];
								?>
								<!-------------- Repeat -------------->
							<div class="col-lg-4" style="padding:10px;">
								<div class="hover-over" align="middle">
									<img src="<?php echo $image;?>" alt="<?php echo $productname;?>" class="img-thumbnail custom-image">
									<strong><p><?php echo $productname;?></p></strong>
									<p><?php echo "Rs. ".$price;?></p>
									<a href="<?php echo "product_details.php?iddetail=".$row1['productID'];?>"><p class="btn btn-success">Learn More</p></a>
								</div>
							</div>

							<!-------------- Repeat -------------->
								<?php
							}
						}

						else{
							//echo $pagenumber;
							$pagefirst=18*($pagenumber-1);
							$sql1="select * from product where brandID='$bidget' limit $pagefirst,18;";
							$result1=mysqli_query($connect,$sql1) or die("Error in Myslq :".mysqli_error($connect));

							while($row1=mysqli_fetch_array($result1))
							{
								$productname=$row1['productName'];
								$price=$row1['productPrice'];
								$image=$row1['productImagePath'];
								?>
								<!-------------- Repeat -------------->
								<div class="col-lg-4" style="padding:10px;">
									<div class="hover-over" align="middle">
										<img src="<?php echo $image;?>" alt="<?php echo $productname;?>" class="img-thumbnail custom-image">
										<strong><p><?php echo $productname;?></p></strong>
										<p><?php echo "Rs. ".$price;?></p>
										<a href="<?php echo "product_details.php?iddetail=".$row1['productID'];?>"><p class="btn btn-success">Learn More</p></a>
									</div>
								</div>
							<!-------------- Repeat -------------->
								<?php
							}

						}										

					}
					
				//pagination for category
					if(isset($_GET['q4'])){
						$cidget=$_GET['q4'];
						$pagenumber=$_GET['q3'];
												

						if ($pagenumber==1){
							
							$sql2="select * from product where categoryID=$cidget limit 18;";
							$result2=mysqli_query($connect,$sql2) or die("Error in Mysql :".mysqli_error($connect));
							$count2=mysqli_num_rows($result2);

							while($row2=mysqli_fetch_array($result2))
							{
							$productname=$row2['productName'];
							$price=$row2['productPrice'];
							$image=$row2['productImagePath'];
								?>
								<!-------------- Repeat -------------->
								<div class="col-lg-4" style="padding:10px;">
									<div class="hover-over" align="middle">
										<img src="<?php echo $image;?>" alt="<?php echo $productname;?>" class="img-thumbnail custom-image">
										<strong><p><?php echo $productname;?></p></strong>
										<p><?php echo "Rs. ".$price;?></p>
										<a href="<?php echo "product_details.php?iddetail=".$row1['productID'];?>"><p class="btn btn-success">Learn More</p></a>
									</div>
								</div>

							<!-------------- Repeat -------------->
								<?php
							}
						}

						else{

							$pagefirst=18*($pagenumber-1);
							$sql2="select * from product where categoryID=$cidget  limit $pagefirst,18;";
							$result2=mysqli_query($connect,$sql2) or die("Error in Myslq :".mysqli_error($connect));

							while($row2=mysqli_fetch_array($result2))
							{
								$productname=$row2['productName'];
								$price=$row2['productPrice'];
								$image=$row2['productImagePath'];
								?>
								<!-------------- Repeat -------------->
								<div class="col-lg-4" style="padding:10px;">
									<div class="hover-over" align="middle">
										<img src="<?php echo $image;?>" alt="<?php echo $productname;?>" class="img-thumbnail custom-image">
										<strong><p><?php echo $productname;?></p></strong>
										<p><?php echo "Rs. ".$price;?></p>
										<a href="<?php echo "product_details.php?iddetail=".$row1['productID'];?>"><p class="btn btn-success">Learn More</p></a>
									</div>
								</div>

							<!-------------- Repeat -------------->
								<?php
							}

						}	

					}

					//pagination for new status
					if(isset($_GET['qnew'])){
						$pstatus=$_GET['qnew'];
						$pagenumber=$_GET['q3'];
						
						if ($pagenumber==1){

							$sql1="select * from product where productStatus='$pstatus' limit 18;";
							$result1=mysqli_query($connect,$sql1) or die("Error in Myslq :".mysqli_error($connect));

							while($row1=mysqli_fetch_array($result1))
							{
								$productname=$row1['productName'];
								$price=$row1['productPrice'];
								$image=$row1['productImagePath'];
								?>
								<!-------------- Repeat -------------->
							<div class="col-lg-4" style="padding:10px;">
								<div class="hover-over" align="middle">
									<img src="<?php echo $image;?>" alt="<?php echo $productname;?>" class="img-thumbnail custom-image">
									<strong><p><?php echo $productname;?></p></strong>
									<p><?php echo "Rs. ".$price;?></p>
									<a href="<?php echo "product_details.php?iddetail=".$row1['productID'];?>"><p class="btn btn-success">Learn More</p></a>
								</div>
							</div>

							<!-------------- Repeat -------------->
								<?php
							}
						}

						else{
							//echo $pagenumber;
							$pagefirst=18*($pagenumber-1);
							$sql1="select * from product where productStatus='$pstatus' limit $pagefirst,18;";
							$result1=mysqli_query($connect,$sql1) or die("Error in Myslq : line 12".mysqli_error($connect));

							while($row1=mysqli_fetch_array($result1))
							{
								$productname=$row1['productName'];
								$price=$row1['productPrice'];
								$image=$row1['productImagePath'];
								?>
								<!-------------- Repeat -------------->
							<div class="col-lg-4" style="padding:10px;">
								<div class="hover-over" align="middle">
									<img src="<?php echo $image;?>" alt="<?php echo $productname;?>" class="img-thumbnail custom-image">
									<strong><p><?php echo $productname;?></p></strong>
									<p><?php echo "Rs. ".$price;?></p>
									<a href="<?php echo "product_details.php?iddetail=".$row1['productID'];?>"><p class="btn btn-success">Learn More</p></a>
								</div>
							</div>

							<!-------------- Repeat -------------->
								<?php
							}

						}										

					}
				?>		
				
<?php
include("cms_admin/connect1.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Biotech Trading Concern</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

  
</head>

<body>
  <?php include('include/header.php') ?>
    <div class="container">
        <h3>Our Gallery</h3>
        <div class="row">
        <?php
        $s1="Select * from galleryimage;";
        $qr=mysqli_query($connect,$s1) or die ("Error in mysqli: ".mysqli_error($connect));
        while ($rs=mysqli_fetch_array($qr)){
            $imgName=$rs['galleryimageName'];
            $imgPath=$rs['galleryimageImagePath'];
            $imgID=$rs['galleryimageID'];

        ?>
       
            <div class="col-md-3">
              <div style="text-align:center;">
                <a class="group1" href="<?php echo $imgPath; ?>" title="<?php echo $imgName;?>" alt="<?php echo $imgName;?>">
                                    <img src="<?php echo $imgPath; ?>" class="img-thumbnail" style="width:200px; height:200px;">
                                </a>
                                <p><?php echo $imgName;?></p>
                   
                </div>
            </div>
             <?php
        }
       ?>
       </div>
      

    </div>
  <?php include('include/footer.php') ?>

</body>
</html>

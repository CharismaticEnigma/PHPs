<?php
include('cms_admin/connect1.php');
$a=1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Bio Tech Concern</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">
 
</head>

<body>
<?php include('include/header.php') ?>
	<div class="container" style="">
      <div class="row clearfix well-lg" style=" margin-top:-20px">
          <div class="col-md-12 column">
              <div class="carousel slide" id="carousel-323560">
                <div class="carousel-inner">
                  <?php
                    $s1="Select * from sliderimage;";
                    $q1=mysqli_query($connect, $s1) or die ("Error in Mysqli: ".mysqli_error($connect));
                    while($r1=mysqli_fetch_array($q1)){

                      $imgpath=$r1['sliderimageImagePath'];
                      $imgid=$r1['sliderimageID'];
                      $arr=explode("/",$imgpath);
                      $imgnm=$arr[2];
                      if ($a==1){
                ?>
                <div class="item active">
                  <img src="<?php echo $imgpath;?>" alt="<?php echo $imgnm; ?>">
                </div>
                <?php
              }
              else{
                
                ?>
                <div class="item">
                  <img src="<?php echo $imgpath;?>" alt="<?php echo $imgnm; ?>">
                </div>
                <?php
              }
                $a++;
              
            }
            ?>
                </div> 
                <a class="left carousel-control" href="#carousel-323560" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a> <a class="right carousel-control" href="#carousel-323560" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
            </div>
          </div>
      </div>

      <div class="row clearfix well-lg">
          <div class="col-md-4 " style="margin-top:-22px;" >
              <div id='cssmenu'>
                   <ul>
                    <li class="heading"><a><strong>Brands</strong></a></li>
                     <ul class="custom-ul">
                     <?php
                        $sq1="Select * from brand;";
                        $q1=mysqli_query($connect,$sq1) or die ("Error in Mysqli: ".mysqli_error($connect));
                        while ($rs1=mysqli_fetch_array($q1)){
                          $id=$rs1['brandID'];
                          $name=$rs1['brandName'];
                       ?>
                         <li><a href="brands.php?id=<?php echo $id; ?>" ><?php echo $name; ?></a></li><br />
                      <?php
                        }
                     ?>
                      
                     </ul>    
                   </ul>
              	
              </div>
              <?php include('include/side_news_&_events.php'); ?>
          </div>

          <div class="col-md-8 column well">
                   <h2>Voice of Chairman </h2>
                  <div class="media ">
                         <a href="#" class="pull-left"><img src="img/ceo.jpg" height="140"  class="media-object " alt=""></a>
                        <div class="media-body">
                            <p>
                                Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. 
                                Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Cras sit amet nibh libero, in gravida nulla. 
                                Nulla vel metus scelerisque ante sollicitudin commodo. <br />
                                 <a class="btn btn-danger" href="#">Read more</a> 
                            </p>
                        </div>

                  </div>
                   
          </div> 
           <div class="col-md-8 column well">
               <h3>Products</h3> 
              <div class="row">
             <?php
                  $sql2="select * from product where productStatus='New' limit 3;";
                  $result2=mysqli_query($connect,$sql2) or die("Error in Mysql :".mysqli_error($connect));
                  while($row2=mysqli_fetch_array($result2)){
                    $proName=$row2['productName'];
                    $proPrice=$row2['productPrice'];
                    $proImage=$row2['productImagePath'];
                    $pId=$row2['productID'];
              ?>
                  <div class="col-md-4"  style="padding:8px;">
                             <div style="border:1px solid #cec8c8; padding:20px;" align="center">
                                <img src="<?php echo $proImage; ?>" alt="<?php echo $proName; ?>" class="img-thumbnail custom-image">
                                <div class="caption" align="center">
                                              <h3>
                                                  <?php echo $proName; ?>
                                              </h3>
                                              
                                                 <strong><?php echo "Price: ".$proPrice; ?></strong> <br /><br />
                                              
                                              <div ><a class="btn btn-primary" href="<?php echo "product_details.php?iddetail=".$pId;?>">See more</a> </div>
                                </div>
                             </div>
                         </div> 
                  <?php
                }
                ?>
                  <a href="products_status.php" class="btn btn-danger" style="float:right;">See More</a>
                </div>
           </div>         
          
        
      </div>
  </div>
  
<?php include('include/footer.php') ?>

</body>
</html>

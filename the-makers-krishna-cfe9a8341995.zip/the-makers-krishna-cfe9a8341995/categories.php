<?php
include('cms_admin/connect1.php');
$cat=$_GET['category'];
$type=$_GET['type'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Categories - Krishna International</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="container">			
	<div class="row">
		<div class="col-lg-2">
			<?php
				include('include/sidebar.php');
			?>
		</div>
		<div class="col-lg-10">
			<div class="custom-wells">	
				<?php
					$s1="Select * from category where categoryID='$cat';";
					$qr1=mysqli_query($connect,$s1) or die("Error in Mysqli: ".mysqli_error($connect));
					$rs1=mysqli_fetch_array($qr1);
					$catName1=$rs1['categoryName'];
					$catDesc1=$rs1['categoryDesc'];
					$catImg1=$rs1['categoryImagePath'];
				?>
				<h3><?php echo $catName1;?></h3>
				<ul class="media-list">						
					<li class="media">
						<img src="<?php echo $catImg1;?>" class="pull-left img-thumbnail custom-image" alt="<?php echo $catName1;?>">
						<div class="media-body">
							<p align="justify"><?php echo $catDesc1;?></p>
						</div>
					</li>
				</ul>
				<div class="well">
					<h3>Sub-Category</h3>
					<div class="row" align="center">
				<?php
					$s2="Select * from subcategory where categoryID='$cat';";
					$qr2=mysqli_query($connect,$s2) or die("Error in Mysqli: ".mysqli_error($connect));
					while ($rs2=mysqli_fetch_array($qr2)){
						$subCatName=$rs2['subcategoryName'];
						$subCatDesc=$rs2['subcategoryDesc'];
						$subCatImg=$rs2['subcategoryImagePath'];
						$subCatID=$rs2['subcategoryID'];

						$s3="Select * from product where subcategoryID='$subCatID' and productType='$type';";
						$qr3=mysqli_query($connect,$s3) or die("Error in Mysqli ".mysqli_error($connect));
						if(mysqli_num_rows($qr3)>0){
				?>

						<div class="col-md-3">
							<div class="cat-container" style="margin-bottom: 8px;">
								<a href="products.php?subcategory=<?php echo $subCatID;?> & type=<?php echo $type;?>"><img src="<?php echo $subCatImg; ?>" class="img-thumbnail custom-image" style="margin-top:-60px;"></a>
								<h4><?php echo $subCatName;?></h4>
							</div>														
						</div>
				<?php
						}
					}
				?>
					</div>					
				</div>
			</div>
		</div>
	</div>
</div>

	<?php include('include/footer.php');?>	
</body>
</html>
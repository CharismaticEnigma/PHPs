<?php
include("cms_admin/connect1.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Products - Krishna International</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="container">		
	<div class="row">
		<div class="col-lg-2">
			<?php
				include('include/sidebar.php');
			?>
		</div>		
		<div class="col-lg-10">
			<div class="custom-wells">
			<?php 
			$detailid=$_GET['iddetail'];
			$sql1="select * from product where productID='$detailid';";
			$result1=mysqli_query($connect,$sql1) or die("Error in Myslq : line 32".mysqli_error($connect));
			while($row1=mysqli_fetch_array($result1))
				{
					$name=$row1['productName'];
					$scid=$row1['subcategoryID'];
					$desc=$row1['productDesc'];
					$imagepath=$row1['productImagePath'];
					$productcatalink=$row1['productCatalogLink'];
				}

				//getting category details
				$sql3="select * from subcategory where subcategoryID='$scid';";
				$result3=mysqli_query($connect,$sql3) or die("Error in Myslq : line 39".mysqli_error($connect));
				$row3=mysqli_fetch_array($result3);
				$subcatename=$row3['subcategoryName'];
				$categoryID=$row3['categoryID'];
				$sql4="Select * from category where categoryID='$categoryID';";
				$qr4=mysqli_query($connect,$sql4) or die("Error in Mysqli: ".mysqli_error($connect));
				$rs4=mysqli_fetch_array($qr4);
				$catName=$rs4['categoryName'];
			?>
				<h3><?php echo $name; ?></h3>
				<div class="row">				
					<div class="col-md-6">
						<img src="<?php echo $imagepath; ?>" alt="<?php echo $name; ?>" class="pro-details img-thumbnail" style="margin-bottom:8px;" rel="zoom">
						
						<table class="table table-bordered table-hover">
							<tr>
								<td><strong>Category</strong></td>
								<td><?php echo $catName; ?></td>								
							</tr>
							<tr>
								<td><strong>Sub-Category</strong></td>
								<td><?php echo $subcatename; ?></td>
							</tr>													
						</table>
						<a href="<?php echo $productcatalink; ?>" class="btn btn-warning" style="float:right;"><i class="fa fa-file-pdf-o" style="font-size:25px;"></i> Download PDF</a>
					</div>
					<div class="col-md-6">
						<h4 style="color:#005E40; margin-top:-3px;"><?php echo $name; ?></h4>										
						<h4>Overview</h4>
						<p align="justify"><?php echo $desc; ?></p>												
					</div>						
				</div>
			</div>					
		</div>		
	</div>
</div>

	<?php include('include/footer.php');?>	
</body>
</html>
<?php
include('cms_admin/connect1.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>FAQ - Krishna International</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
    include('include/header.php');  
?>
<div class="container">
    <div class="custom-wells">
        <h3>Frequently Asked Questions</h3>
        <div class="panel-group" id="accordion">
        <?php
            $tag="inc";
            $inc=0;
            $s1="Select * from faq;";
            $qr1=mysqli_query($connect,$s1) or die ("Error in Mysqli: ".mysqli_error($connect));
            while($rs1=mysqli_fetch_array($qr1)){
                $inc++;
                $qn=$rs1['faqQn'];
                $ans=$rs1['faqAns'];
                $href ="$tag$inc";
        ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="<?php echo "#$href";?>">
                            <?php echo $qn; ?>
                        </a>
                    </h4>
                </div>
                <div id="<?php echo $href;?>" class="panel-collapse collapse">
                    <div class="panel-body">
                        <?php echo $ans;?>
                    </div>
                </div>
            </div>
        <?php

            }
        ?>
            
        </div>
    </div>      
</div>
    <?php include('include/footer.php');?>  
</body>
</html>
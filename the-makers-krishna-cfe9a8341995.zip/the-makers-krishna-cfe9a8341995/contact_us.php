<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Contact Us - Krishna International</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="container">
	<div class="custom-wells">
	<h3>Contact Us</h3>
	<p align="justify">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	<hr>
	<div class="row">
		<div class="col-md-6">
			<div class="well">
				<h4>Bagmati Enterprises</h4>
				<p align="justify"><span class="glyphicon glyphicon-map-marker"></span> <strong>Address:</strong> Nepalgunj, Surkhet road, ward no. 3 (Head Office)</p>
				<p align="justify">Dhapakhel, VDC ward no. 1. Udhyogmarg</p>
				<p align="justify"><span class="glyphicon glyphicon-phone-alt"></span> <strong>Phone:</strong> 123456</p>
				<p align="justify"><span class="glyphicon glyphicon-pencil"></span> <strong>Email:</strong> @.com</p>				
				<form name="form" action="include/mail.php" method="post">
					<div class="responsive-table">
						<table class="table">
							<tr>
								<td><p>Name</p></td>
								<td><input type="text" name="name" id="name" style="width:100%;" required></td>
							</tr>
							<tr>
								<td><p>E-mail</td>								
								<td><input type="email" name="email" id="email" style="width:100%;" required></td>
							</tr>
							<tr>
								<td><p>Subject</p></td>
								<td><input type="text" name="subject" id="subject" style="width:100%;" required></td>
							</tr>
							<tr class="antispam">
								<td><p>URL</p></td>
								<td><input type="text" name="url" id="url" style="width:100%;" placeholder="Do not enter anything here!!!"></td>
							</tr>
							<tr>
								<td><p>Your Message</p></td>
								<td><textarea name="message" id="message" cols="45" rows="5" style="width:100%;" required></textarea></td>
							</tr>
							<tr>
								<td></td>
								<td align="center"><input class="btn btn-success" type="submit" name="submit" id="submit" value="Send" style="font-size:22px;"></td>
							</tr>
						</table>
					</div>
				</form>
			</div>
		</div>
		<div class="col-md-6">
			<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script><div style="overflow:hidden;height:500px;width:100%;"><div id="gmap_canvas" style="height:500px;width:100%;"></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style><a class="google-map-code" href="http://wordpress-themes.org" id="get-map-data">wordpress-themes.org</a></div><script type="text/javascript"> function init_map(){var myOptions = {zoom:16,center:new google.maps.LatLng(27.643654,85.334264 ),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(27.643654, 85.334264 )});infowindow = new google.maps.InfoWindow({content:"<b>Krishna International</b><br/>Hattiban<br/> Lalitpur" });google.maps.event.addListener(marker, "click", function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>
		</div>
	</div>
	</div>
</div>

	<?php include('include/footer.php');?>	
</body>
</html>
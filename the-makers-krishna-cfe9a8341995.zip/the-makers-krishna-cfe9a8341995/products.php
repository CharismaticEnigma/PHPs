<?php
include("cms_admin/connect1.php");
$count1=0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Products - Krishna International</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="container">			
		<div class="row">
			<div class="col-lg-2">
				<?php
					include('include/sidebar.php');
					
				?>
			</div>
			<div class="col-lg-10">
				<div class="custom-wells">
					<h3>Our Products</h3>
					<div class="row">
					<?php
					if(isset($_GET['subcategory']) && isset($_GET['type'])){
						$subcategory=$_GET['subcategory'];
						$type=$_GET['type'];

						$sqlc1="select * from product where subcategoryID='$subcategory' and productType='$type';";
						$resultc1=mysqli_query($connect,$sqlc1) or die("Error in Mysql :".mysqli_error($connect));
						$count1=mysqli_num_rows($resultc1);

						$sql1="select * from product where subcategoryID='$subcategory' and productType='$type' limit 18;";
						$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));

						?>

						<script>
					function showUser(str)
					{
					if (str=="")
					  {
					  document.getElementById("txtHint2").innerHTML="";
					  return;
					  } 
					if (window.XMLHttpRequest)
					  {// code for IE7+, Firefox, Chrome, Opera, Safari
					  xmlhttp=new XMLHttpRequest();
					  }
					else
					  {// code for IE6, IE5
					  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
					  }
					xmlhttp.onreadystatechange=function()
					  {
					  if (xmlhttp.readyState==4 && xmlhttp.status==200)
						{
						document.getElementById("txtHint2").innerHTML=xmlhttp.responseText;
						}
					  }
					xmlhttp.open("GET","product_get.php?q2=<?php echo $subcategory; ?>&type=<?php echo $type; ?> &q3="+str,true);
					xmlhttp.send();
					}
			</script> 
					<br>
 					<span id="txtHint2">
 					<?php

						//begin while loop
						while ($row1=mysqli_fetch_array($result1)) {
							$productid=$row1['productID'];
							$productname=$row1['productName'];
							$productimg=$row1['productImagePath'];
							?>
							<div class="col-lg-3" style="padding:10px;">
								<div class="hover-over" align="middle">
									<img src="<?php echo $productimg; ?>" alt="product-name" class="img-thumbnail custom-image">
									<div style="height:60px; overflow:hidden;">
										<strong><p><?php echo $productname; ?></p></strong>
									</div>									
									<a href="<?php echo "product_details.php?iddetail=".$productid;?>"><p class="btn btn-danger">Learn More</p></a>
								</div>
							</div>
							<?php
						}
						//end of while loop
						?>
						</span>
						<?php
					}
					
					?>
						
					</div>

					<div class="row">
				
					<?php
					//pageination button
					$pagenum=$count1/18;
					if($count1%18!=0){
						$pagenum++;
					}
					// check if page in greater than 1 or not if is greater display pageno text else don't
					if($pagenum>=2){
					?>
						<ul class="pagination pagination-lg">Page no.
					<?php
					}
					for ($i=1; $i<=$pagenum; $i++)
					{
						if($pagenum>=2){ // check if page in greater than 1 or not if is greater display pageno button else don't

					?>					
					<li><button value="<?php echo $i; ?> " onclick="showUser(this.value)" style="width:40px; height:30px; font-size:16px; margin:1px;"> <?php echo $i; ?> </button></li>
					<?php
					}
				
				 }
				?>
						
					</ul>
				</div>

				</div>					
			</div>
		</div>
</div>

	<?php include('include/footer.php');?>	
</body>
</html>
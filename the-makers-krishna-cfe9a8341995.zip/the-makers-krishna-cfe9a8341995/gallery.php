<?php
include('cms_admin/connect1.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Gallery - Krishna International</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="container">
	<div class="custom-wells">
		<h3>Gallery</h3>
		<div class="row">
			<?php
				$s1="Select * from galleryimage;";
				$qr1=mysqli_query($connect,$s1) or die ("Errory in Mysqli: ".mysqli_error($connect));
				while($rs1=mysqli_fetch_array($qr1)){
					$img1=$rs1['galleryimageImagePath'];
					$imgNm1=$rs1['galleryimageName'];
			?>
			<div class="col-md-3 col-xs-6" style="text-align:center;">
				<a class="group1" href="<?php echo $img1;?>" title="<?php echo $imgNm1;?>" alt="<?php echo $imgNm1;?>">
					<img src="<?php echo $img1;?>" class="img-thumbnail custom-image">
				</a>
				<p><?php echo $imgNm1;?></p>
			</div>
			<?php
				}
			?>
		</div>
	</div>		
</div>

	<?php include('include/footer.php');?>	
</body>
</html>
<?php
include("cms_admin/connect1.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Events - Krishna International</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="container">
	<div class="custom-wells">
		<h3>News & Events</h3>
		<?php
		$sql1="select * from event;";
		$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
		while ($row1=mysqli_fetch_array($result1)) {
			$ename=$row1['eventName'];
			$edesc=$row1['eventDesc'];
			$eimg=$row1['eventImagePath'];

			//check if event Image is null
			if ($eimg!="images/event") {
				?>
				<div class="repeat">
					<h4><?php echo $ename;?></h4>
					<ul class="media-list">						
						<li class="media">
							<img src="<?php echo $eimg;?>" class="pull-left img-thumbnail custom-image zoom" alt="<?php echo $ename;?>" rel="zoom">
							<div class="media-body">
								<p align="justify">
									<?php echo $edesc;?>
								</p>
							</div>
						</li>
					</ul>
				</div>
				<?php
			}
			else{
				?>
				<div class="repeat">
					<h4><?php echo $ename;?></h4>
					<ul class="media-list">						
						<li class="media">
							<img src="images/event/default.png" class="pull-left img-thumbnail custom-image zoom" alt="<?php echo $ename;?>" rel="zoom">
							<div class="media-body">
								<p align="justify">
									<?php echo $edesc;?>
								</p>
							</div>
						</li>
					</ul>
				</div>
				<?php
			}
		}
	//end of loop
		?>

	</div>			
</div>

	<?php include('include/footer.php');?>	
</body>
</html>
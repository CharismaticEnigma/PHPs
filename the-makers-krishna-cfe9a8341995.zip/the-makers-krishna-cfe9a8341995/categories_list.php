<?php
$type=$_GET['type'];
include('cms_admin/connect1.php');
$checkCatID="no";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title><?php echo $type;?> - Krishna International</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="container">			
	<div class="row">
		<div class="col-lg-2">
			<?php
				include('include/sidebar.php');
			?>
		</div>
		<div class="col-lg-10">
			<div class="custom-wells">	
				<h2>Categories for: <?php echo $type;?></h2>
				<?php
					$s1="select distinct subcategoryID from product where productType='$type';";
					$qr1=mysqli_query($connect,$s1) or die ("Error in Mysqli: ".mysqli_error($connect));
					while ($rs1=mysqli_fetch_array($qr1)){
						$subCatID=$rs1['subcategoryID'];
						$s2="Select categoryID from subcategory where subcategoryID='$subCatID';";
						$qr2=mysqli_query($connect,$s2) or die("Error in Mysqli: ".mysqli_error($connect));
						while($rs2=mysqli_fetch_array($qr2)){
							$catID=$rs2['categoryID'];
							$s3="Select * from category where categoryID='$catID';";
							$qr3=mysqli_query($connect,$s3) or die ("Error in Mysqli: ".mysqli_error($connect));
							while($rs3=mysqli_fetch_array($qr3)){
								$catName=$rs3['categoryName'];
								$catDesc=$rs3['categoryDesc'];
								$catImg=$rs3['categoryImagePath'];
								$catID=$rs3['categoryID'];
								if($checkCatID!=$catID){
									$checkCatID=$catID;
									
				?>

				<h3><?php echo $catName;?></h3>
				<ul class="media-list">						
					<li class="media">
						<img src="<?php echo $catImg;?>" class="pull-left img-thumbnail custom-image" alt="<?php echo $catName;?>">
						<div class="media-body">
							<p align="justify"><?php echo $catDesc;?></p>
						</div>
						<a href="categories.php?category=<?php echo $catID;?> & type=<?php echo $type;?>" class="btn btn-info" style="margin:12px; float:right;">See More</a>
					</li>
				</ul>
				<?php	
								}
							}
						}
					}
				?>
				
			</div>
		</div>
	</div>
</div>

	<?php include('include/footer.php');?>	
</body>
</html>
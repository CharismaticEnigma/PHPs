	<?php
	include("connect.php");

	$imgID=$_GET['dele'];

		if(isset($imgID)){
			$sql1="Select * from event where eventID='$imgID';";
			$res=mysqli_query($connect, $sql1);
			while($row1 = mysqli_fetch_array($res))
			{
 				$imgs=$row1['eventImagePath'];
 				//check if image is null
 				if($imgs!="images/event")
 				{
	 				$arr=array();
	 				$arr= (explode ("/",$imgs));
	 				chdir("../images/event");
	 				unlink($arr[2]);
 				}
 				
 			}
		
			$sql= "delete from event where eventID='$imgID';";
			mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
			header('location:event_edit_delete.php');
		
		}

		?>
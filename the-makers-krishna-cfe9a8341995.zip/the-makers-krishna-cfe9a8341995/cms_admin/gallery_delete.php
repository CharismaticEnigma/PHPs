	<?php
	include("connect.php");
		/*if(!isset($_SESSION['Login_Name'])){
		header("Location:index.php");
		exit();
	} 

else{ */
	$imgID=$_GET['id'];

		if(isset($imgID)){
			$sql1="Select * from galleryimage where galleryimageID='$imgID';";
			$res=mysqli_query($connect,$sql1);
			while($row1 = mysqli_fetch_array($res))
			{
 				 $imgs=$row1['galleryimageImagePath'];
 				 $arr=array();
 				 $arr= (explode ("/",$imgs));
 				 chdir("../images/gallery");
 				 unlink($arr[2]);
 			}
		
			$sql= "delete from galleryimage where galleryimageID='$imgID';";
		
		mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
		
		header('location:gallery_image_delete.php');
		
		}
		//}
		?>
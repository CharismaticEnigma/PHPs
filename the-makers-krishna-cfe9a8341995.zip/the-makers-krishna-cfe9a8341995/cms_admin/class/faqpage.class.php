<?php
class Faqpage
{
	function insertFaq(){
		include("connect1.php");	
		$qn=$_POST['qn'];		
		$ans=$_POST['ans'];

		$sql= "insert into faq (faqQn,faqAns) values ('$qn','$ans');";
		mysqli_query($connect, $sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error());
		echo "data sucessfully added";
	}

	function editFaq(){
		$id=$_POST['id'];
		$qn=$_POST['qn'];
		$ans=$_POST['ans'];

		include("connect1.php");

		if(isset($qn) && $ans !=Null){
			$sqlup=mysqli_query($connect, "Update faq Set faqQn='$qn' where faqID='$id'");	
		}
		if(isset($ans)&& $ans !=Null){
			$sqlup=mysqli_query($connect, "Update faq Set faqAns='$ans' where faqID='$id'");	
		}
		
	}
	function deleteFaq(){
		$id=$_POST['id'];
		include("connect1.php");
		$sql="delete from faq where faqID='$id';";
		mysqli_query($connect,$sql) or die("Error in Mysqli <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp; ". mysqli_error($connect));
		echo "Record deleted";

	}

}
$Faqpage = new Faqpage();
?>
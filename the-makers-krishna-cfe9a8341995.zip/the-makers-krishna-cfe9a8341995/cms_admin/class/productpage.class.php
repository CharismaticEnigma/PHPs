<?php

class Productpage
{
	//public $ext,$extsof,$extcata, $destsof, $dest, $destcata;
	function insertProduct(){
	
		$name=$_POST['productname'];		
		$ptype=$_POST['producttype'];
		$scid=$_POST['subcategoryid'];
		$desc=$_POST['productdesc'];
		$pstatus=$_POST['productstatus'];
		
		$boolimg="false";
		$boolsof="false";
		$boolcata="false";
		
		$ext="";
		$extsof="";
		$extcata="";

		$dest = "../images/product";
		$destcata = "../images/product/catalog";		

		//the php script to upload the image
		$imagename = $_FILES["newsimg"]["name"];
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		$catalink=$_FILES["cataloglink"]["name"];
		$tmpcatalink=$_FILES["cataloglink"]["tmp_name"];

		//path to put into the database table
		$path = "images/product/$imagename";
		$pathcata = "images/product/catalog/$catalink";
		
		//actual server destination folder
		
		
		//check whether the extention is correct
		if($imagename!="" || $imagename!=null){
			$dest = "../images/product/$imagename";
			$arr = explode(".",$imagename);
			$ext = $arr[1];
		}

		if($catalink!="" || $catalink!=null){
			$destcata = "../images/product/catalog/$catalink";		
			$arrcata= explode(".",$catalink);
			$extcata= $arrcata[1];	
		}
		
		
			if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG'))
			{
				if(file_exists($dest)){
					echo "an image with that name already exists.. Please change your file";
					$boolimg="exist";
				}
				else{
					$boolimg="true";
				}
			}
			elseif ($ext==""){
				$path="null";
			}
			else{
				echo "Invalid photo type";
			}

			if(($extcata=='pdf') or ($extcata=='doc') or ($extcata=='docx') or ($extcata=='txt'))
			{
				if(file_exists($destcata)){
						echo "a catalog with that name already exists.. Please change your file";
						$boolcata="exist";

				}
				else{
					$boolcata="true";
				}

			}
			elseif($extcata==""){
				$pathcata="null";
			}
			else{
				echo "Invalid pdf type";
			}

			if($boolimg!="exist" && $boolcata!="exist"){
				//copy the temporarily uploaded file to the server destination (actual upload)
				if($boolimg=="true"){
					copy($tmpimage,$dest);
				}
				if($boolcata=="true"){
				//copy($catalink,$destcata);					
					copy($tmpcatalink,$destcata);
				}

				
				//@rename($dest,"../studpics/$id.$ext");
				include("connect1.php");

					$sql= "insert into product (productType,productName,subcategoryID,productDesc,productImagePath,productStatus,productCatalogLink) values ('$ptype','$name',$scid,'$desc','$path','$pstatus','$pathcata');";
					mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));


			}				
					




					
						
		
		
	}


	function editProduct(){
		include("connect1.php");
		$type=$_POST['type'];
		$name=$_POST['nm'];
		$subcategory=$_POST['sub'];
		$status=$_POST['status'];
		$desc=$_POST['desc'];
		$pid=$_POST['pid'];
		$scid=$_POST['scid'];

		//fetching imagepath, software link and catalog
		$imgLoc=$_POST['imagepath'];
		$catLoc=$_POST['catalogLink1'];


		if($type !="-- Select --" && $type !=Null){			
			$sqlup=mysqli_query($connect,"Update product Set productType='$type' where productID='$pid'");	
		}

		if(isset($name) && $name !=Null){
			$sqlup=mysqli_query($connect,"Update product Set productName='$name' where productID='$pid'");	
		}
		

		if(isset($desc)&& $desc !=Null){
			$sqlup=mysqli_query($connect,"Update product Set productDesc='$desc' where productID='$pid'");	
		}
		

		if($status !="-- Select --" && $status !=Null){			
			$sqlup=mysqli_query($connect,"Update product Set productStatus='$status' where productID='$pid'");	
		}

		if ($subcategory!="-- Select --" && $subcategory !=Null){
			$sqlup=mysqli_query($connect,"Update product Set subcategoryID='$subcategory' where productID='$pid'");
			
		}

		
	//end of image edit
		$boolimg="false";
		$boolcata="false";

		$ext="";
		$extsof="";
		$extcata="";

		$dest = "../images/product";
		$destcata = "../images/product/catalog";		

		//the php script to upload the image
		$imagename = $_FILES["newsimg"]["name"];
		$tmpimage = $_FILES["newsimg"]["tmp_name"];


		$catalink=$_FILES["cataloglink"]["name"];
		$tmpcatalink=$_FILES["cataloglink"]["tmp_name"];

		//path to put into the database table
		$path = "images/product/$imagename";
		$pathcata = "images/product/catalog/$catalink";
		
		//actual server destination folder
		
		
		//check whether the extention is correct
		if($imagename!="" || $imagename!=null){
			$dest = "../images/product/$imagename";
			$arr = explode(".",$imagename);
			$ext = $arr[1];
		}
			

		if($catalink!="" || $catalink!=null){
			$destcata = "../images/product/catalog/$catalink";		
			$arrcata= explode(".",$catalink);
			$extcata= $arrcata[1];	
		}
		
		
			if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG'))
			{
				if(file_exists($dest)){
					echo "an image with that name already exists.. Please change your file";
					$boolimg="exist";
				}
				else{
					$boolimg="true";
				}
			}
			elseif ($ext==""){
				$path="null";
			}
			else{
				echo "Invalid photo type";
			}

			
			if(($extcata=='pdf') or ($extcata=='doc') or ($extcata=='docx') or ($extcata=='txt'))
			{
				if(file_exists($destcata)){
						echo "a catalog with that name already exists.. Please change your file";
						$boolcata="exist";

				}
				else{
					$boolcata="true";
				}

			}
			elseif($extcata==""){
				$pathcata="null";
			}
			else{
				echo "Invalid pdf type";
			}

			include("connect1.php");


			if($boolimg!="exist" && $boolcata!="exist"){
				//copy the temporarily uploaded file to the server destination (actual upload)
				if($boolimg=="true"){
					if($imgLoc!="null")
					{
						$imgarr=array();
						$imgarr=explode("/", $imgLoc);
						$cdr=getcwd();
				 		chdir("../images/product");
				 		unlink($imgarr[2]);
				 		chdir($cdr);
					}
			 		copy($tmpimage,$dest);
					$sqlup=mysqli_query($connect,"Update product Set productImagePath='$path' where productID='$pid'");
				}
			
				if($boolcata=="true"){
				//copy($catalink,$destcata);
					if($catLoc!="null"){
						$catarr=array();
						$catarr=explode("/", $catLoc);
						$cdr=getcwd();
				 		chdir("../images/product/catalog");
				 		unlink($catarr[3]);
				 		chdir($cdr);
			 		}
			 		copy($tmpcatalink,$destcata);
					$sqlup1=mysqli_query($connect,"Update product Set productCatalogLink='$pathcata' where productID='$pid'");					
					//copy($tmpcatalink,$destcata);
				}

			}		

		
		
		
	}

	function deleteProduct(){
		include("connect1.php");
		 $pid=$_POST['pid'];
		
		 $path=$_POST['imagepath'];
		$catLoc=$_POST['catalogLink1'];
		if($path!="null")
					{
						$imgarr=array();
						$imgarr=explode("/", $path);
						$cdr=getcwd();
				 		chdir("../images/product");
				 		unlink($imgarr[2]);
				 		chdir($cdr);
					}
			if($catLoc!="null"){
						$catarr=array();
						$catarr=explode("/", $catLoc);
						$cdr=getcwd();
				 		chdir("../images/product/catalog");
				 		unlink($catarr[3]);
				 		chdir($cdr);
			 		} 	 	

		 	$s2="Delete from product where productID='$pid';";
		 	mysqli_query($connect,$s2) or die("Error in mysql: ".mysqli_error($connect));
		 	echo "Product Deleted";
		 	header('location:edit_delete_product.php');



		 }	
	}
$Productpage= new Productpage();
?>
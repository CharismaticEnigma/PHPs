<?php
class Servicepage
{
	function insertService(){
		include("connect1.php");	
		$name=$_POST['nm'];		
		$desc=$_POST['desc'];
		$sql1="Insert into service(serviceName,serviceDesc) values('$name','$desc');";
		$qr1=mysqli_query($connect,$sql1) or die ("Error in Mysqli: ".mysqli_error($connect));
		echo "Data successfully added";
									
	}

	function editService(){

		$id=$_POST['id'];
		$nm=$_POST['nm'];
		$desc=$_POST['desc'];

		include("connect1.php");

		if(isset($nm) && $nm !=Null){
			$sqlup=mysqli_query($connect, "Update service Set serviceName='$nm' where serviceID='$id'");	
		}
		if(isset($desc)&& $desc !=Null){
			$sqlup=mysqli_query($connect, "Update service Set serviceDesc='$desc' where serviceID='$id'");	
		}
	}	

}
$Servicepage = new Servicepage();
?>
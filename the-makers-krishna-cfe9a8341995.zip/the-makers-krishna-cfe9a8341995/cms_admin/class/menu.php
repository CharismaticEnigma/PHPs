   <?php
   ?>
   <div id="menu">
        <ul>
       					
			<li class="first"><a href="#">Category</a>
                <ul>
                    <li class="top"><a href="add_category.php"> Add Category</a></li>
					<li class="top"><a href="edit_delete_category.php"> Edit/Delete Category</a></li>
                    <li class="top"><a href="add_subCategory.php"> Add Sub Category</a></li>
					<li class="top"><a href="edit_delete_subCategory.php"> Edit/Delete Sub Category</a></li>
                    </ul>
            </li>
            <li class="first"><a href="#">Event</a>
                <ul>
                    <li class="top"><a href="event_add.php"> Add Event</a></li>
                    <li class="top"><a href="event_edit_delete.php"> Edit/Delete Event</a></li>
                    
                    </ul>
            </li>
			<li class="first"><a href="#">Slider/Gallery Image</a>
                <ul>
                    <li class="top"><a href="add_slider1.php"> Add Image for Big Slider</a></li>
					<li class="top"><a href="edit_delete_slider1.php"> Delete Image for Big Slider</a></li>
                     <li class="top"><a href="gallery_image_add.php"> Add Image for Gallery</a></li>
                    <li class="top"><a href="gallery_image_delete.php"> Delete Image for Gallery</a></li>
                    </ul>
            </li>
            <li class="first"><a href="#">Product</a>
                <ul>
                    <li class="top"><a href="add_product.php"> Add New Product</a></li>
                    <li class="top"><a href="edit_delete_product.php"> Edit/Delete Product With Category</a></li>
                    </ul>
            </li>
            <li class="first"><a href="#">About</a>
                <ul>
                    <li class="top"><a href="add_about.php"> Add About us Article</a></li>
                    <li class="top"><a href="edit_delete_about.php"> Edit/Delete About us Article</a></li>
                    <li class="top"><a href="add_sistercompany.php"> Add about Sister company</a></li>
                    <li><a href="edit_delete_sistercompany.php">Edit/Delete Sister company</a></li> 
                    </ul>
            </li>
            <li class="first"><a href="#">Service</a>
                <ul>
                    <li class="top"><a href="add_service.php"> Add new Serevice</a></li>
                    <li class="top"><a href="edit_delete_service.php"> Edit/Delete Service</a></li>
                    </ul>
            </li>


            <li class="first"><a href="#">FAQs</a>
                <ul>
                    <li class="top"><a href="add_faq.php"> Add New FAQs</a></li>
                    <li class="top"><a href="edit_delete_faq.php"> Edit/Delete FAQs</a></li>
                    </ul>
            </li>
             <li class="first"><a href="welcome_edit.php">Edit Welcome</a>
             </li>
			
			           
           </ul>
    </div>
<?php
	include("connect1.php");
	/*if(!isset($_SESSION['Login_Name'])){
		header("Location:index.php");
		exit();
	}
	else{ */
	$a = $_GET['dele'];
	if(isset($a)){
		$sql1="Select * from about where aboutID='$a';";
		$res=mysqli_query($connect, $sql1);
		while($row1 = mysqli_fetch_array($res))
			{
 				$imgs=$row1['aboutImagePath'];
 				if ($imgs!=Null) {
	 				$arr=array();
	 				$arr= (explode ("/",$imgs));
	 				chdir("../images/about/sisterarticle");
	 				unlink($arr[3]);
 				}	
 				$sql2="delete from about where aboutID='$a';";
	   			$res2=mysqli_query($connect, $sql2) or die ("error in mysql :".mysqli_error($connect));
				header('location:edit_delete_sistercompany.php');
 			}
		
	}
?>
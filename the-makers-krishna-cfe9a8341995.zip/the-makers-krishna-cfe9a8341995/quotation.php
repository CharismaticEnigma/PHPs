<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Quotation Request - Krishna International</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="container">
	<div class="custom-wells">
		<h3>Request for quote</h3>
        <div class="row">
            <div class="col-md-6">
                <form name="quotation" action="include/quotation_form.php" method="post">
                    <div class="responsive-table">
                        <table class="table table-condensed">
                            <tr>
                                <td><p>Name</p></td>
                                <td><input type="text" name="name" id="name" style="width:100%;" autofocus required></td>
                            </tr>
                            <tr>
                                <td><p>Title</p></td>
                                <td><input type="text" name="title" id="title" style="width:100%;" required></td>
                            </tr>
                            <tr>
                                <td><p>Company</p></td>
                                <td><input type="text" name="company" id="company" style="width:100%;" required></td>
                            </tr>
                            <tr>
                                <td><p>Address</p></td>
                                <td><input type="text" name="address" id="address" style="width:100%;" required></td>
                            </tr>
                            <tr>
                                <td><p>City</p></td>
                                <td><input type="text" name="city" id="city" style="width:100%;" required></td>
                            </tr>
                            <tr>
                                <td><p>Country</p></td>
                                <td><input type="text" name="country" id="country" style="width:100%;" required></td>
                            </tr>
                            <tr>
                                <td><p>Telephone</p></td>
                                <td><input type="text" name="telephone" id="telephone" style="width:100%;" required></td>
                            </tr>
                            <tr>
                                <td><p>E-mail</td>                              
                                <td><input type="email" name="email" id="email" style="width:100%;" required></td>
                            </tr>
                            <tr>
                                <td><p>Website</p></td>
                                <td><input type="text" name="website" id="website" style="width:100%;" required></td>
                            </tr>
                            <tr class="antispam">
                                <td><p>URL</p></td>
                                <td><input type="text" name="url" id="url" style="width:100%;" placeholder="Do not enter anything here!!!"></td>
                            </tr>
                            <tr>
                                <td><p>Product Details</p></td>
                                <td><textarea name="message" id="message" cols="45" rows="5" style="width:100%;" required></textarea></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td align="center"><input class="btn btn-danger" type="submit" name="submit" id="submit" value="Submit Request"></td>
                            </tr>
                        </table>
                    </div>
                </form>
            </div>
        </div>        
	</div>		
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
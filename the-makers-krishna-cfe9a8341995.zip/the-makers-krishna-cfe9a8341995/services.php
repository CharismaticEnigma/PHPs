<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Services - Krishna International</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="container">
	<div class="custom-wells">
		<h3>Our Services</h3>
		<!-- Loop  -->
		<?php
		$sql1="select * from service;";
		    $result1=mysqli_query($connect,$sql1) or die("Error in Myslq : line 21".mysqli_error($connect));
		    while($row1=mysqli_fetch_array($result1)){
		        $servicename=$row1['aboutName'];
		        $servicedesc=$row1['aboutDesc'];
				?>		
		?>
		<h4><?php echo $servicename; ?></h4>
		<p align="justify">
			<?php echo $servicedesc; ?>
		</p>
		<?php
		}
		?>
		<!-- loop -->
	</div>		
</div>

	<?php include('include/footer.php');?>	
</body>
</html>
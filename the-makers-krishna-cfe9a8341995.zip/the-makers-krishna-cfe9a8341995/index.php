<?php
include("cms_admin/connect1.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Krishna International</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
	<div class="container">
		<div class="row">
			<div class="col-lg-8">
				<?php include('include/slider.php') ?>
			</div>
			<div class="col-lg-4">
				<div class="custom-wells">
				<?php
				$sql1="select * from welcome;";
				$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
				$row1=mysqli_fetch_array($result1);
				?>
					<h2><?php echo $row1['welcomeTitle'];?></h2>
					<p align="justify"><?php echo $row1['welcomeDesc'];?></p>
					<a href="contact_us.php" class="btn btn-primary">Contact info</a>					
				</div>
			</div>			
		</div>
	</div>	
	<div class="container">	
		<div class="custom-wells">
			<h3>New Products</h3>
			<div class="row">
			<?php
				$sql2="select * from product where productStatus='New' limit 8;";
				$result2=mysqli_query($connect,$sql2) or die("Error in Mysql :".mysqli_error($connect));
				while($row2=mysqli_fetch_array($result2)){
					$proname=$row2['productName'];
					$proimage=$row2['productImagePath'];
					$pid=$row2['productID'];
				?>
			
				<div class="col-lg-3" style="padding:10px;">
					<div class="hover-over" align="middle">
						<img src="<?php echo $proimage; ?>" alt="<?php echo $proname; ?>" class="img-thumbnail custom-image">
						<div style="height:40px; overflow:hidden; margin-bottom:3px;">
							<strong><p><?php echo $proname; ?></p></strong>						
						</div>						
						<a href="<?php echo "product_details.php?iddetail=".$pid;?>"><p class="btn btn-danger">Learn More</p></a>
					</div>
				</div>
				<?php
				}
				?>
				<a href="products_status.php" class="btn btn-primary" style="margin:12px; float:right;">See More</a>
			</div>
		</div>		
		
		<div class="row">				
			<div class="col-md-8" style="overflow:hidden;">
				<div class="custom-wells">
					<h3>Categories</h3>
					<?php include('include/our_categories.php'); ?>
				</div>
			</div>
			<div class="col-md-4">
				<div class="custom-wells">
					<h3>About Us</h3>
					<p align="justify">Krishna International</p>
					<a href="about_us.php" class="btn btn-primary">See More</a>
				</div>
			</div>
		</div>
	</div>
	
	<?php include('include/footer.php');?>	
</body>
</html>
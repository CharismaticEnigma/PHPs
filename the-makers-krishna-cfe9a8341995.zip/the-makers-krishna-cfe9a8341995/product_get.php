<?php
include("cms_admin/connect1.php");

										
					//pageination 
					if(isset($_GET['q2'])){
						$subcategory=$_GET['q2'];
						$pagenumber=$_GET['q3'];
						$type=$_GET['type'];
						

						if ($pagenumber==1){

							$sql1="select * from product where subcategoryID='$subcategory' and productType='$type' limit 18;";
							$result1=mysqli_query($connect,$sql1) or die("Error in Myslq :".mysqli_error($connect));

							while($row1=mysqli_fetch_array($result1))
							{
								$productid=$row1['productID'];
								$productname=$row1['productName'];
								$productimg=$row1['productImagePath'];
								?>
								<!-------------- Repeat -------------->
							<div class="col-lg-3" style="padding:10px;">
								<div class="hover-over" align="middle">
									<img src="<?php echo $productimg; ?>" alt="product-name" class="img-thumbnail custom-image">
									<div style="height:60px; overflow:hidden;">
										<strong><p><?php echo $productname; ?></p></strong>
									</div>									
									<a href="<?php echo "product_details.php?iddetail=".$productid;?>"><p class="btn btn-danger">Learn More</p></a>
								</div>
							</div>

							<!-------------- Repeat -------------->
								<?php
							}
						}

						else{
							//echo $pagenumber;
							$pagefirst=18*($pagenumber-1);
							$sql1="select * from product where subcategoryID='$subcategory' and productType='$type' limit $pagefirst,18;";
							$result1=mysqli_query($connect,$sql1) or die("Error in Myslq :".mysqli_error($connect));

							while($row1=mysqli_fetch_array($result1))
							{
								$productid=$row1['productID'];
								$productname=$row1['productName'];
								$productimg=$row1['productImagePath'];
								?>
								<!-------------- Repeat -------------->
								<div class="col-lg-3" style="padding:10px;">
									<div class="hover-over" align="middle">
										<img src="<?php echo $productimg; ?>" alt="product-name" class="img-thumbnail custom-image">
										<div style="height:60px; overflow:hidden;">
											<strong><p><?php echo $productname; ?></p></strong>
										</div>								
										<a href="<?php echo "product_details.php?iddetail=".$productid;?>"><p class="btn btn-danger">Learn More</p></a>
									</div>
								</div>
							<!-------------- Repeat -------------->
								<?php
							}

						}										

					}
					


					//pagination for new status
					if(isset($_GET['qnew'])){
						$pstatus=$_GET['qnew'];
						$pagenumber=$_GET['q3'];
						
						if ($pagenumber==1){

							$sql1="select * from product where productStatus='$pstatus' limit 18;";
							$result1=mysqli_query($connect,$sql1) or die("Error in Myslq :".mysqli_error($connect));

							while($row1=mysqli_fetch_array($result1))
							{
								$productname=$row1['productName'];
								$productimg=$row1['productImagePath'];
								?>
								<!-------------- Repeat -------------->
							<div class="col-lg-3" style="padding:10px;">
								<div class="hover-over" align="middle">
									<img src="<?php echo $productimg; ?>" alt="product-name" class="img-thumbnail custom-image">
									<div style="height:60px; overflow:hidden;">
										<strong><p><?php echo $productname; ?></p></strong>
									</div>									
									<a href="<?php echo "product_details.php?iddetail=".$productid;?>"><p class="btn btn-danger">Learn More</p></a>
								</div>
							</div>

							<!-------------- Repeat -------------->
								<?php
							}
						}

						else{
							//echo $pagenumber;
							$pagefirst=18*($pagenumber-1);
							$sql1="select * from product where productStatus='$pstatus' limit $pagefirst,18;";
							$result1=mysqli_query($connect,$sql1) or die("Error in Myslq : line 12".mysqli_error($connect));

							while($row1=mysqli_fetch_array($result1))
							{
								$productname=$row1['productName'];
								$image=$row1['productImagePath'];
								?>
								<!-------------- Repeat -------------->
							<div class="col-lg-3" style="padding:10px;">
								<div class="hover-over" align="middle">
									<img src="<?php echo $productimg; ?>" alt="product-name" class="img-thumbnail custom-image">
									<div style="height:60px; overflow:hidden;">
										<strong><p><?php echo $productname; ?></p></strong>
									</div>									
									<a href="<?php echo "product_details.php?iddetail=".$productid;?>"><p class="btn btn-danger">Learn More</p></a>
								</div>
							</div>


							<!-------------- Repeat -------------->
								<?php
							}

						}										

					}
				?>		
				
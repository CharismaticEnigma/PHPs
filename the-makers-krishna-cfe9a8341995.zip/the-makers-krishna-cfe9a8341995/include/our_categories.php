<!-- carousel CSS and Jquery -->
<link href="css/flexistyle.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/jquery.flexisel.js"></script>
<!------ carousel CSS and Jquery ------>
    <ul id="flexiselDemo3">
    <?php
    $sqlc1="select * from category;";
    $resultc1=mysqli_query($connect,$sqlc1) or die("Error in Mysql".mysqli_error($connect));
    while ($rowc1=mysqli_fetch_array($resultc1)) {
        $catename=$rowc1['categoryName'];
        $cateimg=$rowc1['categoryImagePath'];
        echo $cateimg;
        ?>
        <li><img src="<?php echo $cateimg ?>" alt="<?php echo $catename ?>" /><p><?php echo $catename ?></p></li>
    <?php
    }
    ?>                   
    </ul>   
<div class="clearout"></div>
<script type="text/javascript">

$(window).load(function() {
    $("#flexiselDemo1").flexisel();
    $("#flexiselDemo2").flexisel({
        enableResponsiveBreakpoints: true,
        responsiveBreakpoints: { 
            portrait: { 
                changePoint:480,
                visibleItems: 1
            }, 
            landscape: { 
                changePoint:640,
                visibleItems: 2
            },
            tablet: { 
                changePoint:768,
                visibleItems: 3
            }
        }
    });

    $("#flexiselDemo3").flexisel({
        visibleItems: 3,
        animationSpeed: 1000,
        autoPlay: true,
        autoPlaySpeed: 3000,            
        pauseOnHover: true,
        enableResponsiveBreakpoints: true,
        responsiveBreakpoints: { 
            portrait: { 
                changePoint:480,
                visibleItems: 1
            }, 
            landscape: { 
                changePoint:640,
                visibleItems: 2
            },
            tablet: { 
                changePoint:768,
                visibleItems: 3
            }
        }
    });

    $("#flexiselDemo4").flexisel({
        clone:false
    });
    
});
</script>
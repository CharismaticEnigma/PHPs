<?php

?>
<link href="css/responsive-slider.css" rel="stylesheet">     
<div class="custom-wells">
	<div class="responsive-slider" data-spy="responsive-slider" data-autoplay="true">
	    <div class="slides" data-group="slides">
	  		<ul>
	  		<?php
	          $sql1="select * from sliderimage;";
	          $result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysql_error($connect));
	          while($row1=mysqli_fetch_array($result1)){
	          	?>
		    	<li>
	          		<div class="slide-body" data-group="slide">
	            		<img src="<?php echo $row1['sliderimageImagePath'];?>" alt="name">
	          		</div>
		    	</li>
	    		<?php
		          }
	          	?>
		    </ul>
	    </div>
	    <a class="slider-control left" href="#" data-jump="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
	    <a class="slider-control right" href="#" data-jump="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
	    <div class="pages">
	      <a class="page" href="#" data-jump-to="1">1</a>
	      <a class="page" href="#" data-jump-to="2">2</a>
	      <a class="page" href="#" data-jump-to="3">3</a>
	    </div>
	</div>
</div>
<script src="js/slider/jquery.js"></script>
<script src="js/slider/jquery.event.move.js"></script>
<script src="js/slider/responsive-slider.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript" src="js/smoothzoom.js"></script>
<script type="text/javascript">
    $(window).load( function() {
        $('img').smoothZoom({
            // Options go here
        });
    });
</script>
<div class="content footer">
	<div class="container" style="border-bottom:1px dashed #5D5D5D">
		<div class="row" style="padding:8px;">
			<div class="col-md-4">
				<h3>About</h3>
				<?php
				$sq2="Select * from about;";
           		$qr2=mysqli_query($connect,$sq2) or die ("Error in Mysqli: ".mysqli_error($connect));
           		while($rs2=mysqli_fetch_array($qr2)){
                $title=str_replace(" ","",strtoLower($rs2['aboutName']));
                if($title=="aboutus" || $title=="aboutcompany" || $title=="aboutkrishnainternational" || $title=="aboutthecompany"){
                    $desc=$rs2['aboutDesc'];
                    $abDesc=substr($desc, 0,530)."......";        
                    ?>
				<p align="justify"><?php echo $abDesc?></p>
				  <?php
                }
            }
            //end of about
            ?>

			</div>
			<div class="col-md-3">
				<h3>Contact</h3>
				<p align="justify"><span class="glyphicon glyphicon-map-marker"></span> <strong>Address:</strong> Nepalgunj, Surkhet road, ward no. 3 (Head Office)</p>
				<p align="justify">Dhapakhel, VDC ward no. 1. Udhyogmarg</p>
				<p align="justify"><span class="glyphicon glyphicon-phone-alt"></span> <strong>Phone:</strong> 123456</p>
				<p align="justify"><span class="glyphicon glyphicon-pencil"></span> <strong>Email:</strong> @.com</p>
			</div>
			<div class="col-md-5">
				<h3>Categories</h3>
				<div class="col-md-6">
				<h4>International </h4>
					<ul style="list-style-type:none;">
						<?php
						$typeA="International";
						$typeB="Sister_Company";
						$checkCatID1="no";

						//international category query stats
						$s1="select distinct subcategoryID from product where productType='$typeA';";
							$qr1=mysqli_query($connect,$s1) or die ("Error in Mysqli: ".mysqli_error($connect));
							while ($rs1=mysqli_fetch_array($qr1)){
								$subCatID=$rs1['subcategoryID'];
								$s2="Select categoryID from subcategory where subcategoryID='$subCatID';";
								$qr2=mysqli_query($connect,$s2) or die("Error in Mysqli: ".mysqli_error($connect));
								while($rs2=mysqli_fetch_array($qr2)){
									$catID=$rs2['categoryID'];
									$s3="Select * from category where categoryID='$catID';";
									$qr3=mysqli_query($connect,$s3) or die ("Error in Mysqli: ".mysqli_error($connect));
									while($rs3=mysqli_fetch_array($qr3)){
										$catName=$rs3['categoryName'];
										$catDesc=$rs3['categoryDesc'];
										$catImg=$rs3['categoryImagePath'];
										$catID=$rs3['categoryID'];
										if($checkCatID1!=$catID){
											$checkCatID1=$catID;
							?>

							
									<li><a href="categories.php?category=<?php echo $catID;?> & type=<?php echo $typeA;?>"><?php echo $catName;?></a></li>
								

						<?php	
										}
									}
								}
							}
						?> 
					</ul>
				</div> 

				<div class="col-md-6">
				<h4>Sister </h4>
					<ul style="list-style-type:none;">
						<?php
						$typeA="International";
						$typeB="Sister_Company";
						$checkCatID1="no";

						//sister company category query stats
						$s1="select distinct subcategoryID from product where productType='$typeB';";
							$qr1=mysqli_query($connect,$s1) or die ("Error in Mysqli: ".mysqli_error($connect));
							while ($rs1=mysqli_fetch_array($qr1)){
								$subCatID=$rs1['subcategoryID'];
								$s2="Select categoryID from subcategory where subcategoryID='$subCatID';";
								$qr2=mysqli_query($connect,$s2) or die("Error in Mysqli: ".mysqli_error($connect));
								while($rs2=mysqli_fetch_array($qr2)){
									$catID=$rs2['categoryID'];
									$s3="Select * from category where categoryID='$catID';";
									$qr3=mysqli_query($connect,$s3) or die ("Error in Mysqli: ".mysqli_error($connect));
									while($rs3=mysqli_fetch_array($qr3)){
										$catName=$rs3['categoryName'];
										$catDesc=$rs3['categoryDesc'];
										$catImg=$rs3['categoryImagePath'];
										$catID=$rs3['categoryID'];
										if($checkCatID1!=$catID){
											$checkCatID1=$catID;
							?>

							
									<li style="color:#000;"><a href="categories.php?category=<?php echo $catID;?> & type=<?php echo $typeB;?>"><?php echo $catName;?></a></li>
								

						<?php	
										}
									}
								}
							}
						?> 
					</ul>
				</div>

			</div>
		</div>		
	</div>
<div class="container" style="margin-top:20px">
	<div style="float:right">
	<a href="http://www.plus.google.com"><img src="images/social/google+.png"></a>	
</div>
	<div class="copyright" align="middle">
		<p>Copyright &copy 2014 Krishna International. All rights reserved</p>
		<p>Powered By: <a href="http://www.hitechskills.com">Hi-Tech Skills</a></p>
	</div>
</div>	
</div>
<?php
$typeA="International";
$typeB="Sister_Company";
$checkCatID1="no";
?>
<link rel="stylesheet" type="text/css" href="css/sidemenu.css">
<div id='cssmenu'>
   <ul>
      <li class="heading"><a><strong><span><span class="glyphicon glyphicon-tasks"></span> International</span></strong></a></li>
      	<ul class="custom-ul">
         <?php
					$s1="select distinct subcategoryID from product where productType='$typeA';";
					$qr1=mysqli_query($connect,$s1) or die ("Error in Mysqli: ".mysqli_error($connect));
					while ($rs1=mysqli_fetch_array($qr1)){
						$subCatID=$rs1['subcategoryID'];
						$s2="Select categoryID from subcategory where subcategoryID='$subCatID';";
						$qr2=mysqli_query($connect,$s2) or die("Error in Mysqli: ".mysqli_error($connect));
						while($rs2=mysqli_fetch_array($qr2)){
							$catID=$rs2['categoryID'];
							$s3="Select * from category where categoryID='$catID';";
							$qr3=mysqli_query($connect,$s3) or die ("Error in Mysqli: ".mysqli_error($connect));
							while($rs3=mysqli_fetch_array($qr3)){
								$catName=$rs3['categoryName'];
								$catDesc=$rs3['categoryDesc'];
								$catImg=$rs3['categoryImagePath'];
								$catID=$rs3['categoryID'];
								if($checkCatID1!=$catID){
									$checkCatID1=$catID;
									
				?>
         
            <li><a href="categories.php?category=<?php echo $catID;?> & type=<?php echo $typeA;?>"><span><?php echo $catName;?></span></a></li>
         
         <?php	
								}
							}
						}
					}
		?>  
		</ul> 
   </ul>
   <ul>
      <li class="heading"><a><strong><span><span class="glyphicon glyphicon-tasks"></span> Sister Company</span></strong></a></li>
      	<ul class="custom-ul">
         <?php
					$s1="select distinct subcategoryID from product where productType='$typeB';";
					$qr1=mysqli_query($connect,$s1) or die ("Error in Mysqli: ".mysqli_error($connect));
					while ($rs1=mysqli_fetch_array($qr1)){
						$subCatID=$rs1['subcategoryID'];
						$s2="Select categoryID from subcategory where subcategoryID='$subCatID';";
						$qr2=mysqli_query($connect,$s2) or die("Error in Mysqli: ".mysqli_error($connect));
						while($rs2=mysqli_fetch_array($qr2)){
							$catID=$rs2['categoryID'];
							$s3="Select * from category where categoryID='$catID';";
							$qr3=mysqli_query($connect,$s3) or die ("Error in Mysqli: ".mysqli_error($connect));
							while($rs3=mysqli_fetch_array($qr3)){
								$catName=$rs3['categoryName'];
								$catDesc=$rs3['categoryDesc'];
								$catImg=$rs3['categoryImagePath'];
								$catID=$rs3['categoryID'];
								if($checkCatID1!=$catID){
									$checkCatID1=$catID;
									
				?>
         
            <li><a href="categories.php?category=<?php echo $catID;?> & type=<?php echo $typeB;?>"><span><?php echo $catName;?></span></a></li>
         
         <?php	
								}
							}
						}
					}
		?>  
		</ul> 
   </ul>
</div>
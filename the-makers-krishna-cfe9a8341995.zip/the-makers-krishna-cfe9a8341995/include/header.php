<?php
include('cms_admin/connect1.php');
?>
<!------ CSS & JS ------>       
  <link rel="stylesheet" href="css/bootstrap.css"> 
  <link rel="stylesheet" href="css/bootswatch.css">      
  <link rel="stylesheet" href="css/custom-css.css">
  <link rel="stylesheet" href="css/sidemenu.css">
  <link rel="stylesheet" href="css/smoothzoom.css">
  <link rel="stylesheet" href="css/font-awesome.css">

  <script src="js/ajax.googleapis"></script>  
  <script src="js/modernizr.js"></script>    
  <script src="js/jquery.min.js" type="text/javascript"></script>
  <script src="js/modernizr.custom.17475.js" type="text/javascript"></script>
  <script src="js/jquery-1.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="js/bootswatch.js"></script>

    <link rel="stylesheet" href="css/colorbox.css" />
  <script src="js/jquery.colorbox.js"></script>
  <script>
      $(document).ready(function(){
        //Examples of how to assign the Colorbox event to elements
        $(".group1").colorbox({rel:'group1'});
        $(".group2").colorbox({rel:'group2', transition:"fade"});
        $(".group3").colorbox({rel:'group3', transition:"none", width:"75%", height:"75%"});
        $(".group4").colorbox({rel:'group4', slideshow:true});
        $(".ajax").colorbox();
        $(".youtube").colorbox({iframe:true, innerWidth:640, innerHeight:390});
        $(".vimeo").colorbox({iframe:true, innerWidth:500, innerHeight:409});
        $(".iframe").colorbox({iframe:true, width:"80%", height:"80%"});
        $(".inline").colorbox({inline:true, width:"50%"});
        $(".callbacks").colorbox({
          onOpen:function(){ alert('onOpen: colorbox is about to open'); },
          onLoad:function(){ alert('onLoad: colorbox has started to load the targeted content'); },
          onComplete:function(){ alert('onComplete: colorbox has displayed the loaded content'); },
          onCleanup:function(){ alert('onCleanup: colorbox has begun the close process'); },
          onClosed:function(){ alert('onClosed: colorbox has completely closed'); }
        });

        $('.non-retina').colorbox({rel:'group5', transition:'none'})
        $('.retina').colorbox({rel:'group5', transition:'none', retinaImage:true, retinaUrl:true});
        
        //Example of preserving a JavaScript event for inline calls.
        $("#click").click(function(){ 
          $('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
          return false;
        });
      });
    </script>
  <!-- color box css and jquery end -->

<!------ --------- ------>

<div class="navbar navbar-default navbar-fixed-top">
  <div class="custom-container">
    <div class="navbar-header">
          <a href="#" class="navbar-brand">
            <img src="images/krilogo.png" alt="Logo" style="margin-top:-16px;">
            <h2 style="margin-top:-6px;margin-left:3px;float:right; text-align:center; font-family:samarkan;">Krishna </br><span>International</span></h2>
          </a>
          <button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target="#navbar-main">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
    </div>
    <div style="height: 1px;" class="navbar-collapse collapse" id="navbar-main">
      <ul class="nav navbar-nav">
          <li class="dropdown"><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
          <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="themes"><span class="fa fa-plus-square"></span> Products <span class="caret"></span></a>
            <ul class="dropdown-menu" aria-labelledby="themes">
              <li><a href="categories_list.php?type=International">International</a></li>
              <li><a href="categories_list.php?type=Sister_Company">Sister Concern</a></li>                            
            </ul>
          </li>
          <li>
            <a href="about_us.php"><span class="glyphicon glyphicon-info-sign"></span> About</a>
          </li> 
          <li>
            <a href="services.php"><span class="fa fa-ellipsis-v"></span> Services</a>
          </li>
          <li>
            <a href="faq.php"><span class="glyphicon glyphicon-question-sign"></span> FAQ</a>
          </li>       
          <li>
            <a href="quotation.php"><span class="glyphicon glyphicon-send"></span> Quotation</a>
          </li>
          <li>
            <a href="gallery.php"><span class="glyphicon glyphicon-picture"></span> Gallery</a>
          </li>
          <li>
            <a href="events.php"><span class="glyphicon glyphicon-bullhorn"></span> Event</a>
          </li>
          
          <li>
            <a href="contact_us.php" id="contact"><span class="glyphicon glyphicon-envelope"></span> Contact</a>             
          </li>
      </ul>
      <ul class="search">
        <li>
          <div class="search">
            <form action="search.php" method="get">
              <input type="search" placeholder="Products" name="pnm">
            </form>
          </div>
        </li>
      </ul>
    </div>    
  </div>
</div>

        
          

       
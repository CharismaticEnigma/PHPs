<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Bagmati Enterprises</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<h3>Contact Us</h3>
		<p align="justify">
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		</p>
		<hr>
		<div class="row">
			<div class="col-md-6">
				<div class="well">
				<table class="table-border">
					<tr>
						<td colspan="2" align="center"><h2>Bagmati Enterprises</h2></td>
					</tr>
					<tr>
						<td colspan="2" align="right"><h4>Single Source Multiple Solutions</h4></td>
					</tr>
					<tr>
						<td><strong>Address:</strong></td>
						<td>Tripurapath, Tripureswor, Kathmandu, Nepal</td>
					</tr>
					<tr>
						<td><strong>House No:</strong></td>
						<td>336-16 Raut Niwas</td>
					</tr>
					<tr>
						<td align="left"><strong>Email:</strong></td>
						<td>bagmati@info.com</td>
					</tr>
					<tr>
						<td></td>
						<td>bagmati@ntc.net.np</td>
					</tr>
					<tr>
						<td><strong>Phone No.:</strong></td>
						<td>+977-1-4260889</td>
					</tr>
					<tr>
						<td></td>
						<td>+977-1-4261912</td>
					</tr>
					<tr>
						<td></td>
						<td>+977-1-4255762</td>
					</tr>
					<tr>
						<td><strong>Fax No:</strong></td>
						<td>977-1-4260633</td>
					</tr>
					<tr>
						<td><strong>G.P.O Box</strong></td>
						<td>26350</td>
					</tr>

				 </table>
					<form name="form" action="include/mail.php" method="post">
						<table>
							<tr>
								<td><p>Name</p></td>
								<td></td>
								<td><input type="text" name="name" id="name" placeholder="Name" style="width:100%;"></td>
							</tr>
							<tr>
								<td><p>E-mail</p></td>
								<td></td>
								<td><input type="text" name="email" id="email" placeholder="E-mail" style="width:100%;"></td>
							</tr>
							<tr>
								<td><p>Subject</p></td>
								<td></td>
								<td><input type="text" name="subject" id="subject" placeholder="Subject" style="width:100%;"></td>
							</tr>
							<tr>
								<td><p>Your Message</p></td>
								<td></td>
								<td><textarea name="message" id="message" cols="45"  placeholder="Your Message"rows="5"></textarea></td>
							</tr>
							<tr>
								<td>&nbsp</td>
								<td>&nbsp</td>
								<td>&nbsp</td>
							</tr>
							<tr>
								<td></td>
								<td></td>
								<td style="float:right;"><input class="btn btn-info" type="submit" name="submit" id="submit" value="Submit"></td>
							</tr>
						</table>
					</form>
				</div>
			</div>
			<div class="col-md-6">
				<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script><div style="overflow:hidden;height:500px;width:600px;"><div id="gmap_canvas" style="height:500px;width:600px;"></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style><a class="google-map-code" href="http://wordpress-themes.org" id="get-map-data">wordpress-themes.org</a></div><script type="text/javascript"> function init_map(){var myOptions = {zoom:16,center:new google.maps.LatLng(27.691994460300617,85.31536481111448),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(27.691994460300617, 85.31536481111448)});infowindow = new google.maps.InfoWindow({content:"<b>Jaya Sai Baba Surgical House</b><br/>Tripureshwor<br/> Kathmandu" });google.maps.event.addListener(marker, "click", function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>
			</div>
		</div>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
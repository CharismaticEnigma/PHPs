<?php
class Eventpage
{
	function addEvent(){
		include("connect1.php");
		$eventName=$_POST['evname'];	
		$iDesc=$_POST['desc'];
	

		//the php script to upload the image
		$imagename = $_FILES["newsimg"]["name"];
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		//path to put into the database table
		$path = "images/event/$imagename";
		
		//actual server destination folder
		$dest = "../images/event/$imagename";
		$arr = explode(".",$imagename);
		//check whether the extention is correct
		$ext = $arr[1];
		
		if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG') or($ext==''))
		{	
			if($ext=='')
			{
				$sql= "insert into event (eventName, eventDesc,eventImagePath) values ('$eventName','$iDesc','images/event');";
		
				mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
				echo "data sucessfully added";
			}
			elseif(file_exists($dest)){
					echo "an image with that name already exists.. Please change your file";
				}
			else{

				//copy the temporarily uploaded file to the server destination (actual upload)
				copy($tmpimage,$dest);
				
				//@rename($dest,"../studpics/$id.$ext");

				$sql= "insert into event (eventName, eventDesc,eventImagePath) values ('$eventName','$iDesc','$path');";
		
				mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
				echo "data sucessfully added";
			}
		
		}
		else
		{
			echo "invalid photo! try again.";
			exit;
		}
			
	}
	
	
	function editEvent(){
		include("connect1.php");
		$hid=$_POST['hid'];
		$iID=$_POST['iid'];
		$desc=$_POST['desc'];
		

		if(isset($iID) && $iID !=Null){
			$sqlup=mysqli_query($connect,"Update event Set eventName='$iID' where eventID='$hid'");	
		}
		if(isset($desc)&& $desc !=Null){
			$sqlup=mysqli_query($connect,"Update event Set eventDesc='$desc' where eventID='$hid'");	
		}
		
		
		//the php script to upload the image
		
		$imagename = $_FILES["newsimg"]["name"];
		echo $imagename;
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		//path to put into the database table
		$path = "images/event/$imagename";
		
		//actual server destination folder
		$dest = "../images/event/$imagename";
		echo "Destination: ".$dest;
		
		if (isset($imagename) && $imagename!= Null)
		{
		
		$arr = explode(".",$imagename);
		//check whether the extention is correct
		$ext = $arr[1];
		
		if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG') or($ext==''))
		{	
				if(file_exists($dest)){
			echo "an image with that name already exists.. Please change your file";
		}
		else{
			if(isset($path) && $path !=Null){

			$sql1="Select * from event where eventID='$hid';";
			$res=mysqli_query($connect,$sql1);
			while($row1 = mysqli_fetch_array($res))
			{
 				 //echo $row1['headingImagePath'];
 				 $imgs=$row1['eventImagePath'];
 				 //echo $imgs;
 				 //echo $row1['headingImageName'];
 				$arr=array();
 				 $arr= (explode ("/",$imgs));
 				// echo $arr[2];
 				 $cdr=getcwd();
 				 chdir("../images/event");
 				unlink($arr[2]);
 			}
 			chdir($cdr);
 			copy($tmpimage,$dest);
			$sqlup=mysqli_query($connect,"Update event Set eventImagePath='$path' where eventID='$hid'");	

		}
			//copy the temporarily uploaded file to the server destination (actual upload)
		}
		}
		else
		{
			echo "invalid photo! try again.";
			exit;
		}	
		}		
		
		//echo "Data updated successfully";
		
	}
	
	
	
	
	}
	
	$Eventpage = new Eventpage();
	?>
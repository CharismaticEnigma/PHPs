   <?php
   ?>
   <div id="menu">
        <ul>
       <li><a href="#">Brand</a>
                <ul>
                    <li class="top"><a href="add_brand.php"> Add Brand</a></li>
                    <li><a href="edit_delete_brand.php">Edit/Delete Brand</a></li>					
					</ul>
            </li>
					
			<li class="first"><a href="#">Category</a>
                <ul>
                    <li class="top"><a href="add_category.php"> Add Category</a></li>
					<li class="top"><a href="edit_delete_category.php"> Edit/Delete Category</a></li>
                    <li class="top"><a href="add_subCategory.php"> Add Sub Category</a></li>
					<li class="top"><a href="edit_delete_subCategory.php"> Edit/Delete Sub Category</a></li>
                    </ul>
            </li>
            <li class="first"><a href="#">Event</a>
                <ul>
                    <li class="top"><a href="event_add.php"> Add Event</a></li>
                    <li class="top"><a href="event_edit_delete.php"> Edit/Delete Event</a></li>
                    
                    </ul>
            </li>
			<li class="first"><a href="#">Slider/Gallery Image</a>
                <ul>
                    <li class="top"><a href="add_slider1.php"> Add Image for Big Slider</a></li>
					<li class="top"><a href="edit_delete_slider1.php"> Delete Image for Big Slider</a></li>
                     <li class="top"><a href="gallery_image_add.php"> Add Image for Gallery</a></li>
                    <li class="top"><a href="gallery_image_delete.php"> Delete Image for Gallery</a></li>
                    </ul>
            </li>
            <li class="first"><a href="#">Product</a>
                <ul>
                    <li class="top"><a href="add_product.php"> Add New Product</a></li>
                    <li class="top"><a href="edit_delete_product.php"> Edit/Delete Product With Category</a></li>d
                    </ul>
            </li>
            <li class="first"><a href="#">About</a>
                <ul>
                    <li class="top"><a href="add_about.php"> Add New Article</a></li>
                    <li class="top"><a href="edit_delete_about.php"> Edit/Delete Article</a></li>
                    </ul>
            </li>
             <li class="first"><a href="welcome_edit.php">Edit Welcome</a>
             </li>
			
			           
           </ul>
    </div>
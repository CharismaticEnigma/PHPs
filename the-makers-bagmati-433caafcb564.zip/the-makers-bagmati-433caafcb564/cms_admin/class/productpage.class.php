<?php

class Productpage
{
	//public $ext,$extsof,$extcata, $destsof, $dest, $destcata;
	function insertProduct(){
	
		$name=$_POST['productname'];		
		$bid=$_POST['brandid'];
		$scid=$_POST['subcategoryid'];
		$desc=$_POST['productdesc'];
		$pstatus=$_POST['productstatus'];
		
		$boolimg="false";
		$boolsof="false";
		$boolcata="false";
		
		$ext="";
		$extsof="";
		$extcata="";

		$dest = "../images/product";
		$destsof = "../images/product/software";
		$destcata = "../images/product/catalog";		

		//the php script to upload the image
		$imagename = $_FILES["newsimg"]["name"];
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		$soflink=$_FILES["softwarelink"]["name"];
		$tmpsoflink=$_FILES["softwarelink"]["tmp_name"];

		$catalink=$_FILES["cataloglink"]["name"];
		$tmpcatalink=$_FILES["cataloglink"]["tmp_name"];

		//path to put into the database table
		$path = "images/product/$imagename";
		$pathsof = "images/product/software/$soflink";
		$pathcata = "images/product/catalog/$catalink";
		
		//actual server destination folder
		
		
		//check whether the extention is correct
		if($imagename!="" || $imagename!=null){
			$dest = "../images/product/$imagename";
			$arr = explode(".",$imagename);
			$ext = $arr[1];
		}
			

		if($soflink!="" || $soflink!=null) {
			$destsof = "../images/product/software/$soflink";
			$arrsof= explode(".",$soflink);
			$extsof= $arrsof[1];

		}

		if($catalink!="" || $catalink!=null){
			$destcata = "../images/product/catalog/$catalink";		
			$arrcata= explode(".",$catalink);
			$extcata= $arrcata[1];	
		}
		
		
			if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG'))
			{
				if(file_exists($dest)){
					echo "an image with that name already exists.. Please change your file";
					$boolimg="exist";
				}
				else{
					$boolimg="true";
				}
			}
			elseif ($ext==""){
				$path="null";
			}
			else{
				echo "Invalid photo type";
			}

			if(($extsof=='exe'))
			{
				if(file_exists($destsof)){
					echo $destsof;
						echo "a software with that name already exists.. Please change your file";
						$boolsof="exist";
				}
				else{
					$boolsof="true";
				}

			}
			elseif ($extsof==""){
				$pathsof="null";
			}					
			else{
				echo "Invalid file type";
			}
			if(($extcata=='pdf') or ($extcata=='doc') or ($extcata=='docx') or ($extcata=='txt'))
			{
				if(file_exists($destcata)){
						echo "a catalog with that name already exists.. Please change your file";
						$boolcata="exist";

				}
				else{
					$boolcata="true";
				}

			}
			elseif($extcata==""){
				$pathcata="null";
			}
			else{
				echo "Invalid pdf type";
			}

			if($boolimg!="exist" && $boolsof!="exist" && $boolcata!="exist"){
				//copy the temporarily uploaded file to the server destination (actual upload)
				if($boolimg=="true"){
					copy($tmpimage,$dest);
				}
				if($boolsof=="true"){
					copy($tmpsoflink,$destsof);
					
				}
				if($boolcata=="true"){
				//copy($catalink,$destcata);					
					copy($tmpcatalink,$destcata);
				}

				
				//@rename($dest,"../studpics/$id.$ext");
				include("connect1.php");

					$sql= "insert into product (productName,subcategoryID,brandID,productDesc,productImagePath,productStatus,productSoftwareLink,productCatalogLink) values ('$name',$scid,$bid,'$desc','$path','$pstatus','$pathsof','$pathcata');";
					mysqli_query($connect,$sql) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));

					$sql2="select * from subcategory where subcategoryID=$scid;";
					
					$result2=mysqli_query($connect,$sql2) or die("Error in Mysql :".mysqli_error());
					if ($row2=mysqli_fetch_array($result2))
					{
						$cid=$row2['categoryID'];
						
						$sqlc="select * from brandcategory where brandID=$bid and categoryID=$cid;";
						//echo $sqlc;
						$resultc=mysqli_query($connect,$sqlc) or die("Error in Mysql :".mysqli_error());
						$countc=mysqli_num_rows($resultc);
						
						if ($countc<1) {
							$sql3= "insert into brandcategory (brandID, categoryID) values ($bid,$cid);";
							mysqli_query($connect,$sql3) or die("Error in SQL: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error());
							echo "data sucessfully added";
						}
					
						
					}


			}				
					




					
						
		
		
	}


	function editProduct(){
		include("connect1.php");
		$name=$_POST['nm'];
		$brand=$_POST['brand'];
		$subcategory=$_POST['sub'];
		$status=$_POST['status'];
		$desc=$_POST['desc'];
		$pid=$_POST['pid'];
		$bid=$_POST['bid'];
		$scid=$_POST['scid'];

		//fetching imagepath, software link and catalog
		$imgLoc=$_POST['imagepath'];
		$sofLoc=$_POST['softwareLink1'];
		$catLoc=$_POST['catalogLink1'];

		
		if(isset($name) && $name !=Null){
			$sqlup=mysqli_query($connect,"Update product Set productName='$name' where productID='$pid'");	
		}
		

		if(isset($desc)&& $desc !=Null){
			$sqlup=mysqli_query($connect,"Update product Set productDesc='$desc' where productID='$pid'");	
		}
		

		if($status !="-- Select --" && $status !=Null){			
			$sqlup=mysqli_query($connect,"Update product Set productStatus='$status' where productID='$pid'");	
		}

		if ($brand!="-- Select --" && $subcategory!="-- Select --"){

			$sql1="select * from subcategory where subcategoryID='$scid';";					
			$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
			if ($row1=mysqli_fetch_array($result1))
					{
						$cid=$row1['categoryID'];
						$sql2="select * from product where brandID='$bid' and subcategoryID='$scid';";
						$result2=mysqli_query($connect,$sql2) or die("Error in Mysql line 116 :".mysqli_error($connect));
						$count2=mysqli_num_rows($result2);
						
						if ($count2>=2) {
							$b1=$brand;
							$sqlup1=mysqli_query($connect,"Update product Set brandID='$brand',subcategoryID='$subcategory' where productID='$pid'") or die("Error in Mysql : line 122".mysqli_error($connect));	

							$sql3="select * from subcategory where subcategoryID='$subcategory';";
							$result3=mysqli_query($connect,$sql3) or  die("Error in Mysql 123:".mysqli_error($connect));
							if ($row3=mysqli_fetch_array($result3))
							{ 
								$cid4=$row3['categoryID']; 
								$sql4="select * from brandcategory where brandID='$brand' and categoryID='$cid4';";
								$result4=mysqli_query($connect,$sql4) or die("Error in Mysql 128:".mysqli_error($connect));
								$count4=mysqli_num_rows($result4);

								if($count4<1)
								{
									$sql5= "insert into brandcategory (brandID, categoryID) values ($brand,$cid4);";
									mysqli_query($connect,$sql5) or die("Error in SQL 134: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
									echo "data sucessfully added";
								}

							}
						}
						else
						{
							$sqldel6="delete from brandcategory where brandID='$bid' and categoryID='$cid';";
							mysqli_query($connect,$sqldel6) or die("Error in Mysql: 144".mysqli_error($connect));
							$sqlup1=mysqli_query($connect,"Update product Set brandID='$brand', subcategoryID='$subcategory' where productID='$pid'") or die("Error in Mysql : line 146".mysqli_error($connect));	

							$sql7="select * from subcategory where subcategoryID='$subcategory';";
							$result7=mysqli_query($connect,$sql7) or  die("Error in Mysql 146 :".mysqli_error($connect));
							if ($row7=mysqli_fetch_array($result7))
							{
								$cid8=$row7['categoryID']; 
								$sql8="select * from brandcategory where brandID='$brand' and categoryID='$cid8';";
								$result8=mysqli_query($connect,$sql8) or die("Error in Mysql 151:".mysqli_error($connect));
								$count8=mysqli_num_rows($result8);

								if($count8<1)
								{
									$sql9= "insert into brandcategory (brandID, categoryID) values ('$brand','$cid8');";
									mysqli_query($connect,$sql9) or die("Error in SQL 157: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
									echo "data sucessfully added";
								}

							}


						}
					}
			
		}

		elseif($brand!="-- Select --" && $brand !=Null){
			
			$sql1="select * from subcategory where subcategoryID='$scid';";					
			$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
			if ($row1=mysqli_fetch_array($result1))
					{
						$cid=$row1['categoryID'];
						$sql2="select * from product where brandID='$bid' and subcategoryID='$scid';";
						$result2=mysqli_query($connect,$sql2) or die("Error in Mysql line 116 :".mysqli_error($connect));
						$count2=mysqli_num_rows($result2);
						
						if ($count2>=2) {
							$sqlup1=mysqli_query($connect,"Update product Set brandID='$brand' where productID='$pid'");	

							/*$sql3="select * from subcategory where subcategoryID='$scid';";
							$result3=mysqli_query($connect,$sql3) or  die("Error in Mysql 123:".mysqli_error($connect));
							if ($row3=mysqli_fetch_array($result3))
							{ 
								$cid4=$row3['categoryID']; */
								$sql4="select * from brandcategory where brandID='$brand' and categoryID='$cid';";
								$result4=mysqli_query($connect,$sql4) or die("Error in Mysql 128:".mysqli_error($connect));
								$count4=mysqli_num_rows($result4);

								if($count4<1)
								{
									$sql5= "insert into brandcategory (brandID, categoryID) values ($brand,$cid);";
									mysqli_query($connect,$sql5) or die("Error in SQL 134: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
									echo "data sucessfully added";
								}

							//}
						}
						else
						{
							$sqldel6="delete from brandcategory where brandID='$bid' and categoryID='$cid';";
							mysqli_query($connect,$sqldel6) or die("Error in Mysql: 144".mysqli_error($connect));
							$sqlup1=mysqli_query($connect,"Update product Set brandID='$brand' where productID='$pid'");	

							/*$sql7="select * from subcategory where subcategoryID='$scid';";
							$result7=mysqli_query($connect,$sql7) or  die("Error in Mysql 146 :".mysqli_error($connect));
							if ($row7=mysqli_fetch_array($result7))
							{
								$cid8=$row7['categoryID']; */
								$sql8="select * from brandcategory where brandID='$brand' and categoryID='$cid';";
								$result8=mysqli_query($connect,$sql8) or die("Error in Mysql 151:".mysqli_error($connect));
								$count8=mysqli_num_rows($result8);

								if($count8<1)
								{
									$sql9= "insert into brandcategory (brandID, categoryID) values ('$brand','$cid');";
									mysqli_query($connect,$sql9) or die("Error in SQL 157: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
									echo "data sucessfully added";
								}

							//}


						}
					}
		}

		elseif($subcategory!="-- Select --" && $subcategory !=Null){
			
			$sql1="select * from subcategory where subcategoryID='$scid';";					
			$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
			if ($row1=mysqli_fetch_array($result1))
					{
						$cid=$row1['categoryID'];
						$sql2="select * from product where brandID='$bid' and subcategoryID='$scid';";
						$result2=mysqli_query($connect,$sql2) or die("Error in Mysql line 116 :".mysqli_error($connect));
						$count2=mysqli_num_rows($result2);
						
						if ($count2>=2) {
							$sqlup1=mysqli_query($connect,"Update product Set subcategoryID='$subcategory' where productID='$pid'");	

							$sql3="select * from subcategory where subcategoryID='$subcategory';";
							$result3=mysqli_query($connect,$sql3) or  die("Error in Mysql 123:".mysqli_error($connect));
							if ($row3=mysqli_fetch_array($result3))
							{ 
								$cid4=$row3['categoryID']; 
								$sql4="select * from brandcategory where brandID='$bid' and categoryID='$cid4';";
								$result4=mysqli_query($connect,$sql4) or die("Error in Mysql 128:".mysqli_error($connect));
								$count4=mysqli_num_rows($result4);

								if($count4<1)
								{
									$sql5= "insert into brandcategory (brandID, categoryID) values ($bid,$cid4);";
									mysqli_query($connect,$sql5) or die("Error in SQL 134: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
									echo "data sucessfully added";
								}

							}
						}
						else
						{
							$sqldel6="delete from brandcategory where brandID='$bid' and categoryID='$cid';";
							mysqli_query($connect,$sqldel6) or die("Error in Mysql: 144".mysqli_error($connect));
							$sqlup1=mysqli_query($connect,"Update product Set subcategoryID='$subcategory' where productID='$pid'");	

							$sql7="select * from subcategory where subcategoryID='$subcategory';";
							$result7=mysqli_query($connect,$sql7) or  die("Error in Mysql 146 :".mysqli_error($connect));
							if ($row7=mysqli_fetch_array($result7))
							{
								$cid8=$row7['categoryID']; 
								$sql8="select * from brandcategory where brandID='$bid' and categoryID='$cid8';";
								$result8=mysqli_query($connect,$sql8) or die("Error in Mysql 151:".mysqli_error($connect));
								$count8=mysqli_num_rows($result8);

								if($count8<1)
								{
									$sql9= "insert into brandcategory (brandID, categoryID) values ('$bid','$cid8');";
									mysqli_query($connect,$sql9) or die("Error in SQL 157: <a href='javascript:history.back()'> Click here to Go back </a> &nbsp;&nbsp;".mysqli_error($connect));
									echo "data sucessfully added";
								}

							}


						}
					}
		}


		
	//end of image edit
		$boolimg="false";
		$boolsof="false";
		$boolcata="false";

		$ext="";
		$extsof="";
		$extcata="";

		$dest = "../images/product";
		$destsof = "../images/product/software";
		$destcata = "../images/product/catalog";		

		//the php script to upload the image
		$imagename = $_FILES["newsimg"]["name"];
		$tmpimage = $_FILES["newsimg"]["tmp_name"];

		$soflink=$_FILES["softwarelink"]["name"];
		$tmpsoflink=$_FILES["softwarelink"]["tmp_name"];

		$catalink=$_FILES["cataloglink"]["name"];
		$tmpcatalink=$_FILES["cataloglink"]["tmp_name"];

		//path to put into the database table
		$path = "images/product/$imagename";
		$pathsof = "images/product/software/$soflink";
		$pathcata = "images/product/catalog/$catalink";
		
		//actual server destination folder
		
		
		//check whether the extention is correct
		if($imagename!="" || $imagename!=null){
			$dest = "../images/product/$imagename";
			$arr = explode(".",$imagename);
			$ext = $arr[1];
		}
			

		if($soflink!="" || $soflink!=null) {
			$destsof = "../images/product/software/$soflink";
			$arrsof= explode(".",$soflink);
			$extsof= $arrsof[1];

		}

		if($catalink!="" || $catalink!=null){
			$destcata = "../images/product/catalog/$catalink";		
			$arrcata= explode(".",$catalink);
			$extcata= $arrcata[1];	
		}
		
		
			if(($ext=='jpg') or ($ext=='gif') or ($ext=='JPG') or ($ext=='GIF') or ($ext=='png') or ($ext=='PNG'))
			{
				if(file_exists($dest)){
					echo "an image with that name already exists.. Please change your file";
					$boolimg="exist";
				}
				else{
					$boolimg="true";
				}
			}
			elseif ($ext==""){
				$path="null";
			}
			else{
				echo "Invalid photo type";
			}

			if(($extsof=='exe'))
			{
				if(file_exists($destsof)){
					echo $destsof;
						echo "a software with that name already exists.. Please change your file";
						$boolsof="exist";
				}
				else{
					$boolsof="true";
				}

			}
			elseif ($extsof==""){
				$pathsof="null";
			}					
			else{
				echo "Invalid file type";
			}
			if(($extcata=='pdf') or ($extcata=='doc') or ($extcata=='docx') or ($extcata=='txt'))
			{
				if(file_exists($destcata)){
						echo "a catalog with that name already exists.. Please change your file";
						$boolcata="exist";

				}
				else{
					$boolcata="true";
				}

			}
			elseif($extcata==""){
				$pathcata="null";
			}
			else{
				echo "Invalid pdf type";
			}

			include("connect1.php");


			if($boolimg!="exist" && $boolsof!="exist" && $boolcata!="exist"){
				//copy the temporarily uploaded file to the server destination (actual upload)
				if($boolimg=="true"){
					if($imgLoc!="null")
					{
						$imgarr=array();
						$imgarr=explode("/", $imgLoc);
						$cdr=getcwd();
				 		chdir("../images/product");
				 		unlink($imgarr[2]);
				 		chdir($cdr);
					}
			 		copy($tmpimage,$dest);
					$sqlup=mysqli_query($connect,"Update product Set productImagePath='$path' where productID='$pid'");
				}
				if($boolsof=="true"){
					if($sofLoc!="null"){
						$sofarr=array();
						$sofarr=explode("/", $sofLoc);
						$cdr=getcwd();
				 		chdir("../images/product/software");
				 		unlink($sofarr[3]);
				 		chdir($cdr);
			 		}
			 		copy($tmpsoflink,$destsof);
					$sqlup1=mysqli_query($connect,"Update product Set productSoftwareLink='$pathsof' where productID='$pid'");
					
					
				}
				if($boolcata=="true"){
				//copy($catalink,$destcata);
					if($catLoc!="null"){
						$catarr=array();
						$catarr=explode("/", $catLoc);
						$cdr=getcwd();
				 		chdir("../images/product/catalog");
				 		unlink($catarr[3]);
				 		chdir($cdr);
			 		}
			 		copy($tmpsoflink,$destcata);
					$sqlup1=mysqli_query($connect,"Update product Set productCatalogLink='$pathcata' where productID='$pid'");					
					//copy($tmpcatalink,$destcata);
				}

			}		

		
		
		
	}

	function deleteProduct(){
		include("connect1.php");
		 $pid=$_POST['pid'];
		

		 $bid=$_POST['bid'];
		 $scid=$_POST['scid'];
		 $path=$_POST['imagepath'];
		 $sofLoc=$_POST['softwareLink1'];
		$catLoc=$_POST['catalogLink1'];

		 //echo $pid.$bid.$scid;
		 $s1="Select * from product where brandID='$bid' and subcategoryID='$scid';";
		 $r1=mysqli_query($connect, $s1) or die("Error in mysql: ".mysqli_error($connect));
		 if($c1=mysqli_num_rows($r1)>1){
		 	
		 	if($path!="null")
					{
						$imgarr=array();
						$imgarr=explode("/", $path);
						$cdr=getcwd();
				 		chdir("../images/product");
				 		unlink($imgarr[2]);
				 		chdir($cdr);
					}
			if($sofLoc!="null"){
						$sofarr=array();
						$sofarr=explode("/", $sofLoc);
						$cdr=getcwd();
				 		chdir("../images/product/software");
				 		unlink($sofarr[3]);
				 		chdir($cdr);
			 		}
			if($catLoc!="null"){
						$catarr=array();
						$catarr=explode("/", $catLoc);
						$cdr=getcwd();
				 		chdir("../images/product/catalog");
				 		unlink($catarr[3]);
				 		chdir($cdr);
			 		} 

		 	$s2="Delete from product where productID='$pid';";
		 	mysqli_query($connect,$s2) or die("Error in mysql: ".mysqli_error($connect));
		 	//echo "Product Deleted";
		 	header('location:edit_delete_product.php');

		 }
		 elseif ($c1=mysqli_num_rows($r1)==1) {
		 	$s3="Select * from subcategory where subcategoryID='$scid';";
		 	$r2=mysqli_query($connect,$s3) or die("Mysqli Error: ".mysqli_error($connect));
		 	while($qr1=mysqli_fetch_array($r2))
		 	{
		 		$cid=$qr1['categoryID'];
		 	}
		 	$s4="Delete from brandcategory where brandID='$bid' and categoryID='$cid';";
		 	mysqli_query($connect, $s4);
		 	if($path!="null")
					{
						$imgarr=array();
						$imgarr=explode("/", $path);
						$cdr=getcwd();
				 		chdir("../images/product");
				 		unlink($imgarr[2]);
				 		chdir($cdr);
					}
			if($sofLoc!="null"){
						$sofarr=array();
						$sofarr=explode("/", $sofLoc);
						$cdr=getcwd();
				 		chdir("../images/product/software");
				 		unlink($sofarr[3]);
				 		chdir($cdr);
			 		}
			if($catLoc!="null"){
						$catarr=array();
						$catarr=explode("/", $catLoc);
						$cdr=getcwd();
				 		chdir("../images/product/catalog");
				 		unlink($catarr[3]);
				 		chdir($cdr);
			 		} 
		 	

		 	$s2="Delete from product where productID='$pid';";
		 	mysqli_query($connect,$s2) or die("Error in mysql: ".mysqli_error($connect));
		 	echo "Product Deleted";
		 	header('location:edit_delete_product.php');



		 }
	}




	


	
	
	
	}
$Productpage= new Productpage();
?>
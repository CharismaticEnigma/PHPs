<?php
include('cms_admin/connect1.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Bagmati Enterprises</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<h3>Gallery</h3>
		<div class="row">
		<?php
			$s1="Select * from galleryimage;";
			$q1=mysqli_query($connect,$s1) or die("Error in Mysqli: ".mysqli_error($connect));
			while ($rs=mysqli_fetch_array($q1)){
				$galID=$rs['galleryimageID'];
				$galName=$rs['galleryimageName'];
				$galImage=$rs['galleryimageImagePath'];
		?>
		
			<div class="col-md-3 col-xs-6" style="text-align:center;">
				<a class="group1" href="<?php echo $galImage; ?>" title="<?php echo $galName;?>" alt="<?php echo $galName; ?>">
					<img src="<?php echo $galImage; ?>" class="img-thumbnail custom-image" alt="<?php echo $galName; ?>">
				</a>
				<p><?php echo $galName; ?></p>
			</div>
		
		<?php		
			}
		?>
		</div>
		
		
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
include("cms_admin/connect1.php");
$count1=0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Sai Baba</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	
	<div class="container">			
			<div class="row">
				<div class="col-lg-2">
					<?php
						include('include/sidebar.php');
					?>
				</div>
				<!-- ya deke -->
				<div class="col-lg-10">				
				<h3 style="margin-top:-3px;">Our Products</h3>
				<div class="row">
				<?php
					if(isset($_GET['id'])){
						$bid=$_GET['id'];


					$sqlc1="select * from product where brandID='$bid';";
					$resultc1=mysqli_query($connect,$sqlc1) or die("Error in Myslq : line 66".mysqli_error($connect));
					$count1=mysqli_num_rows($resultc1);

					$sql1="select * from product where brandID='$bid' limit 3;";
					$result1=mysqli_query($connect,$sql1) or die("Error in Myslq : line 70".mysqli_error($connect));
					
					?>
					<script>
					function showUser(str)
					{
					if (str=="")
					  {
					  document.getElementById("txtHint2").innerHTML="";
					  return;
					  } 
					if (window.XMLHttpRequest)
					  {// code for IE7+, Firefox, Chrome, Opera, Safari
					  xmlhttp=new XMLHttpRequest();
					  }
					else
					  {// code for IE6, IE5
					  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
					  }
					xmlhttp.onreadystatechange=function()
					  {
					  if (xmlhttp.readyState==4 && xmlhttp.status==200)
						{
						document.getElementById("txtHint2").innerHTML=xmlhttp.responseText;
						}
					  }
					xmlhttp.open("GET","product_get.php?q2=<?php echo $bid; ?> &q3="+str,true);
					xmlhttp.send();
					}
			</script> 
					<br>
 					<span id="txtHint2">
 						<?php
	 						while($row1=mysqli_fetch_array($result1))
						{
							?>
							<!-------------- Repeat -------------->
						<div class="col-lg-3" style="padding:10px;">
							<div class="hover-over" align="middle">
							<img src="<?php echo $row1['productImagePath']; ?>" alt="<?php echo $row1['productName']; ?>" class="img-thumbnail custom-image">
							<strong><p><?php echo $row1['productName']; ?></p></strong>
							<a href="<?php echo "product_details.php?iddetail=".$row1['productID'];?>"><p class="btn btn-danger">Learn More</p></a>
								
						</div>
						</div>

						<!-------------- Repeat -------------->
							<?php
						}
						?>

 					</span>
 					<?php

					}
				?>

				<?php
					if(isset($_GET['brandid']) && isset($_GET['subcateid'])){
						$brandid=$_GET['brandid'];
						$subcate=$_GET['subcateid'];
						
						$brandidd=str_replace(" ", "", $brandid);
						$subcatee=str_replace(" ", "", $subcate);


					$sqlc1="select * from product where brandID=$brandidd and subcategoryID=$subcatee;";
					$resultc1=mysqli_query($connect,$sqlc1) or die("Error in Myslq : line 66".mysqli_error($connect));
					$count1=mysqli_num_rows($resultc1);

					
					$sql4="select * from product where brandID=$brandidd and subcategoryID=$subcatee limit 3;";
					$result4=mysqli_query($connect,$sql4) or die("Error in Mysql : line 67".mysqli_error($connect));
					
					?>
					<script>
					function showUser(str)
					{
					if (str=="")
					  {
					  document.getElementById("txtHint2").innerHTML="";
					  return;
					  } 
					if (window.XMLHttpRequest)
					  {// code for IE7+, Firefox, Chrome, Opera, Safari
					  xmlhttp=new XMLHttpRequest();
					  }
					else
					  {// code for IE6, IE5
					  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
					  }
					xmlhttp.onreadystatechange=function()
					  {
					  if (xmlhttp.readyState==4 && xmlhttp.status==200)
						{
						document.getElementById("txtHint2").innerHTML=xmlhttp.responseText;
						}
					  }
					xmlhttp.open("GET","product_get.php?q7=<?php echo $brandidd; ?>&q4=<?php echo $subcatee; ?> &q3="+str,true);
					xmlhttp.send();
					}
			</script> 
						<br>
 					<span id="txtHint2">
					<?php
					while($row4=mysqli_fetch_array($result4)){

						?>
					
						<!-------------- Repeat -------------->
					<div class="col-lg-3" style="padding:10px;">
						<div class="hover-over" align="middle">
						<img src="<?php echo $row4['productImagePath']; ?>" alt="<?php echo $row4['productName']; ?>" class="img-thumbnail custom-image">
						<strong><p><?php echo $row4['productName']; ?></p></strong>
						<a href="<?php echo "product_details.php?iddetail=".$row4['productID'];?>"><p class="btn btn-danger">Learn More</p></a>
							
					</div>
					</div>

					<!-------------- Repeat -------------->
					
						<?php
					}
					?>
					</span>
					<?php
					
					}
				?>
					

								
					
				</div>
				<div class="row">
				
					<ul class="pagination pagination-lg">Page no.
					<?php
					$pagenum=$count1/3;
					if($count1%3!=0){
						$pagenum++;
					}
					for ($i=1; $i<=$pagenum; $i++)
					{
					?>					
					<li><button value="<?php echo $i; ?> " onclick="showUser(this.value)" style="width:40px; height:30px; font-size:16px; margin:1px;"> <?php echo $i; ?> </button></li>
					<?php
				
				 }
				?>
						
					</ul>

				</div>
			</div>
			</div>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
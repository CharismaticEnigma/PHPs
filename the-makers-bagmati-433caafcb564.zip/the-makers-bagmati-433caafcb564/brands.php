<?php
include('cms_admin/connect1.php');
$excount=0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Sai Baba</title>
	<script type="text/javascript">

		function toggle() {
		var ele = document.getElementById("toggleText");
		var text = document.getElementById("displayText");
		
		if(ele.style.display == "block") {
	    		ele.style.display = "none";
			text.innerHTML = "Expand";
	  	}	  	
		else {
			ele.style.display = "block";
			text.innerHTML = "Collapse";
		}
		}

    </script>

    <script type="text/javascript"><!--
	var dge=document.getElementById;
	function cl_expcol(a){/*
	    document.getElementById(a).style.display = 
	      (document.getElementById(a).style.display=='none')?
	      'block':'none';*/
		  if(document.getElementById(a).style.display=='none')
		  {
			 //alert('block');
			 document.getElementById(a).style.display='block';
		  }
		  else if(document.getElementById(a).style.display=='block')
		  {
			  //alert('none');
			  document.getElementById(a).style.display='none';
		  }
		  else
		  {
			  //alert('def');
			  document.getElementById(a).style.display='block';
		  }
		  
			}
			-->
	</script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">			
		<div class="row">
			<div class="col-lg-2">
				<?php
					include('include/sidebar.php');
				?>
			</div>
			<div class="col-lg-10">
			<?php
					$bid=$_GET['id'];
					$s1="Select * from brand where brandID='$bid';";
					$q1=mysqli_query($connect,$s1) or die("Mysqli Error: ".mysqli_error($connect));
					while($qr1=mysqli_fetch_array($q1)){
						$nm=$qr1['brandName'];
						$desc=$qr1['brandDesc'];
						$img=$qr1['brandImagePath'];
					}
				?>		
				<h3><?php echo $nm; ?></h3>
				<ul class="media-list">								
					<li class="media">
						<img src="<?php echo $img; ?>" class="pull-left img-thumbnail" alt="<?php echo $nm; ?>">
						<div class="media-body">
							<p align="justify">
								<?php echo $desc; ?>
							</p>
						</div>
					</li>
				</ul>
				<div class="well">
					<h3>Categories</h3>
						<div class="row" align="center">
							
								
								<?php
									$sql2="select * from brandcategory where brandID='$bid';";
									$result2=mysqli_query($connect,$sql2) or die("Error in Mysql :".mysqli_error($connect));
									while($row2=mysqli_fetch_array($result2)){
										$cid=$row2['categoryID'];

										//query to get category details from category table
										$sql3="select * from category where categoryID='$cid';";
										$result3=mysqli_query($connect,$sql3) or die("Error in MYslq :".mysqli_error($connect));
										while($row3=mysqli_fetch_array($result3)){
											$excount++;
											$cname=$row3['categoryName'];
											$cimg=$row3['categoryImagePath'];
											
								?>
									<div class="col-md-3" onmouseover="cl_expcol('<?php echo "ex".$excount; ?>')" onmouseout="cl_expcol('<?php echo "ex".$excount; ?>')">
									<div class="cat-container" style="margin-bottom: 8px;">
									<img src="<?php echo $cimg;?>" class="img-thumbnail custom-otherimage" alt="<?php echo $cname;?>" style="margin-top:-60px;">
									<h4><?php echo $cname;?></h4>
									<span class="glyphicon glyphicon-chevron-down"></span>
									</div>

								
										<?php
											//query to get subcategory details from subcategory table
											$sql4="select * from subcategory where categoryID='$cid';";
											$result4=mysqli_query($connect,$sql4) or die("Error in Mysql :".mysqli_error($connect));
											while($row4=mysqli_fetch_array($result4)){
												$scid=$row4['subcategoryID'];
												$scname=$row4['subcategoryName'];
												
										?>
										<ul class="hidetext rl-hover" id="<?php echo "ex".$excount; ?>">								
											<a href="products.php?brandid=<?php echo $bid;?> & subcateid=<?php echo $scid;?>"><li><?php echo $scname; ?></li></a>
										</ul>								
										<?php
											}
										?>
									</div>
								<?php
										}

									} 
								?>
							
						</div>					
				</div>
			</div>
		</div>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
<?php
//include('cms_admin/connect1.php');
?>
<link rel="stylesheet" type="text/css" href="css/sidemenu.css">
<div id='cssmenu'>
   <ul>
      <li class="heading"><a><strong><span>Category</span></strong></a></li>
         <ul class="custom-ul">
         <?php
         $s1="Select * from category;";
         $q1=mysqli_query($connect,$s1) or die("Mysqli Error: ".mysqli_error($connect));
         while($qr1=mysqli_fetch_array($q1))
         {
         ?>
            <li><a href='<?php echo "categories.php?id=".$qr1['categoryID'];?>'><span><?php echo $qr1['categoryName'];?></span></a></li>
            <?php
               }
            ?>
         </ul>   
      <li class="heading"><a><strong><span>Brand</span></strong></a></li>
         <ul class="custom-ul">
         <?php
             $s2="Select * from brand;";
         $q2=mysqli_query($connect,$s2) or die("Mysqli Error: ".mysqli_error($connect));
         while($qr2=mysqli_fetch_array($q2))
         {
         ?>
            <li><a href='brands.php?id=<?php echo $qr2['brandID'];?> '><span><?php echo $qr2['brandName'];?></span></a></li>
            <?php 
         }
         ?>
            
         </ul>
   </ul>
</div>
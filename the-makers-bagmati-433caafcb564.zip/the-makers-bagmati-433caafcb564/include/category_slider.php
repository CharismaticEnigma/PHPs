<?php

?>
  <link href="css/owl.carousel.css" rel="stylesheet">
  <link href="css/owl.theme.css" rel="stylesheet">
  <script src="js/jquery-1.9.1.min.js"></script>  
  <script src="js/owl.carousel.js"></script>
	<div class="row">
    <div class="span12">
      <div id="owl-example" class="owl-carousel">
      <?php 
        $s1="Select * from category limit 3;";
        $qr1=mysqli_query($connect,$s1) or die("Error in mysqli: ".mysqli_error($connect));
        while ($rs=mysqli_fetch_array($qr1)){
          $catName=$rs['categoryName'];
          $catImage=$rs['categoryImagePath'];
          $catDesc=$rs['categoryDesc'];
          $catID=$rs['categoryID'];
       ?>
        <div class="custom-well" style="margin-left:2px; margin-right:2px;" align="center">
          <div style="height:55px; overflow:hidden; margin-bottom:3px;">
            <h4><?php echo $catName; ?></h4>
          </div>
          <img src="<?php echo $catImage;?>"  class="img-thumbnail custom-image" alt="<?php echo $catName; ?>">
           <div style="height:130px; overflow:hidden; margin-bottom:3px;">         
              <p><?php echo $catDesc;?></p>
           </div>
           <a href="category.php?id=<?php echo $catID; ?>" class="btn btn-danger">Learn More</a>
        </div>
       <?php   
        }
      ?>
       
      </div>
    </div>
  </div>



  <script type="text/javascript">
  	    $(document).ready(function() {
     
    $("#owl-example").owlCarousel();
     
    });
  </script>
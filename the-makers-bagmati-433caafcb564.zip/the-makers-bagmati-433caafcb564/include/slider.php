<?php

?>
<link href="css/responsive-slider.css" rel="stylesheet">     
<div class="custom-wells" style="margin-top:20px; margin-bottom:10px;">
	<div class="responsive-slider" data-spy="responsive-slider" data-autoplay="true">
	    <div class="slides" data-group="slides">
	  		<ul>
	  		<?php
	  			$qs1="Select * from sliderimage;";
	  			$qr1=mysqli_query($connect,$qs1) or die("Error in Mysqli: ". mysqli_error($connect));
	  			while($rv1=mysqli_fetch_array($qr1)){
	  				$slID=$rv1['sliderimageID'];
	  				$slImg=$rv1['sliderimageImagePath'];
	  		?>
	  		<li>
	          		<div class="slide-body" data-group="slide">
	            		<img src="<?php echo $slImg; ?>" alt="<?php echo $slID; ?>">
	          		</div>
		    	</li>
	  		<?php
	  			}
	  		?>
		    	
		    </ul>
	    </div>
	    <a class="slider-control left" href="#" data-jump="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
	    <a class="slider-control right" href="#" data-jump="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
	    <div class="pages">
	      <a class="page" href="#" data-jump-to="1">1</a>
	      <a class="page" href="#" data-jump-to="2">2</a>
	      <a class="page" href="#" data-jump-to="3">3</a>
	    </div>
	</div>
</div>
<script src="js/slider/jquery.js"></script>
<script src="js/slider/jquery.event.move.js"></script>
<script src="js/slider/responsive-slider.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript" src="js/smoothzoom.js"></script>
<script type="text/javascript">
    $(window).load( function() {
        $('img').smoothZoom({
            // Options go here
        });
    });
</script>
<div class="container" style="border-bottom:1px dashed #5D5D5D">

<div class="row" style="padding:8px;">
	<div class="col-md-2" align="center"><a href="index.php">Home</a></div>
	<div class="col-md-2" align="center"><a href="index.php">About</a></div>
	<div class="col-md-2" align="center"><a href="index.php">Gallery</a></div>
	<div class="col-md-2" align="center"><a href="index.php">Events</a></div>
	<div class="col-md-2" align="center"><a href="index.php">Contact Us</a></div>
</div>		
</div>
<div class="container" style="margin-top:20px">
	<div style="float:right">
	<a href="http://www.facebook.com"><img src="images/social/fb.png"></a>
	<a href="http://www.twitter.com"><img src="images/social/twitter.png"></a>
</div>
	<div class="copyright" align="middle">
		<p>Copyright &copy 2014 Bagmati Enterprises. All rights reserved</p>
		<p>Powered By: <a href="http://www.hitechskills.com">Hi-Tech Skills</a></p>
	</div>
</div>	
<?php
include('cms_admin/connect1.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Sai Baba</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">			
		<div class="row">
			<div class="col-lg-2">
				<?php
					include('include/sidebar.php');
				?>
			</div>
			<div class="col-lg-10">
			<?php
				$cid=$_GET['id'];
				$s1="Select * from category where categoryID='$cid';";
				$q1=mysqli_query($connect,$s1) or die("Mysqli Error: ".mysqli_error($connect));
				while($qr1=mysqli_fetch_array($q1)){
					$nm=$qr1['categoryName'];
					$desc=$qr1['categoryDesc'];
					$img=$qr1['categoryImagePath'];
				}
		?>
				<h3><?php echo $nm; ?></h3>
				<ul class="media-list">								
					<li class="media">
						<img src="<?php echo $img; ?>" class="pull-left img-thumbnail" alt="<?php echo $nm; ?>">
						<div class="media-body">
							<p align="justify">
								<?php echo $desc; ?>
							</p>
						</div>
					</li>
				</ul>
				<div class="well">
					<h3>Brands</h3>
						<div class="row" align="center">
						<?php 
						$sql2="select * from brandcategory where categoryID='$cid';";
						$result2=mysqli_query($connect,$sql2) or die("Error in Mysql : line 57".mysqli_error());
						while($row2=mysqli_fetch_array($result2))
						{
							$bid=$row2['brandID'];
							$sql3="select * from brand where brandID='$bid';";
							$result3=mysqli_query($connect,$sql3) or die("Error in Mysql : line 62".mysqli_error());
							while($row3=mysqli_fetch_array($result3))
							{
								$bname=$row3['brandName'];
								$bimg=$row3['brandImagePath'];
								?>
								<div class="col-md-3">
									<div class="cat-container" style="margin-bottom: 8px;">
										<a href="<?php echo "products.php?id=".$bid;?>"><img src="<?php echo $bimg;?>" alt="<?php echo $bname;?>" class="img-thumbnail" style="margin-top:-60px;"></a>
										<h4><?php echo $bname;?></h4>
									</div>														
								</div>
								<?php
							}
						}
							?>
							
						</div>
					
				</div>
			</div>

		</div>
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
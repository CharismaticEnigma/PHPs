<?php
include('cms_admin/connect1.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Bagmati Enterprises</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<h3>Downloads</h3>
		<div class="row">
			<div class="col-md-6 col-xs-6">
				<h4 id="catalogue">Catalogue</h4>
				<ul>
				<?php
					$s1="Select * from product;";
					$q1=mysqli_query($connect,$s1) or die ("Error in Mysqli: ".mysqli_error($connect));
					while ($qr1=mysqli_fetch_array($q1)){
						$productName=$qr1['productName'];
						$catLink=$qr1['productCatalogLink'];
						if ($catLink!="null"){


				?>
					<a href="<?php echo $catLink;?>"><li><?php echo $productName;?></li></a>
				<?php
						}
					}
				?>
				</ul>
			</div>
			<div class="col-md-6 col-xs-6">
				<h4 id="software">Software</h4>
				<ul>
				<?php
					$s1="Select * from product;";
					$q1=mysqli_query($connect,$s1) or die ("Error in Mysqli: ".mysqli_error($connect));
					while ($qr1=mysqli_fetch_array($q1)){
						$productName=$qr1['productName'];
						$sofLink=$qr1['productSoftwareLink'];
						if ($sofLink!="null"){
				?>
					<a href="<?php echo $sofLink;?>"><li><?php echo $productName;?></li></a>
				<?php
						}
					}
				?>
				</ul>
			</div>
		</div>
		
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
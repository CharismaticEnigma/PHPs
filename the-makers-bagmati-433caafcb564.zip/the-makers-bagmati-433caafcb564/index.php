<?php
include('cms_admin/connect1.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Bagmati Enterprises</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<?php include('include/slider.php') ?>
			</div>			
		</div>
	</div>
	<div class="content">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<?php
						$sql1="select * from welcome;";
						$result1=mysqli_query($connect,$sql1) or die("Error in Mysql :".mysqli_error($connect));
						$row1=mysqli_fetch_array($result1);
						?>
					<div class="">
						<h2><?php echo $row1['welcomeTitle'];?></h2>
						<p align="justify"><?php echo $row1['welcomeDesc'];?></p>
						<hr>
					</div>
				</div>
			</div>
			<h3>New Products</h3>
			<div class="row">
				<?php
					$s1="Select * from product where productStatus='New' limit 4;";
					$qr1=mysqli_query($connect,$s1) or die("Error in mysqli: ".mysqli_error($connect));
					while($rs=mysqli_fetch_array($qr1)){
						$pid=$rs['productID'];
						$proName=$rs['productName'];
						$proBrand=$rs['brandID'];
						$proImage=$rs['productImagePath'];
						$s2="Select * from brand where brandID='$proBrand';";
						$qr2=mysqli_query($connect,$s2) or die ("Error in Mysqli: ".mysqli_error($connect));
							$rs2=mysqli_fetch_array($qr2);
							$brandName=$rs2['brandName'];
				?>
				<div class="col-lg-3" style="padding:10px;">
					<div class="hover-over" align="middle">
						<img src="<?php echo $proImage ?>" alt="<?php echo $proName; ?>" class="img-thumbnail img-circle custom-image">
						<div style="height:40px; overflow:hidden; margin-bottom:3px;">
							<strong><p><?php echo $proName; ?></p></strong>						
						</div>
						<p><?php echo $brandName; ?></p>
						<a href="<?php echo "product_details.php?iddetail=".$pid;?>"><p class="btn btn-danger">Learn More</p></a>
					</div>
				</div>

				<?php
					}
				?>
				<<a href="products_status.php" class="btn btn-primary" style="float:right">See More</a>
			</div>
			<hr>
			<div class="row">				
				<div class="col-md-8" style="overflow:hidden;">
					<h3>Categories</h3>
					<?php include('include/category_slider.php'); ?>
				</div>
				<div class="col-md-4">
					
					 <?php
				            $ab1=str_replace(" ","",strtolower("About Us"));
				            $ab2=str_replace(" ","",strtolower("About Company"));
				            $ab3=str_replace(" ","",strtolower("About Bagmati"));
				            $ab4=str_replace(" ","",strtolower("About Bagmati Enterprises"));
				            $ab5=str_replace(" ","",strtolower("About Our Company"));
				            
				            $sq2="Select * from about;";
				            $qr2=mysqli_query($connect,$sq2) or die ("Error in Mysqli: ".mysqli_error($connect));
				            while($rs2=mysqli_fetch_array($qr2)){
				                $title=str_replace(" ","",strtoLower($rs2['aboutName']));
				                if($title=="aboutus" || $title=="aboutcompany" || $title=="aboutbagmati" || $title=="aboutbagmatienterprises" || $title=="aboutourcompany"){
				                    $abtName=$rs2['aboutName'];
				                    $desc=$rs2['aboutDesc'];
				                    $abDesc=substr($desc, 0,530)."......";        
				                    ?>
				                    <h3><?php echo $abtName;?></h3>
				                    <p align="justify">
				                        <?php echo $abDesc;?>
				                    </p>
				                    <?php
				                    break;
				                }
				            }
				            

				            ?>
					<a href="about_us.php" class="btn btn-primary">See More</a>
				</div>
			</div>
		</div>
	</div>
	<?php include('include/footer.php');?>	
</body>
</html>
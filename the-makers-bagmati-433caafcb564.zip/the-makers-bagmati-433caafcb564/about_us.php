<?php
include("cms_admin/connect1.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Bagmati Enterprises</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
<?php
	 $sql1="select * from about;";
    $result1=mysqli_query($connect,$sql1) or die("Error in Myslq : line 21".mysqli_error($connect));
    while($row1=mysqli_fetch_array($result1)){
        $aboutname=$row1['aboutName'];
        $aboutdesc=$row1['aboutDesc'];
        $aboutimagepath=$row1['aboutImagePath'];
       
        if ($aboutimagepath!="noimage")
        {
?>
	<div class="container">
		<h3><?php echo $aboutname; ?></h3>
		<div class="row">
			<div class="col-md-6">
				<img src="<?php echo $aboutimagepath; ?>" alt="<?php echo $aboutname; ?>" class="img-thumbnail" style="margin-bottom">
				<!-- <p>Jaya Sai Baba Surgical House</p> -->
			</div>
		</div>
		<p align="justify">
			<?php echo $aboutdesc; ?>
		</p>		
	</div>
	<?php
		}
		else
		{
			?>
			<div class="container">
		<h3><?php echo $aboutname; ?></h3>
		<p align="justify">
			<?php echo $aboutdesc; ?>
		</p>		
	</div>
			<?php
		}
	}
	?>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>
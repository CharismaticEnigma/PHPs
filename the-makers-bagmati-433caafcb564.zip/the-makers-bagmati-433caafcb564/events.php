<?php
include('cms_admin/connect1.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<title>Bagmati Enterprises</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>
<?php
	include('include/header.php');	
?>
<div class="content">
	<div class="container">
		<h3>News & Events</h3>
		<?php
			$sq1="Select * from event;";
			$q1=mysqli_query($connect, $sq1) or die ("Error in Mysqli: ".mysqli_error($connect));
			while ($qr1=mysqli_fetch_array($q1)){
				$id=$qr1['eventID'];
				$eventName=$qr1['eventName'];
				$eventDesc=$qr1['eventDesc'];
				$eventImage=$qr1['eventImagePath'];
		?>
		<div class="repeat">
			<h4><?php echo $eventName;?></h4>
				<ul class="media-list">						
					<li class="media">
						<img src="<?php echo $eventImage;?>" class="pull-left img-thumbnail custom-image zoom" alt="<?php echo $eventName; ?>" rel="zoom">
						<div class="media-body">
							<p align="justify"><?php echo $eventDesc; ?></p>
						</div>
					</li>
				</ul>
			</div>

		<?php
			}
		?>		
	</div>
</div>
	<?php include('include/footer.php');?>	
</body>
</html>